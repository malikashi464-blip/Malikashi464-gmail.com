import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(role: "admin" | "user"): TrpcContext {
  return {
    user: { id: role === "admin" ? 1 : 2, openId: `${role}-open-id`, name: role, email: `${role}@example.com`, loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("admin access control", () => {
  it("allows an administrator", async () => {
    const result = await appRouter.createCaller(context("admin")).admin.accessCheck();
    expect(result.allowed).toBe(true);
  });

  it("rejects a regular user with FORBIDDEN", async () => {
    await expect(appRouter.createCaller(context("user")).admin.accessCheck()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
