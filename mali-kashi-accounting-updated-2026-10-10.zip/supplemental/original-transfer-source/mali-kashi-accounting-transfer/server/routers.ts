import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { createCashTransaction, createCustomer, createCustomerPayment, createProduct, createPurchase, createReturn, createSale, createStockMovement, createSupplier, getCashSummary, getDashboardSummary, getCustomerById, updateCustomer, getPurchaseById, getPurchaseDetail, getSaleById, getSaleDetail, getSettings, cancelSale, updateSale, listCustomers, listCustomerPayments, listCashTransactions, getCashboxBalances, listDrivers, listProducts, listPurchaseBills, listSalesInvoices, listStockBalances, listStockMovements, listSuppliers, listUsers, listWarehouses, upsertSettings } from "./db";
import { storagePut } from "./storage";

const currency = z.enum(["IQD", "USD"]);
const moneyAmount = z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی پارە دەبێت ژمارەیەکی دروست و نەرێنی نەبێت");
const customerInput = z.object({ name: z.string().min(2), phone: z.string().optional(), address: z.string().optional(), notes: z.string().optional(), currency: currency.default("IQD"), openingBalance: moneyAmount.default("0"), advancePaymentIQD: moneyAmount.default("0"), advancePaymentUSD: moneyAmount.default("0") });
const supplierInput = z.object({ name: z.string().min(2), phone: z.string().optional(), address: z.string().optional(), notes: z.string().optional(), currency: currency.default("IQD"), openingBalance: moneyAmount.default("0") });
const customerPaymentInput = z.object({ customerId: z.number().int().positive(), currency, direction: z.enum(["in", "out"]), amount: moneyAmount.refine(value => Number(value) > 0, "بڕی پارە دەبێت زیاتر لە سفر بێت"), note: z.string().optional() });
const dateOnly = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "فۆرماتی بەروار دەبێت YYYY-MM-DD بێت");
const customerPaymentHistoryInput = z.object({ customerId: z.number().int().positive(), startDate: dateOnly.optional(), endDate: dateOnly.optional() }).refine(value => !value.startDate || !value.endDate || value.startDate <= value.endDate, { message: "بەرواری دەستپێک نابێت لە بەرواری کۆتایی دواتر بێت", path: ["endDate"] });
const productInput = z.object({ sku: z.string().min(1), barcode: z.string().optional(), imageUrl: z.string().url().max(512).optional(), imageKey: z.string().max(512).optional(), name: z.string().min(2), category: z.string().optional(), unit: z.string().default("دانە"), cartonCoverageM2: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی مەتری دووجا نابێت نەرێنی بێت").default("0"), salePriceIQD: z.string().default("0"), salePriceUSD: z.string().default("0"), purchasePriceIQD: z.string().default("0"), purchasePriceUSD: z.string().default("0"), reorderLevel: z.string().default("0") });
const productImageInput = z.object({ fileName: z.string().min(1).max(120), contentType: z.enum(["image/jpeg", "image/png", "image/webp", "image/gif"]), data: z.string().regex(/^data:image\/(jpeg|png|webp|gif);base64,/, "داتاى وێنە نادروستە").max(8_000_000) });
const saleInput = z.object({ customerId: z.number().optional(), warehouseId: z.number().optional(), currency, paymentTerm: z.enum(["cash", "credit", "partial"]), subtotal: z.string(), discount: z.string(), loadingFee: z.string(), transportFee: z.string(), total: z.string(), paidAmount: z.string(), notes: z.string().optional(), lines: z.array(z.object({ productId: z.number(), quantity: z.string().refine(value => Number(value) > 0 && Number.isFinite(Number(value)), "بڕ دەبێت ژمارەیەکی دروست و زیاتر لە سفر بێت"), cartonQuantity: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی کارتۆن نادروستە").optional(), unitPrice: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "نرخ نادروستە"), discount: z.string() })).min(1) });
const cashInput = z.object({ currency, direction: z.enum(["in", "out"]), amount: z.string(), category: z.string().min(1), note: z.string().optional() });
const purchaseInput = z.object({ supplierId: z.number().optional(), warehouseId: z.number().optional(), currency, paymentTerm: z.enum(["cash", "credit", "partial"]), subtotal: z.string(), discount: z.string(), total: z.string(), paidAmount: z.string(), notes: z.string().optional(), lines: z.array(z.object({ productId: z.number(), currency, quantity: z.string(), cartonQuantity: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی کارتۆن نادروستە").optional(), unitPrice: z.string(), discount: z.string() })).min(1) });
const returnInput = z.object({ direction: z.enum(["sales", "purchases"]), customerId: z.number().optional(), supplierId: z.number().optional(), originalSaleId: z.number().optional(), originalPurchaseId: z.number().optional(), currency, total: z.string(), cartonQuantity: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی کارتۆن نادروستە").default("0"), allowance: z.string().default("0"), notes: z.string().optional(), lines: z.array(z.object({ productId: z.number().int().positive(), quantity: z.string().refine(value => Number(value) > 0, "بڕی گەڕاوە دەبێت زیاتر لە سفر بێت"), cartonQuantity: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی کارتۆن نادروستە").default("0") })).default([]) });
export const inventoryAddInput = z.object({ productId: z.number().int().positive(), toWarehouseId: z.number().int().positive().optional(), quantity: z.string().refine(value => Number(value) > 0, "بڕ دەبێت زیاتر لە سفر بێت"), cartonQuantity: z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی کارتۆن نادروستە").optional(), unitPrice: z.string().default("0"), currency, stockType: z.enum(["opening", "adjustment"]).default("opening"), note: z.string().optional() });

const adminOnlyProcedure = protectedProcedure.use(({ ctx, next }) => { if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "تەنها بەڕێوەبەر دەتوانێت ئەم کردارە بکات" }); return next(); });

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  dashboard: router({
    summary: protectedProcedure.query(() => getDashboardSummary()),
    cashSummary: protectedProcedure.query(() => getCashSummary()),
  }),
  customers: router({
    list: protectedProcedure.query(() => listCustomers()),
    create: protectedProcedure.input(customerInput).mutation(({ input }) => createCustomer(input)),
    update: protectedProcedure.input(z.object({ id: z.number().int().positive(), data: customerInput.partial() })).mutation(({ input }) => updateCustomer(input.id, input.data)),
    payments: protectedProcedure.input(customerPaymentHistoryInput).query(async ({ input }) => { const customer = await getCustomerById(input.customerId); if (!customer) throw new TRPCError({ code: "NOT_FOUND", message: "کڕیار نەدۆزرایەوە" }); return listCustomerPayments(input.customerId, { startDate: input.startDate, endDate: input.endDate }); }),
    addPayment: protectedProcedure.input(customerPaymentInput).mutation(({ input, ctx }) => createCustomerPayment({ ...input, createdBy: ctx.user.id })),
  }),
  products: router({
    list: protectedProcedure.query(() => listProducts()),
    create: protectedProcedure.input(productInput).mutation(({ input }) => createProduct(input)),
    uploadImage: protectedProcedure.input(productImageInput).mutation(async ({ input, ctx }) => {
      const base64 = input.data.slice(input.data.indexOf(",") + 1);
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      return storagePut(`products/${ctx.user.id}/${Date.now()}-${safeName}`, Buffer.from(base64, "base64"), input.contentType);
    }),
  }),
  suppliers: router({ list: protectedProcedure.query(() => listSuppliers()), create: protectedProcedure.input(supplierInput).mutation(({ input }) => createSupplier(input)), }),
  drivers: router({ list: protectedProcedure.query(() => listDrivers()) }),
  warehouses: router({ list: protectedProcedure.query(() => listWarehouses()) }),
  inventory: router({
    movements: protectedProcedure.query(() => listStockMovements()),
    balances: protectedProcedure.query(() => listStockBalances()),
    add: protectedProcedure.input(inventoryAddInput).mutation(({ input, ctx }) => createStockMovement({ productId: input.productId, toWarehouseId: input.toWarehouseId, quantity: input.quantity, cartonQuantity: input.cartonQuantity, unitPrice: input.unitPrice, currency: input.currency, movementType: "adjustment", referenceType: input.stockType, note: input.note, createdBy: ctx.user.id })),
  }),
  purchases: router({ create: protectedProcedure.input(purchaseInput).mutation(({ input, ctx }) => createPurchase({ billNumber: `PUR-${Date.now()}`, supplierId: input.supplierId, warehouseId: input.warehouseId, currency: input.currency, paymentTerm: input.paymentTerm, subtotal: input.subtotal, discount: input.discount, total: input.total, paidAmount: input.paidAmount, status: "received", notes: input.notes, createdBy: ctx.user.id }, input.lines.map(line => ({ productId: line.productId, quantity: line.quantity, unitPrice: line.unitPrice, discount: line.discount, lineTotal: String(Number(line.quantity) * Number(line.unitPrice) - Number(line.discount)), cartonQuantity: line.cartonQuantity })) )),
  }),
  cashbox: router({ summary: protectedProcedure.query(() => getCashboxBalances()), transactions: protectedProcedure.query(() => listCashTransactions()), create: protectedProcedure.input(cashInput).mutation(({ input, ctx }) => createCashTransaction({ transactionNumber: `CASH-${Date.now()}`, ...input, createdBy: ctx.user.id })) }),
  invoices: router({ sales: protectedProcedure.query(() => listSalesInvoices()), purchases: protectedProcedure.query(() => listPurchaseBills()), salesDetail: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getSaleDetail(input.id)), purchasesDetail: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getPurchaseDetail(input.id)) }),
  returns: router({ create: protectedProcedure.input(returnInput).mutation(async ({ input, ctx }) => { if (input.direction === "sales") { if (!input.originalSaleId) throw new TRPCError({ code: "BAD_REQUEST", message: "پسوولەی فرۆشتن هەڵبژێرە" }); const invoice = await getSaleById(input.originalSaleId); if (!invoice || invoice.status !== "confirmed") throw new TRPCError({ code: "BAD_REQUEST", message: "ئەم پسوولەیە نییە یان ناتوانرێت بگەڕێندرێتەوە" }); } else { if (!input.originalPurchaseId) throw new TRPCError({ code: "BAD_REQUEST", message: "پسوولەی کڕین هەڵبژێرە" }); const bill = await getPurchaseById(input.originalPurchaseId); if (!bill || bill.status !== "received") throw new TRPCError({ code: "BAD_REQUEST", message: "ئەم پسوولەی کڕینە نییە یان ناتوانرێت بگەڕێندرێتەوە" }); } const { lines, ...returnValues } = input; return createReturn({ returnNumber: `RET-${Date.now()}`, ...returnValues, createdBy: ctx.user.id }, lines); }) }),
  users: router({ list: adminOnlyProcedure.query(() => listUsers()) }),
  settings: router({ get: protectedProcedure.query(() => getSettings()), update: protectedProcedure.input(z.object({ businessName: z.string().min(2), phone: z.string().optional(), address: z.string().optional(), defaultCurrency: currency, usdRate: z.string(), invoicePrefix: z.string().min(1).max(16) })).mutation(({ input, ctx }) => upsertSettings({ ...input, updatedBy: ctx.user.id })) }),
  sales: router({
    create: protectedProcedure.input(saleInput).mutation(async ({ input, ctx }) => { if (!input.warehouseId) throw new TRPCError({ code: "BAD_REQUEST", message: "کۆگای فرۆشتن هەڵبژێرە" }); const balances = await listStockBalances(); const requested = new Map<number, number>(); input.lines.forEach(line => requested.set(line.productId, (requested.get(line.productId) ?? 0) + Number(line.quantity))); let stockExceeded = false; requested.forEach((quantity, productId) => { const available = balances.find(row => row.productId === productId && row.warehouseId === input.warehouseId); if (!available || quantity > Number(available.quantity)) stockExceeded = true; }); if (stockExceeded) throw new TRPCError({ code: "BAD_REQUEST", message: "بڕی فرۆشتن لە بڕی کۆگا زیاترە" }); return createSale({ invoiceNumber: `INV-${Date.now()}`, customerId: input.customerId, warehouseId: input.warehouseId, currency: input.currency, paymentTerm: input.paymentTerm, subtotal: input.subtotal, discount: input.discount, loadingFee: input.loadingFee, transportFee: input.transportFee, total: input.total, paidAmount: input.paidAmount, status: "confirmed", notes: input.notes, createdBy: ctx.user.id }, input.lines.map(line => ({ productId: line.productId, quantity: line.quantity, unitPrice: line.unitPrice, discount: line.discount, lineTotal: String(Number(line.quantity) * Number(line.unitPrice) - Number(line.discount)), cartonQuantity: line.cartonQuantity }))); }),
    update: protectedProcedure.input(z.object({ id: z.number().int().positive(), data: saleInput })).mutation(async ({ input, ctx }) => { if (!input.data.warehouseId) throw new TRPCError({ code: "BAD_REQUEST", message: "کۆگای فرۆشتن هەڵبژێرە" }); const balances = await listStockBalances(); const requested = new Map<number, number>(); input.data.lines.forEach(line => requested.set(line.productId, (requested.get(line.productId) ?? 0) + Number(line.quantity))); let exceeded = false; requested.forEach((quantity, productId) => { const row = balances.find(item => item.productId === productId && item.warehouseId === input.data.warehouseId); if (!row || quantity > Number(row.quantity)) exceeded = true; }); if (exceeded) throw new TRPCError({ code: "BAD_REQUEST", message: "بڕی نوێ لە stock زیاترە" }); const { lines, ...data } = input.data; return updateSale(input.id, { ...data, invoiceNumber: `INV-${input.id}`, status: "confirmed", updatedAt: new Date() }, lines.map(line => ({ productId: line.productId, quantity: line.quantity, unitPrice: line.unitPrice, discount: line.discount, lineTotal: String(Number(line.quantity) * Number(line.unitPrice) - Number(line.discount)), cartonQuantity: line.cartonQuantity }))); }),
    delete: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { try { return await cancelSale(input.id); } catch { throw new TRPCError({ code: "BAD_REQUEST", message: "ئەم پسوولەیە ناتوانرێت بسڕدرێتەوە" }); } }),
  }),
  admin: router({ accessCheck: adminOnlyProcedure.query(({ ctx }) => ({ allowed: true, userId: ctx.user.id })) }),
});

export type AppRouter = typeof appRouter;
