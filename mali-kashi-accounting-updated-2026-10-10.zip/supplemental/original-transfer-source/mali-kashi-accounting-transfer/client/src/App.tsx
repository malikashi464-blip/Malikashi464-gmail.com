import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import DashboardLayout from "./components/DashboardLayout";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Sales from "./pages/Sales";
import Directory from "./pages/Directory";
import Drivers from "./pages/Drivers";
import Operations from "./pages/Operations";
import Inventory from "./pages/Inventory";
import InvoiceManagement from "./pages/InvoiceManagement";
import CustomerPayments from "./pages/CustomerPayments";

function Router() {
  return <Switch>
    <Route path="/" component={Home} />
    <Route path="/sales" component={Sales} />
    <Route path="/invoices" component={InvoiceManagement} />
    <Route path="/customer-payments" component={CustomerPayments} />
    <Route path="/customers" component={() => <Directory kind="customers" />} />
    <Route path="/purchases" component={() => <Operations kind="purchases" />} />
    <Route path="/suppliers" component={() => <Directory kind="suppliers" />} />
    <Route path="/products" component={() => <Directory kind="products" />} />
    <Route path="/inventory" component={Inventory} />
    <Route path="/drivers" component={Drivers} />
    <Route path="/returns" component={() => <Operations kind="returns" />} />
    <Route path="/cashbox" component={() => <Operations kind="cashbox" />} />
    <Route path="/users" component={Home} />
    <Route path="/settings" component={() => <Operations kind="settings" />} />
    <Route path="/404" component={NotFound} />
    <Route component={NotFound} />
  </Switch>;
}

function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster /><DashboardLayout><Router /></DashboardLayout></TooltipProvider></ThemeProvider></ErrorBoundary>;
}

export default App;
