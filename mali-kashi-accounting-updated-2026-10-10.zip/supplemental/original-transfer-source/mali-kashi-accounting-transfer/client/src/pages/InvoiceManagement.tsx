import { useState } from "react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export default function InvoiceManagement() {
  const [, setLocation] = useLocation();
  const invoices = trpc.invoices.sales.useQuery(undefined, { retry: false });
  const utils = trpc.useUtils();
  const remove = trpc.sales.delete.useMutation({ onSuccess: () => utils.invoices.sales.invalidate() });
  const [selected, setSelected] = useState<number | null>(null);
  const openEdit = async (id: number) => {
    const data = await utils.invoices.salesDetail.fetch({ id });
    if (!data) return;
    const draft = {
      customerId: data.invoice.customerId ? String(data.invoice.customerId) : "",
      warehouseId: data.invoice.warehouseId ? String(data.invoice.warehouseId) : "",
      driverId: data.invoice.driverId ? String(data.invoice.driverId) : "",
      currency: data.invoice.currency, paymentTerm: data.invoice.paymentTerm,
      paidAmount: data.invoice.paidAmount, loadingFee: data.invoice.loadingFee,
      transportFee: data.invoice.transportFee, discount: data.invoice.discount,
      notes: data.invoice.notes ?? "",
      lines: data.lines.map(line => ({ productId: String(line.productId), productName: `کاڵا #${line.productId}`, quantity: String(line.quantity), cartonQuantity: String(line.cartonQuantity ?? "0"), unitPrice: String(line.unitPrice), discount: String(line.discount) })),
    };
    localStorage.setItem("mali-kashi-sale-draft-edit-id", String(id));
    localStorage.setItem("mali-kashi-sale-draft", JSON.stringify(draft));
    setLocation("/sales");
  };
  return <main dir="rtl" className="mx-auto w-full max-w-[1180px] space-y-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><h1 className="text-2xl font-extrabold text-[#203328]">بەڕێوەبردنی پسوولەکانی فرۆشتن</h1><p className="mt-1 text-xs text-[#718076]">بینین، دەستکاری و پاشگەزکردنەوەی پسوولەکان</p></div><Button onClick={() => setLocation("/sales")} className="rounded-xl bg-[#079b71] text-white">پسوولەی نوێ</Button></div><section className="overflow-x-auto rounded-2xl border border-[#dfe9e7] bg-white"><div className="min-w-[720px]"><div className="grid grid-cols-6 bg-[#f2f8f4] px-4 py-3 text-xs font-bold text-[#557064]"><span>ژمارە</span><span>بەروار</span><span>دراو</span><span>کۆی گشتی</span><span>دۆخ</span><span>کردار</span></div>{invoices.isLoading ? <p className="p-6 text-center text-sm">داتا بار دەکرێت...</p> : invoices.data?.length ? invoices.data.map(row => <div key={row.id} className="grid grid-cols-6 items-center border-t border-[#edf2ef] px-4 py-3 text-xs"><b>{row.invoiceNumber}</b><span>{new Date(row.createdAt).toLocaleDateString("ku-IQ")}</span><span>{row.currency}</span><b>{row.total}</b><span>{row.status === "confirmed" ? "پەسەندکراو" : "پاشگەزکراوە"}</span><div className="flex gap-1"><Button onClick={() => { setSelected(row.id); void openEdit(row.id); }} variant="outline" className="h-8 rounded-lg px-2 text-[10px]">دەستکاری</Button>{row.status === "confirmed" && <Button onClick={() => { if (window.confirm("ئایا دڵنیایت لە پاشگەزکردنەوەی ئەم پسوولەیە؟")) remove.mutate({ id: row.id }); }} variant="outline" className="h-8 rounded-lg px-2 text-[10px] text-red-600">سڕینەوە</Button>}</div></div>) : <p className="p-8 text-center text-sm text-[#89958d]">هیچ پسوولەیەک نییە.</p>}</div></section>{selected && <p className="rounded-xl bg-[#eef8ef] p-3 text-xs text-[#438151]">پسوولەکە بۆ دەستکاری لە فۆڕمی فرۆشتن کرایەوە.</p>}</main>;
}
