export type StockIntakeInput = {
  productId: string;
  warehouseId?: string;
  quantity: string;
  unitPrice: string;
  currency: "IQD" | "USD";
  stockType: "opening" | "adjustment";
};

export function validateStockIntake(input: StockIntakeInput) {
  if (!input.productId) return { valid: false, message: "کاڵا پێویستە." } as const;
  const quantity = Number(input.quantity);
  const unitPrice = Number(input.unitPrice);
  if (!Number.isFinite(quantity) || quantity <= 0) return { valid: false, message: "بڕ دەبێت ژمارەیەکی زیاتر لە سفر بێت." } as const;
  if (!Number.isFinite(unitPrice) || unitPrice < 0) return { valid: false, message: "نرخی یەکە نابێت کەمتر لە سفر بێت." } as const;
  return { valid: true, message: "" } as const;
}

export function buildInventoryMovement(input: StockIntakeInput, createdBy: number) {
  const validation = validateStockIntake(input);
  if (!validation.valid) throw new Error(validation.message);
  return {
    productId: Number(input.productId),
    toWarehouseId: input.warehouseId ? Number(input.warehouseId) : undefined,
    quantity: input.quantity,
    unitPrice: input.unitPrice,
    currency: input.currency,
    movementType: "adjustment" as const,
    referenceType: input.stockType,
    note: input.stockType === "opening" ? "تۆماری سەرەتاییی کۆگا" : undefined,
    createdBy,
  };
}
