-- Mali Kashi transfer compatibility SQL
-- Run this after the normal Drizzle migrations in the destination project.
ALTER TABLE purchaseItems
  ADD COLUMN IF NOT EXISTS currency ENUM('IQD','USD') NOT NULL DEFAULT 'IQD' AFTER productId;
