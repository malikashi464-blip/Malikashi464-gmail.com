CREATE TABLE `cash_boxes` (
	`currency` enum('IQD','USD') NOT NULL,
	`balance` decimal(18,2) NOT NULL DEFAULT '0',
	CONSTRAINT `cash_boxes_currency` PRIMARY KEY(`currency`)
);
