# ماڵی کاشی — Project Transfer

This archive contains the source code for the current Mali Kashi accounting project, including the React frontend, Express/tRPC backend, Drizzle schema, migrations, tests, and package lockfile.

## Import into another Manus account

Create a new **Web App with database and user authentication** project, then copy the archive contents into the new project. Keep the new project's managed framework environment variables and OAuth configuration; do not copy or create a `.env` file from this archive.

Install dependencies with `pnpm install`, then run `pnpm run check`, `pnpm test`, and `pnpm run build`.

The `drizzle/` directory contains the schema and migration history. The file `database-transfer.sql` contains the compatibility statement for the per-line purchase currency field and should be run against the new project's database after the normal schema migration process if the new database does not already contain that column.

## Important account-specific setup

The destination account must configure its own Manus OAuth application and database connection through the new project environment. Existing users, sessions, uploaded files, and production database records are not included in this source archive. This package transfers the application code and database structure, not private account data.

## Main features included

- Kurdish Sorani RTL accounting dashboard.
- Sales and purchase workflows with decimal quantities and IQD/USD per purchase line.
- Multi-product purchase entry with stock availability warnings.
- One-click `کەمکردنەوە بۆ بڕی ماوە` action when requested quantity exceeds available stock.
- Customers, suppliers, inventory, cashbox, returns, reports, drivers, permissions, and responsive mobile drawer navigation.
