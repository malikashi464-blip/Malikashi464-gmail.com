export type SalesDraftLine = { productId: string; currency: "IQD" | "USD"; quantity: string; unitPrice: string; discount: string };

export function createFreshSaleDraft() {
  return {
    contactId: "",
    warehouseId: "",
    currency: "IQD" as const,
    paymentTerm: "credit" as const,
    paidAmount: "0",
    loadingFee: "0",
    transportFee: "0",
    driverName: "",
    notes: "",
    productSearch: "",
    lines: [] as SalesDraftLine[],
  };
}

export function isFreshSaleDraft(draft: ReturnType<typeof createFreshSaleDraft>) {
  return draft.contactId === "" && draft.warehouseId === "" && draft.currency === "IQD" && draft.paymentTerm === "credit" && draft.paidAmount === "0" && draft.loadingFee === "0" && draft.transportFee === "0" && draft.driverName === "" && draft.notes === "" && draft.productSearch === "" && draft.lines.length === 0;
}

// The client calls this contract before every new-sale action so a previous draft cannot leak into the next invoice.
export const freshSaleDraftContract = { createFreshSaleDraft, isFreshSaleDraft };
