# Mali Kashi ZIP merge findings

## Scope

The inspected archive was `mali-kashi-transfer-source.zip`, downloaded from the previously provided Mali Kashi transfer link. It contains 214 files and is an older snapshot of the same `mali-kashi-accounting` project, not a separate application with an independent feature set.

## Comparison

The archive contains the same major application areas already present in the active project: Kurdish RTL dashboard/layout, sales, purchasing, returns, inventory, suppliers, customers, customer advance payments, customer payment history, carton/m² tracking, image metadata, tests, Drizzle schema, and server/router code. The package manifest is unchanged between the archive and the active project.

The active project contains newer migration files `0012_condemned_franklin_storm.sql` and `0013_peaceful_sersi.sql`, while the archive stops at the earlier migration set. The active project also contains current development logs that are intentionally not part of the source archive. The archive's `vite.config.ts.bak` is not a feature and should not be merged.

## Safe decision

No feature from this archive should be copied over the active project: doing so would roll the application back and could remove newer customer-directory, payment-history, audit, return-lifecycle, and UI work. The active project already supersedes the archive in the relevant areas.

## Required next input

If the user intended a different ZIP containing additional modules or features, that specific archive must be uploaded or its direct download URL provided. It can then be compared against the active project without overwriting Mali Kashi-specific logic.
