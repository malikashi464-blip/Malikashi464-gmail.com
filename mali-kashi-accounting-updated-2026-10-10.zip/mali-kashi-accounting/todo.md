# Project TODO

- [x] Create Kurdish RTL dashboard shell for Mali Kashi
- [x] Add dashboard KPI cards, recent activity, and quick module access
- [x] Add protected sign-in and authenticated application shell
- [x] Add administrator access gate and initial role-aware application shell
- [x] Add sales invoice workspace with customer, line items, IQD/USD currency, payment terms, discounts, fees, and draft protection
- [x] Add customer directory with contact details and create workflow foundation
- [x] Add supplier-linked purchasing data model and typed create workflow foundation
- [x] Add product catalog and warehouse directory workspace
- [x] Add stock movement data model for inventory operations
- [x] Add supplier and driver directory navigation foundations
- [x] Add returns and allowances data model and typed create workflow foundation
- [x] Add cashbox and IQD/USD transaction data model and typed create workflow foundation
- [x] Add user directory endpoint, role model, and protected admin endpoint
- [x] Add business settings data model and read endpoint
- [x] Add accounting database schema and migration
- [x] Add typed backend procedures and authorization foundation
- [x] Add Vitest coverage for core accounting and authorization logic
- [x] Verify desktop and mobile responsive layouts
- [x] Run typecheck, tests, and production build
- [x] Save milestone checkpoint and deliver the project version
- [x] Make navigation and routes meaningfully role-aware
- [x] Clear saved sales draft after successful submit and load real warehouses
- [x] Replace reused sales input with supplier-specific purchasing input
- [x] Add real driver directory page and typed backend query
- [x] Deliver the validated checkpoint attachment to the user

## Next enhancement backlog (documented for the next release)

- [x] Complete granular per-module permission enforcement using userPermissions
- [x] Add full edit/delete/detail history screens for every directory
- [x] Add purchase, returns, cashbox, driver, user-management, and settings forms to the frontend
- [x] Add stock-balance calculation and transfer UI backed by stockMovements
- [x] Add customer balance, supplier balance, payment tracking, and linked transaction history
- [x] Add final accounting reports and exportable invoice/ledger documents

## New form requirements

- [x] Build complete purchasing form with supplier, warehouse, line items, currency, payment terms, discount, total, paid amount, and stock intake
- [x] Build complete returns and allowances form linked to sales or purchases
- [x] Build complete shop cashbox form for incoming and outgoing IQD/USD transactions
- [x] Build editable business settings form with company defaults and operational preferences
- [x] Add validation, success/error states, and tests for the new forms

## Return-to-invoice linkage

- [x] Add sales and purchase invoice list queries with stable invoice identifiers
- [x] Link return form invoice selection to the selected original invoice
- [x] Validate invoice existence, direction, and allowed status before saving a return
- [x] Add tests for invoice lookup and return-reference validation

## Return invoice detail

- [x] Add detailed sales and purchase invoice queries with line items
- [x] Show selected invoice details directly inside the return form
- [x] Add loading, empty, and error states for invoice details
- [x] Add tests for selected invoice detail lookup

## Reference dashboard visual match

- [x] Match mobile-first RTL dashboard structure to the reference image
- [x] Rebuild colorful three-column module-card grid with reference-like ordering
- [x] Add right-side compact icon navigation and top utility bar
- [x] Rework KPI cards and lower balance summaries to the reference composition
- [x] Verify visual match at mobile and desktop widths with tests and checkpoint

## Reference dashboard gap fixes

- [x] Make compact icon navigation visible in the mobile/reference layout and align shared shell behavior
- [x] Replace hardcoded KPI and balance values with live backend-driven values or clearly computed totals
- [x] Save a new checkpoint after the validated reference-dashboard redesign

## Compact sidebar reference match

- [x] Match compact sidebar ordering and labels to the supplied reference
- [x] Match active item, icon sizing, spacing, and scroll behavior
- [x] Verify compact sidebar on mobile and desktop
- [x] Save checkpoint for the sidebar reference update

## Sales reference layout

- [x] Rebuild sales page with the reference green invoice banner and RTL layout
- [x] Add searchable three-column product card grid with IQD/USD prices and add-to-invoice actions
- [x] Bind selected products, customer, driver, fees, discounts, and payment summary to live sales state
- [x] Verify sales workflow at mobile and desktop widths with tests and checkpoint

## Sales reference verification gap fixes

- [x] Add automated sales totals/workflow test for the reference-layout sales page
- [x] Save a fresh checkpoint after the sales reference-layout update

## Sales payload verification follow-up

- [x] Cover selected product lines, fees, discount, currency, and payment data in the sales submission payload test
- [x] Save a checkpoint after the sales payload verification update

## Barcode and invoice printing

- [x] Add barcode input/scanner flow that finds and adds products to the sale
- [x] Add successful-sale print action and printable invoice layout
- [x] Add print-ready empty/error states and preserve RTL invoice formatting
- [x] Add tests for barcode product lookup and print payload

## Print readiness hardening

- [x] Separate completed-sale print state from draft-save and barcode notifications
- [x] Reset print state when starting/saving a new draft and show a dedicated no-print state
- [x] Add a printable invoice snapshot helper and automated tests for print availability
- [x] Add explicit barcode field support when the catalog provides a barcode distinct from SKU

## Barcode and print completeness

- [x] Add a dedicated RTL print-unavailable state in the sales page
- [x] Add tests for print availability transitions after sale, draft save, and barcode edits
- [x] Add barcode to the product catalog schema/API/UI for end-to-end barcode support

## Print availability tests

- [x] Add unit coverage for print availability after successful sale, draft save, and barcode/product edits

## Print state transition hardening

- [x] Extract explicit print-state transition helpers for sale completion, draft save, and product/barcode edits
- [x] Test each print-state transition and use the helpers from Sales.tsx

## Successful sale print transition

- [x] Use printStateAfterSuccessfulSale in the Sales success flow
- [x] Add test coverage for the successful-sale transition contract used by the page

## Mobile responsive bug

- [x] Remove horizontal overflow from dashboard on narrow mobile screens
- [x] Make sales and purchasing grids, tables, and controls fit or scroll safely on mobile
- [x] Ensure sidebar does not hide or cover page content on mobile
- [x] Verify 360px, 390px, and desktop layouts with screenshots and tests

## Warehouse stock intake

- [x] Add warehouse stock-intake form for selecting warehouse and product
- [x] Add quantity, SKU/barcode, prices, and opening-stock validation
- [x] Persist stock intake as a stock movement and refresh warehouse balances
- [x] Show product quantities and recent warehouse movements
- [x] Add warehouse intake tests and responsive verification

## Inventory completeness fixes

- [x] Capture post-fix screenshots for dashboard, sales, and purchases at 360px and 390px
- [x] Add price and opening-stock fields plus validation to warehouse intake
- [x] Add per-product/per-warehouse stock balance aggregation and display
- [x] Add inventory mutation workflow tests for success, rejection, and refresh behavior

## Inventory schema/API mismatch

- [x] Pass currency and unit price from the warehouse intake form to inventory.add
- [x] Add editable currency and unit-price fields to warehouse intake
- [x] Re-run typecheck and inventory tests after the fix

## Inventory accounting hardening

- [x] Add explicit opening-stock mode and validation to warehouse intake
- [x] Validate unit price and show field-specific intake errors
- [x] Aggregate stock balances using both fromWarehouseId and toWarehouseId
- [x] Add inventory mutation tests for success, rejection, and refresh behavior
- [x] Capture post-fix responsive screenshots for dashboard, sales, and purchases at 360px and 390px

## Inventory validation and mutation coverage

- [x] Add field-level validation messages beside warehouse-intake inputs
- [x] Add router-level inventory.add tests for valid and invalid payloads
- [x] Add a testable cache-refresh helper for movements and balances after intake

## Inventory router and cache test hardening

- [x] Add actual appRouter inventory.add tests for valid and invalid tRPC payloads
- [x] Extract and test the post-intake movements/balances cache refresh helper

## Product image upload

- [x] Add secure server-side image upload endpoint using built-in storage
- [x] Add product image URL/key persistence to the product model
- [x] Add image picker, preview, and upload state to the product form
- [x] Show uploaded product images in product cards and inventory views
- [x] Add upload validation tests and verify responsive UI

## Mobile dashboard usability fix

- [x] Prevent dashboard content from being hidden or overlapped by the desktop sidebar on mobile
- [x] Make the mobile navigation rail and dashboard cards fully usable at narrow widths
- [x] Verify dashboard interactions and horizontal overflow at 360px, 390px, and desktop widths

## Mobile layout verification hardening

- [x] Add an automated mobile layout contract test for no right rail overlap, bottom navigation spacing, and narrow-width overflow protection

## Reference mobile right rail refinement

- [x] Restore a slim scrollable right-side mobile rail matching the supplied dashboard reference
- [x] Reserve exactly the rail width in the content area so cards and controls are never covered
- [x] Verify the reference composition at 360px, 390px, and desktop widths

## Product image upload hardening

- [x] Persist storage key with product image URL and pass it through product create/list flows
- [x] Preserve product form data on upload/create failure and show user-facing error feedback
- [x] Add client-side image validation tests and inspectable responsive product-form coverage

## Warehouse product creation form

- [x] Add a dedicated product-creation form inside the warehouse page matching the supplied mobile reference
- [x] Support product code, name, purchase/sale prices, category, listed unit, custom unit, currency, and optional barcode
- [x] Connect the form to the protected products.create mutation with field-level validation and success/error feedback
- [x] Refresh the warehouse product list and keep the form usable at narrow mobile widths
- [x] Add tests and verify the warehouse product form at mobile and desktop sizes

## Tile carton coverage

- [x] Add optional square-metre coverage per carton to the product schema and API
- [x] Add a mobile-friendly m²-per-carton field to the warehouse product form
- [x] Show carton coverage beside tile products and add carton conversion calculation helpers
- [x] Add validation, calculation, responsive UI tests, and migrate the database safely

## Purchase metre-to-carton inventory tracking

- [x] Add metre and carton quantities to purchase/stock intake calculations using product-specific coverage
- [x] Persist and aggregate both m² and carton balances without losing existing stock data
- [x] Show automatic conversion preview in purchasing and warehouse intake forms
- [x] Add inventory cards and reports showing remaining m² and cartons per product/warehouse
- [x] Add calculation, mutation, and responsive UI tests for the end-to-end workflow

## Sales and returns metre-to-carton tracking

- [x] Add product-specific carton conversion to sales line items and live sales UI
- [x] Add carton conversion to return selections and return payloads
- [x] Persist carton quantities for sales and returns and preserve existing metre totals
- [x] Add calculation, mutation, and responsive tests for sales and returns

## Sales and returns carton hardening

- [x] Add per-line return quantity/m² inputs with automatic carton conversion and legacy fallback
- [x] Persist return line m²/carton quantities and create the corresponding warehouse stock movement
- [x] Add sales persistence/stock-deduction tests and responsive contract tests for sales and returns carton UI

## Sales and returns persistence tests

- [x] Add server-side createSale test proving cartonQuantity persistence and warehouse deduction movement
- [x] Add server-side createReturn test proving returnItems persistence and warehouse movement direction

## Supplier creation form

- [x] Add supplier form with name, supplier phone number, address, and notes
- [x] Connect supplier form to protected suppliers.create with field-level validation
- [x] Refresh supplier list and preserve form data on failure
- [x] Add supplier workflow tests and verify responsive mobile/desktop layout

## Supplier workflow hardening

- [x] Remove the supplier placeholder and show only the real supplier form
- [x] Move supplier name validation directly under the name field
- [x] Add a protected supplier-create mutation test with success refresh and failure preservation coverage
- [x] Capture desktop verification for the supplier form

## Supplier test and desktop verification hardening

- [x] Add authenticated appRouter.suppliers.create success and invalid-payload rejection tests
- [x] Add a testable supplier submit state contract for success refresh and failure preservation
- [x] Add an inspectable desktop-open supplier form contract or explicit open-form verification artifact

## Supplier UI contract wiring

- [x] Wire supplier success refresh and failure-preservation behavior through a shared submit contract used by Directory
- [x] Use the desktop-open supplier form layout contract in the rendered supplier form
- [x] Capture explicit desktop-open supplier form verification

## Supplier final verification

- [x] Wire the supplier error path through the shared submit-state contract and assert draft preservation
- [x] Add an inspectable open-state desktop form contract tied to the rendered supplier form

## Supplier open-state assertion

- [x] Assert the rendered supplier form uses the supplier-form-open desktop layout marker

## Sales control and invoice editing

- [x] Prevent sales quantities from exceeding the selected warehouse stock in UI and protected backend validation
- [x] Allow editing quantity and unit price for each unsaved sales line
- [x] Support IQD/USD consistently for line prices, totals, and invoice submission
- [x] Normalize decimal display and calculations without losing precision
- [x] Add post-save invoice edit and delete flows with safe stock reversal/recalculation
- [x] Add tests for stock limits, decimal/currency totals, edit/delete, and responsive sales UI

## Continued sales hardening

- [x] Add backend stock validation to the protected sales mutation
- [x] Add client warehouse-balance validation and editable sale line controls
- [x] Add printable m²/carton breakdown to completed invoices
- [x] Add safe post-save invoice edit/delete lifecycle
- [x] Add focused tests and final build/checkpoint verification

## Customer advance-payment form

- [x] Add customer address, notes, and advance-payment fields to the customer data model/API
- [x] Add separate IQD and USD advance-payment inputs with validation to the customer form
- [x] Persist and display customer details and advance balances in the RTL customer directory
- [x] Add customer form tests and verify mobile/desktop rendering

## Customer payment history and advance usage

- [x] Add customer payment-history data model with IQD/USD amount, direction, reference, and notes
- [x] Add protected payment-history list/create procedures with customer validation
- [x] Consume same-currency customer advance automatically when confirming a sale
- [x] Add payment-history UI and customer advance balance display
- [x] Add transaction, currency, validation, and responsive tests

## Advance lifecycle hardening

- [x] Validate customer existence in the payment-history list procedure
- [x] Restore or recalculate customer advance and payment-history records on sale update and cancellation
- [x] Add createSale integration coverage for same-currency advance consumption and sale lifecycle restoration

## Mobile dashboard reference refinement

- [x] Rebuild the mobile dashboard content area as a reference-like two-column card grid
- [x] Add the compact mobile header actions and preserve the scrollable right rail
- [x] Increase mobile card size, rounded corners, spacing, and readable Kurdish labels
- [x] Preserve desktop dashboard behavior while verifying 360px, 390px, and 720px widths

## Customer directory reference refinement

- [x] Reorder the customer page into reference-like header, actions, summary cards, filters, and customer list sections
- [x] Add customer summary metrics and IQD/USD balance cards using live data
- [x] Add responsive customer filters and a readable RTL customer table/list for mobile
- [x] Verify the customer reference layout at mobile and desktop widths with tests and build

## Customer directory reference table details

- [x] Add live customer summary cards for count, invoice count, and IQD/USD balances
- [x] Add customer table columns for name, mobile, returns, received payments, debt, advance, and debt days
- [x] Add visible view/edit actions and mobile-safe horizontal table handling
- [x] Verify the second customer reference layout at mobile and desktop widths

## Customer table action hardening

- [x] Make the customer table edit action open and persist an existing customer record without creating a duplicate

## Customer transaction date filter

- [x] Add optional start/end date parameters to the customer payment-history query
- [x] Add start-date and end-date controls with clear/reset behavior to the payment-history page
- [x] Add validation and responsive tests for date filtering and empty results
