# Mobile right rail verification

لە 360x812، right rail ـی مۆبایل بە 88px پیشان درا، لە لای ڕاستی شاشەدا scrollable ـە و card ـەکانی داشبۆرد لە لای چەپ بە تەواوی دەبینرێن؛ rail هیچ کارتەکێکی نەپۆشی. لە 1280x720، sidebar ـی desktop هەروا بە قەبارەی ئاسایی و grid ـی سێ ستوون بەجێی خۆی ماوەتەوە. ناوەڕۆکی مۆبایل بە pr-[88px] و overflow-x-hidden پارێزراوە.
