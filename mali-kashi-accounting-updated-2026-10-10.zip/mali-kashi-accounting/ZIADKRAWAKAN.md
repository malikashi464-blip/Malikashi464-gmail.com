# زیادکراوەکان (2026-10-10)

هیچ فایلێکی پێشوو نەسڕدرایەوە. تەنها ئەمانە زیاد کران یان بە بچووکی دەستکاری کران.

## فایلی نوێ
- `server/extras.ts`: دەستکاری/ناچالاککردنی فرۆشیار، کاڵا، کۆگا، شۆفێر؛ زیادکردنی کۆگا و شۆفێر؛ هەڵوەشاندنەوەی پسوولەی کڕین؛ لۆگ؛ ڕاپۆرتی دارایی.
- `server/manageRouter.ts`: ڕێڕەوی tRPC (`trpc.manage.*`) لەگەڵ پشکنینی دەسەڵات.
- `server/extras.test.ts`: تێستی پشکنینی بڕی کۆگا پێش هەڵوەشاندنەوەی کڕین.
- `client/src/pages/Manage.tsx` (`/manage`)، `FinancialReports.tsx` (`/financial-reports`)، `AuditLog.tsx` (`/audit`).

## دەستکاری بچووک
- `server/routers.ts`: import و هێڵی `manage: manageRouter`.
- `server/db.ts`: کەشفی فرۆشیار پسوولە هەڵوەشاوەکان ناگرێتەوە.
- `client/src/App.tsx` و `DashboardLayout.tsx`: ڕێڕەو و سێ دوگمەی مێنیو.

## پێش بەکارهێنان
`pnpm install && pnpm check && pnpm test && pnpm build`
(`dist/` کۆنە تا build دووبارە بکەیتەوە.)
