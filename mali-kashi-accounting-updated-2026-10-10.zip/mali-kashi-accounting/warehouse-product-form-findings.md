# Warehouse product form verification

The warehouse page was checked at 360px and 1280px after adding the product-creation workflow. At 360px, the page remains inside the slim right navigation rail, the blue add-product action is reachable, and the dark setup card uses a single-column layout with full-width controls. At desktop width, the same card remains inside the page content without affecting the desktop sidebar.

The form contains the requested fields: product code, product name, purchase price, sale price, category, listed unit, custom unit, currency, and optional barcode. The shared validation contract returns separate errors for code, name, purchase price, and sale price, and `Inventory.tsx` renders those errors beside the corresponding controls. The save action calls the protected `products.create` procedure, refreshes `products.list` after success, and retains entered values while showing an error after mutation failure.
