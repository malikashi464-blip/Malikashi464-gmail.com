# Purchase metre-to-carton verification

The purchase route was verified at 390px and the warehouse route was verified at 390px. The purchase form now labels the quantity as metres and, after a product with coverage is selected, shows the product-specific rule such as `1.44 m² = یەک کارتۆن` together with the current carton equivalent. The second purchase line uses the same conversion logic. The warehouse balance card shows the stored m² quantity, the product's m²-per-carton rule, and the equivalent carton balance.

The database stores the product-specific `cartonCoverageM2` value with a default of zero, so existing products remain valid. Purchase quantities continue to be stored as the actual measured quantity; carton counts are derived from that quantity and the product's coverage, preserving exact metre inventory while avoiding duplicated or drifting carton data. The router accepts and validates the coverage value, and the calculation helper returns a rounded carton-equivalent value or null when coverage is unavailable.

The warehouse stock-intake form also now shows the selected product's coverage rule and the live carton equivalent beside the metre quantity field. The inventory.add router accepts an optional carton quantity, while the server-side stock movement helper calculates it automatically from the stored product coverage when the client does not provide it.
