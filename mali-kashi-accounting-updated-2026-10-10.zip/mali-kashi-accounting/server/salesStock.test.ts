import { describe, expect, it } from "vitest";
import { validateSaleStock } from "../shared/salesStock";

describe("validateSaleStock", () => {
  it("rejects a sale above warehouse balance", () => {
    expect(validateSaleStock([{ productId: 1, quantity: "10.125" }], 2, [{ productId: 1, warehouseId: 2, quantity: "10.124" }]).lines["1"]).toContain("10.124");
  });
  it("aggregates repeated lines and accepts precise decimals", () => {
    expect(Object.keys(validateSaleStock([{ productId: 1, quantity: "1.125" }, { productId: 1, quantity: "2.125" }], 2, [{ productId: 1, warehouseId: 2, quantity: "3.250" }]).lines)).toHaveLength(0);
  });
  it("requires a warehouse", () => {
    expect(validateSaleStock([{ productId: 1, quantity: "1" }], undefined, []).warehouse).toContain("کۆگا");
  });
});
