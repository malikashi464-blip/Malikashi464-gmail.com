import { describe, expect, it, vi } from "vitest";

const { createStockMovementMock } = vi.hoisted(() => ({ createStockMovementMock: vi.fn(async (movement: Record<string, unknown>) => ({ id: 77, ...movement })) }));
vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return { ...actual, createStockMovement: createStockMovementMock };
});
import { buildInventoryMovement, validateStockIntake } from "../shared/inventory";
import { appRouter, inventoryAddInput } from "./routers";
import type { TrpcContext } from "./_core/context";
import { refreshInventoryQueries } from "../client/src/lib/inventoryCache";

function authenticatedContext(): TrpcContext {
  return { user: { id: 9, openId: "inventory-test", name: "Inventory Tester", email: "inventory@example.com", loginMethod: "test", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("warehouse stock intake validation", () => {
  it("requires a warehouse and product", () => {
    expect(validateStockIntake({ productId: "", warehouseId: "2", quantity: "3", unitPrice: "0", currency: "IQD", stockType: "opening" }).valid).toBe(false);
    expect(validateStockIntake({ productId: "4", warehouseId: "", quantity: "3", unitPrice: "0", currency: "IQD", stockType: "opening" }).valid).toBe(false);
  });

  it("accepts positive finite quantities and prices only", () => {
    expect(validateStockIntake({ productId: "4", warehouseId: "2", quantity: "3.5", unitPrice: "1250", currency: "IQD", stockType: "opening" }).valid).toBe(true);
    expect(validateStockIntake({ productId: "4", warehouseId: "2", quantity: "0", unitPrice: "1250", currency: "IQD", stockType: "opening" }).valid).toBe(false);
    expect(validateStockIntake({ productId: "4", warehouseId: "2", quantity: "3", unitPrice: "-1", currency: "IQD", stockType: "opening" }).valid).toBe(false);
  });

  it("builds an opening-stock movement and rejects invalid intake", () => {
    expect(buildInventoryMovement({ productId: "4", warehouseId: "2", quantity: "3", unitPrice: "1250", currency: "IQD", stockType: "opening" }, 9)).toMatchObject({ productId: 4, toWarehouseId: 2, quantity: "3", unitPrice: "1250", referenceType: "opening", createdBy: 9 });
    expect(() => buildInventoryMovement({ productId: "4", warehouseId: "2", quantity: "0", unitPrice: "1250", currency: "IQD", stockType: "opening" }, 9)).toThrow();
  });
});

describe("inventory.add tRPC contract", () => {
  it("rejects an invalid payload through the actual router", async () => {
    const caller = appRouter.createCaller(authenticatedContext());
    await expect(caller.inventory.add({ productId: 0, toWarehouseId: 2, quantity: "0", currency: "IQD" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("accepts a valid payload and persists mapped movement fields", async () => {
    createStockMovementMock.mockClear();
    const payload = { productId: 4, toWarehouseId: 2, quantity: "3.5", cartonQuantity: "2.43", unitPrice: "1250", currency: "IQD" as const, stockType: "opening" as const };
    expect(inventoryAddInput.parse(payload)).toMatchObject(payload);
    const result = await appRouter.createCaller(authenticatedContext()).inventory.add(payload);
    expect(result).toMatchObject({ id: 77, productId: 4, toWarehouseId: 2, quantity: "3.5", cartonQuantity: "2.43", unitPrice: "1250", currency: "IQD", movementType: "adjustment", referenceType: "opening", createdBy: 9 });
    expect(createStockMovementMock).toHaveBeenCalledOnce();
  });
});

describe("inventory cache refresh", () => {
  it("invalidates both movement and balance queries", async () => {
    const movements = vi.fn(async () => undefined);
    const balances = vi.fn(async () => undefined);
    await refreshInventoryQueries({ movements, balances });
    expect(movements).toHaveBeenCalledOnce();
    expect(balances).toHaveBeenCalledOnce();
  });
});
