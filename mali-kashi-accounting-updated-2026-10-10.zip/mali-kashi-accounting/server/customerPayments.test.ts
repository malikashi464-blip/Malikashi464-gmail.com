import { describe, expect, it } from "vitest";
import { auditLogs, customerPayments, customers, sales } from "../drizzle/schema";
import { consumeCustomerAdvance, createCustomerPayment, createSale, restoreSaleAdvance, updateCustomerPayment } from "./db";

function fakeDb(customer = { id: 7, advancePaymentIQD: "1000.50", advancePaymentUSD: "5.00" }) {
  const updates: Array<{ table: unknown; values: unknown }> = [];
  const inserts: Array<{ table: unknown; values: unknown }> = [];
  const db = {
    select: () => ({ from: () => ({ where: () => ({ limit: async () => [customer] }) }) }),
    update: (table: unknown) => ({ set: (values: unknown) => ({ where: async () => { updates.push({ table, values }); } }) }),
    insert: (table: unknown) => ({ values: async (values: unknown) => { inserts.push({ table, values }); return { insertId: 88 }; } }),
  };
  return { db, updates, inserts };
}

function saleDb() {
  const updates: Array<{ table: unknown; values: unknown }> = [];
  const inserts: Array<{ table: unknown; values: unknown }> = [];
  const customer = { id: 7, advancePaymentIQD: "1000.50", advancePaymentUSD: "5.00" };
  const db = {
    select: () => ({ from: (table: unknown) => ({ where: () => { const result = Promise.resolve(table === customers ? [customer] : table === customerPayments ? [] : [{ id: 7, cartonCoverageM2: "1.44" }]) as Promise<any> & { limit?: () => Promise<any> }; result.limit = async () => table === customers ? [customer] : table === customerPayments ? [] : [{ id: 7, cartonCoverageM2: "1.44" }]; return result; } }) }),
    update: (table: unknown) => ({ set: (values: unknown) => ({ where: async () => { updates.push({ table, values }); } }) }),
    insert: (table: unknown) => ({ values: async (values: unknown) => { inserts.push({ table, values }); return { insertId: table === sales ? 41 : 88 }; } }),
    delete: () => ({ where: async () => undefined }),
  };
  return { db, updates, inserts };
}

describe("customer advance payment accounting", () => {
  it("applies only same-currency advance to the outstanding sale amount", async () => {
    const { db, updates, inserts } = fakeDb();
    const result = await consumeCustomerAdvance({ customerId: 7, saleId: 41, currency: "IQD", total: "2500", paidAmount: "600" }, db);
    expect(result).toEqual({ applied: "1000.50", balance: "0.00" });
    expect(updates).toContainEqual({ table: customers, values: { advancePaymentIQD: "0.00" } });
    expect(updates).toContainEqual({ table: sales, values: { paidAmount: "1600.50" } });
    expect(inserts).toContainEqual({ table: customerPayments, values: expect.objectContaining({ saleId: 41, currency: "IQD", direction: "out", amount: "1000.50" }) });
  });

  it("consumes same-currency advance when createSale confirms an invoice", async () => {
    const { db, updates, inserts } = saleDb();
    await createSale({ invoiceNumber: "INV-41", customerId: 7, warehouseId: 3, currency: "IQD", paymentTerm: "credit", subtotal: "2500", discount: "0", loadingFee: "0", transportFee: "0", total: "2500", paidAmount: "600", status: "confirmed", createdBy: 11 }, [{ productId: 7, quantity: "1.44", cartonQuantity: "1", unitPrice: "2500", discount: "0", lineTotal: "2500" }], db);
    expect(updates).toContainEqual({ table: customers, values: { advancePaymentIQD: "0.00" } });
    expect(updates).toContainEqual({ table: sales, values: { paidAmount: "1600.50" } });
    expect(inserts).toContainEqual({ table: customerPayments, values: expect.objectContaining({ saleId: 41, direction: "out", amount: "1000.50" }) });
  });

  it("restores sale-consumed advance exactly once for edit or cancellation", async () => {
    const { db, updates, inserts } = fakeDb({ id: 7, advancePaymentIQD: "0.00", advancePaymentUSD: "5.00" });
    db.select = () => ({ from: (table: unknown) => ({ where: () => { const result = Promise.resolve(table === customerPayments ? [{ id: 91, customerId: 7, saleId: 41, currency: "IQD", direction: "out", amount: "1000.50", referenceType: "sale-advance" }] : [{ id: 7, advancePaymentIQD: "0.00", advancePaymentUSD: "5.00" }]) as Promise<any> & { limit?: () => Promise<any> }; result.limit = async () => table === customerPayments ? [{ id: 91, customerId: 7, saleId: 41, currency: "IQD", direction: "out", amount: "1000.50", referenceType: "sale-advance" }] : [{ id: 7, advancePaymentIQD: "0.00", advancePaymentUSD: "5.00" }]; return result; } }) });
    const result = await restoreSaleAdvance(41, db);
    expect(result).toEqual({ restored: 1 });
    expect(updates).toContainEqual({ table: customers, values: { advancePaymentIQD: "1000.50" } });
    expect(inserts).toContainEqual({ table: customerPayments, values: expect.objectContaining({ direction: "in", referenceType: "sale-advance-reversal", amount: "1000.50" }) });
  });

  it("records an incoming customer payment and increases the matching balance", async () => {
    const { db, updates, inserts } = fakeDb();
    const result = await createCustomerPayment({ customerId: 7, currency: "USD", direction: "in", amount: "12.25", note: "پێشوەختە" }, db);
    expect(result.balance).toBe("17.25");
    expect(updates).toContainEqual({ table: customers, values: { advancePaymentUSD: "17.25" } });
    expect(inserts).toContainEqual({ table: customerPayments, values: expect.objectContaining({ customerId: 7, currency: "USD", direction: "in", amount: "12.25", note: "پێشوەختە" }) });
  });

  it("edits an unlinked payment, recalculates both currency balances, and writes an audit record", async () => {
    const updates: Array<{ table: unknown; values: unknown }> = [];
    const inserts: Array<{ table: unknown; values: unknown }> = [];
    const customer = { id: 7, advancePaymentIQD: "1000.50", advancePaymentUSD: "5.00" };
    const payment = { id: 22, customerId: 7, currency: "IQD" as const, direction: "in" as const, amount: "100.50", note: "کۆن", saleId: null };
    const db = {
      select: () => ({ from: (table: unknown) => ({ where: () => ({ limit: async () => table === customerPayments ? [payment] : [customer] }) }) }),
      update: (table: unknown) => ({ set: (values: unknown) => ({ where: async () => { updates.push({ table, values }); } }) }),
      insert: (table: unknown) => ({ values: async (values: unknown) => { inserts.push({ table, values }); return { insertId: 1 }; } }),
    };
    await updateCustomerPayment(22, { amount: "200.00", currency: "USD", direction: "in", note: "نوێ" }, 1, "هەڵەی نرخ", db);
    expect(updates).toContainEqual({ table: customers, values: { advancePaymentIQD: "900.00", advancePaymentUSD: "205.00" } });
    expect(updates).toContainEqual({ table: customerPayments, values: { amount: "200.00", currency: "USD", direction: "in", note: "نوێ" } });
    expect(inserts).toContainEqual({ table: auditLogs, values: expect.objectContaining({ entityType: "customerPayment", entityId: 22, action: "update", editedBy: 1, reasonForEdit: "هەڵەی نرخ" }) });
  });
});
