import { describe, expect, it, vi } from "vitest";
import { createSupplier } from "./db";
import { suppliers } from "../drizzle/schema";

describe("supplier persistence", () => {
  it("persists supplier name, phone, address, and notes", async () => {
    const values = vi.fn(async (payload: unknown) => ({ insertId: 17, payload }));
    const db = { insert: (table: unknown) => { expect(table).toBe(suppliers); return { values }; } };
    await createSupplier({ name: "کۆمپانیای کاشی", phone: "07501234567", address: "هەولێر", notes: "کڕینی بەردەوام", currency: "IQD", openingBalance: "0" }, db);
    expect(values).toHaveBeenCalledWith({ name: "کۆمپانیای کاشی", phone: "07501234567", address: "هەولێر", notes: "کڕینی بەردەوام", currency: "IQD", openingBalance: "0" });
  });
});
