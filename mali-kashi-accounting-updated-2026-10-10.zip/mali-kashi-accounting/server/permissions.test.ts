import { describe, expect, it } from "vitest";
import { getEffectivePermissions } from "./db";
import { permissionModules, roleDefaults } from "../shared/permissions";

describe("role permission defaults", () => {
  it("defines the requested view-only and edit-capable role behavior", () => {
    expect(roleDefaults.viewer).toEqual({ view: true, create: false, edit: false, delete: false });
    expect(roleDefaults.editor).toEqual({ view: true, create: true, edit: true, delete: false });
    expect(roleDefaults.manager).toEqual({ view: true, create: true, edit: true, delete: true });
  });

  it("keeps the legacy standard user editable but never destructive", () => {
    expect(roleDefaults.user).toEqual({ view: true, create: true, edit: true, delete: false });
  });

  it("resolves a viewer matrix without granting user administration", async () => {
    const permissions = await getEffectivePermissions(999999, "viewer");
    expect(permissions).toHaveLength(permissionModules.length);
    expect(permissions.find(permission => permission.module === "sales")).toMatchObject({ view: true, create: false, edit: false, delete: false });
    expect(permissions.find(permission => permission.module === "users")).toMatchObject({ view: false, create: false, edit: false, delete: false });
  });
});
