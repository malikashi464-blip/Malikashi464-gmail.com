import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function context(): TrpcContext {
  return { user: { id: 11, openId: "customer-test", name: "tester", email: "tester@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("protected customers.create", () => {
  it("persists contact fields and separate IQD/USD advance payments", async () => {
    const create = vi.spyOn(db, "createCustomer").mockResolvedValue({} as never);
    await appRouter.createCaller(context()).customers.create({ name: "کڕیاری تاقیکردنەوە", phone: "07501234567", address: "هەولێر", notes: "کڕیاری بەردەوام", advancePaymentIQD: "125000.50", advancePaymentUSD: "75.25" });
    expect(create).toHaveBeenCalledWith({ name: "کڕیاری تاقیکردنەوە", phone: "07501234567", address: "هەولێر", notes: "کڕیاری بەردەوام", currency: "IQD", openingBalance: "0", advancePaymentIQD: "125000.50", advancePaymentUSD: "75.25" });
    create.mockRestore();
  });

  it("rejects negative advance payments before database access", async () => {
    const create = vi.spyOn(db, "createCustomer");
    await expect(appRouter.createCaller(context()).customers.create({ name: "کڕیار", advancePaymentIQD: "-1" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(create).not.toHaveBeenCalled();
    create.mockRestore();
  });
});

describe("protected customers payments", () => {
  it("forwards a valid payment with the authenticated user", async () => {
    const addPayment = vi.spyOn(db, "createCustomerPayment").mockResolvedValue({ paymentId: 4, balance: "100.00" });
    const result = await appRouter.createCaller(context()).customers.addPayment({ customerId: 7, currency: "IQD", direction: "in", amount: "100.00", note: "پێشوەختە" });
    expect(result).toEqual({ paymentId: 4, balance: "100.00" });
    expect(addPayment).toHaveBeenCalledWith({ customerId: 7, currency: "IQD", direction: "in", amount: "100.00", note: "پێشوەختە", createdBy: 11 });
    addPayment.mockRestore();
  });

  it("rejects a zero payment before reaching the database", async () => {
    const addPayment = vi.spyOn(db, "createCustomerPayment");
    await expect(appRouter.createCaller(context()).customers.addPayment({ customerId: 7, currency: "IQD", direction: "in", amount: "0" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(addPayment).not.toHaveBeenCalled();
    addPayment.mockRestore();
  });
});

describe("protected customers payment history lookup", () => {
  it("rejects payment history for a missing customer", async () => {
    const lookup = vi.spyOn(db, "getCustomerById").mockResolvedValue(undefined);
    await expect(appRouter.createCaller(context()).customers.payments({ customerId: 9999 })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(lookup).toHaveBeenCalledWith(9999);
    lookup.mockRestore();
  });
});

describe("protected customers.update", () => {
  it("updates an existing customer without changing its id", async () => {
    const update = vi.spyOn(db, "updateCustomer").mockResolvedValue({ customerId: 7 });
    const result = await appRouter.createCaller(context()).customers.update({ id: 7, data: { name: "کڕیاری نوێکراوە", phone: "07501112233", advancePaymentIQD: "250.00", advancePaymentUSD: "10.50" } });
    expect(result).toEqual({ customerId: 7 });
    expect(update).toHaveBeenCalledWith(7, { name: "کڕیاری نوێکراوە", phone: "07501112233", advancePaymentIQD: "250.00", advancePaymentUSD: "10.50", currency: "IQD", openingBalance: "0" });
    update.mockRestore();
  });
});

describe("customer payment history date filters", () => {
  it("passes an inclusive date range to the payment query", async () => {
    const lookup = vi.spyOn(db, "getCustomerById").mockResolvedValue({ id: 7 } as never);
    const list = vi.spyOn(db, "listCustomerPayments").mockResolvedValue([]);
    await appRouter.createCaller(context()).customers.payments({ customerId: 7, startDate: "2026-09-01", endDate: "2026-09-03" });
    expect(list).toHaveBeenCalledWith(7, { startDate: "2026-09-01", endDate: "2026-09-03" });
    lookup.mockRestore();
    list.mockRestore();
  });

  it("rejects an end date before the start date", async () => {
    const list = vi.spyOn(db, "listCustomerPayments");
    await expect(appRouter.createCaller(context()).customers.payments({ customerId: 7, startDate: "2026-09-04", endDate: "2026-09-03" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(list).not.toHaveBeenCalled();
    list.mockRestore();
  });
});
