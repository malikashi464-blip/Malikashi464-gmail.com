import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function context(): TrpcContext {
  return {
    user: { id: 9, openId: "supplier-test", name: "tester", email: "tester@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("protected suppliers.create", () => {
  it("accepts a valid supplier and forwards all fields", async () => {
    const create = vi.spyOn(db, "createSupplier").mockResolvedValue({} as never);
    const result = await appRouter.createCaller(context()).suppliers.create({ name: "کۆمپانیای کاشی", phone: "07501234567", address: "هەولێر", notes: "کڕینی بەردەوام" });
    expect(result).toEqual({});
    expect(create).toHaveBeenCalledWith({ name: "کۆمپانیای کاشی", phone: "07501234567", address: "هەولێر", notes: "کڕینی بەردەوام", currency: "IQD", openingBalance: "0" });
    create.mockRestore();
  });

  it("rejects an invalid supplier name before reaching the database", async () => {
    const create = vi.spyOn(db, "createSupplier");
    await expect(appRouter.createCaller(context()).suppliers.create({ name: "", phone: "", address: "", notes: "" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(create).not.toHaveBeenCalled();
    create.mockRestore();
  });
});
