import { describe, expect, it, vi } from "vitest";

const storagePutMock = vi.hoisted(() => vi.fn(async () => ({ key: "products/9/test.png", url: "/manus-storage/products/9/test.png" })));
vi.mock("./storage", () => ({ storagePut: storagePutMock }));

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function context(): TrpcContext {
  return { user: { id: 9, openId: "product-test", name: "Product Tester", email: "product@example.com", loginMethod: "test", role: "admin", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("product image upload", () => {
  it("rejects non-image payloads through the protected router", async () => {
    await expect(appRouter.createCaller(context()).products.uploadImage({ fileName: "note.txt", contentType: "image/png", data: "not-an-image" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("uploads a valid base64 image and returns the storage URL", async () => {
    storagePutMock.mockClear();
    const result = await appRouter.createCaller(context()).products.uploadImage({ fileName: "tile.png", contentType: "image/png", data: "data:image/png;base64,aGVsbG8=" });
    expect(result).toEqual({ key: "products/9/test.png", url: "/manus-storage/products/9/test.png" });
    expect(storagePutMock).toHaveBeenCalledOnce();
    expect(storagePutMock).toHaveBeenCalledWith(expect.stringContaining("products/9/"), expect.any(Buffer), "image/png");
  });
});
