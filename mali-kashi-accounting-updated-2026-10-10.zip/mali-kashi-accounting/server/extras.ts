import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import { auditLogs, cashTransactions, drivers, products, purchaseItems, purchases, returns, saleItems, sales, stockMovements, suppliers, users, warehouses } from "../drizzle/schema";
import { getDb, getPurchaseById, listCustomers, listStockBalances } from "./db";

type Currency = "IQD" | "USD";
type AuditAction = "create" | "update" | "cancel";

async function writeAudit(db: any, values: { entityType: string; entityId: number; action: AuditAction; editedBy?: number; reasonForEdit?: string; previousValues?: unknown; newValues?: unknown }) {
  await db.insert(auditLogs).values({
    ...values,
    previousValues: values.previousValues === undefined ? null : JSON.stringify(values.previousValues),
    newValues: values.newValues === undefined ? null : JSON.stringify(values.newValues),
  });
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return db as any;
}

/** Pure helper: which purchase lines can no longer be taken out of the warehouse. */
export function findStockShortages(
  lines: Array<{ productId: number; quantity: string | number }>,
  balances: Array<{ productId: number; warehouseId: number; quantity: string | number }>,
  warehouseId: number,
) {
  const needed = new Map<number, number>();
  lines.forEach(line => needed.set(line.productId, (needed.get(line.productId) ?? 0) + Number(line.quantity)));
  const shortages: Array<{ productId: number; needed: number; available: number }> = [];
  needed.forEach((quantity, productId) => {
    const row = balances.find(item => item.productId === productId && item.warehouseId === warehouseId);
    const available = row ? Number(row.quantity) : 0;
    if (quantity > available + 0.0005) shortages.push({ productId, needed: quantity, available });
  });
  return shortages;
}

/* ---------- Generic update helpers (history is kept: "delete" = deactivate) ---------- */

async function updateWithAudit(table: any, entityType: string, id: number, data: Record<string, unknown>, editedBy: number, reason: string) {
  const db = await requireDb();
  const existing = (await db.select().from(table).where(eq(table.id, id)).limit(1))[0];
  if (!existing) throw new Error("تۆمارەکە نەدۆزرایەوە");
  await db.update(table).set(data).where(eq(table.id, id));
  await writeAudit(db, { entityType, entityId: id, action: "update", editedBy, reasonForEdit: reason, previousValues: existing, newValues: { ...existing, ...data } });
  return { id };
}

async function setActiveWithAudit(table: any, entityType: string, id: number, isActive: boolean, editedBy: number, reason: string) {
  const db = await requireDb();
  const existing = (await db.select().from(table).where(eq(table.id, id)).limit(1))[0];
  if (!existing) throw new Error("تۆمارەکە نەدۆزرایەوە");
  await db.update(table).set({ isActive: isActive ? 1 : 0 }).where(eq(table.id, id));
  await writeAudit(db, { entityType, entityId: id, action: isActive ? "update" : "cancel", editedBy, reasonForEdit: reason, previousValues: { isActive: existing.isActive }, newValues: { isActive: isActive ? 1 : 0 } });
  return { id, isActive };
}

export const updateSupplier = (id: number, data: Partial<typeof suppliers.$inferInsert>, by: number, reason: string) => updateWithAudit(suppliers, "supplier", id, data, by, reason);
export const setSupplierActive = (id: number, active: boolean, by: number, reason: string) => setActiveWithAudit(suppliers, "supplier", id, active, by, reason);
export const updateProduct = (id: number, data: Partial<typeof products.$inferInsert>, by: number, reason: string) => updateWithAudit(products, "product", id, data, by, reason);
export const setProductActive = (id: number, active: boolean, by: number, reason: string) => setActiveWithAudit(products, "product", id, active, by, reason);
export const updateWarehouse = (id: number, data: Partial<typeof warehouses.$inferInsert>, by: number, reason: string) => updateWithAudit(warehouses, "warehouse", id, data, by, reason);
export const setWarehouseActive = (id: number, active: boolean, by: number, reason: string) => setActiveWithAudit(warehouses, "warehouse", id, active, by, reason);
export const updateDriver = (id: number, data: Partial<typeof drivers.$inferInsert>, by: number, reason: string) => updateWithAudit(drivers, "driver", id, data, by, reason);
export const setDriverActive = (id: number, active: boolean, by: number, reason: string) => setActiveWithAudit(drivers, "driver", id, active, by, reason);

export async function createWarehouse(values: typeof warehouses.$inferInsert, by: number) {
  const db = await requireDb();
  const result = await db.insert(warehouses).values(values);
  const id = Number((result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? 0);
  if (id) await writeAudit(db, { entityType: "warehouse", entityId: id, action: "create", editedBy: by, reasonForEdit: "کۆگای نوێ", newValues: values });
  return { id };
}

export async function createDriver(values: typeof drivers.$inferInsert, by: number) {
  const db = await requireDb();
  const result = await db.insert(drivers).values(values);
  const id = Number((result as any)?.[0]?.insertId ?? (result as any)?.insertId ?? 0);
  if (id) await writeAudit(db, { entityType: "driver", entityId: id, action: "create", editedBy: by, reasonForEdit: "شۆفێری نوێ", newValues: values });
  return { id };
}

/* ---------- Purchase cancellation ---------- */

export async function cancelPurchase(id: number, editedBy: number, reason: string) {
  const db = await requireDb();
  const bill = await getPurchaseById(id);
  if (!bill || bill.status !== "received") throw new Error("ئەم پسوولەی کڕینە ناتوانرێت هەڵبوەشێنرێتەوە");
  const lines = await db.select().from(purchaseItems).where(eq(purchaseItems.purchaseId, id));
  if (bill.warehouseId && lines.length) {
    const balances = await listStockBalances();
    const shortages = findStockShortages(lines, balances, bill.warehouseId);
    if (shortages.length) throw new Error("بەشێک لە کاڵاکان فرۆشراون یان گواستراونەتەوە، بۆیە ناتوانرێت پسوولەی کڕین هەڵبوەشێنرێتەوە");
    await db.insert(stockMovements).values(lines.map((line: any) => ({
      productId: line.productId,
      fromWarehouseId: bill.warehouseId,
      quantity: line.quantity,
      cartonQuantity: line.cartonQuantity,
      unitPrice: line.unitPrice,
      currency: bill.currency,
      movementType: "return" as const,
      referenceType: "purchase-cancel",
      referenceId: id,
      note: "هەڵوەشاندنەوەی پسوولەی کڕین",
      createdBy: editedBy,
    })));
  }
  await db.update(purchases).set({ status: "cancelled" }).where(eq(purchases.id, id));
  await writeAudit(db, { entityType: "purchase", entityId: id, action: "cancel", editedBy, reasonForEdit: reason, previousValues: bill, newValues: { ...bill, status: "cancelled" } });
  return { id, status: "cancelled" as const };
}

/* ---------- Audit log ---------- */

export async function listRecentAudit(limit = 200) {
  const db = await getDb();
  if (!db) return [];
  return db.select({ id: auditLogs.id, entityType: auditLogs.entityType, entityId: auditLogs.entityId, action: auditLogs.action, reasonForEdit: auditLogs.reasonForEdit, editedBy: auditLogs.editedBy, editorName: users.name, createdAt: auditLogs.createdAt })
    .from(auditLogs).leftJoin(users, eq(auditLogs.editedBy, users.id)).orderBy(desc(auditLogs.createdAt)).limit(limit);
}

/* ---------- Financial report ---------- */

const zero = (): Record<Currency, number> => ({ IQD: 0, USD: 0 });
const byCurrency = (rows: Array<{ currency: string; value: unknown }>) => {
  const out = zero();
  rows.forEach(row => { if (row.currency === "IQD" || row.currency === "USD") out[row.currency] += Number(row.value ?? 0); });
  return out;
};

export async function getFinancialReport(range: { startDate?: string; endDate?: string } = {}) {
  const db = await getDb() as any;
  if (!db) return null;
  const dateWhere = (column: any) => {
    const parts = [] as any[];
    if (range.startDate) parts.push(gte(sql`date(${column})`, range.startDate));
    if (range.endDate) parts.push(lte(sql`date(${column})`, range.endDate));
    return parts;
  };

  // 1) Receivables: customers who still owe money (same debt formula the customers page uses)
  const customerRows = await listCustomers();
  const receivables = customerRows
    .filter((row: any) => Number(row.debtIQD) > 0 || Number(row.debtUSD) > 0)
    .map((row: any) => ({ id: row.id as number, name: row.name as string, phone: row.phone as string | null, debtIQD: Number(row.debtIQD), debtUSD: Number(row.debtUSD), debtDays: Number(row.debtDays) }))
    .sort((a: any, b: any) => (b.debtIQD + b.debtUSD) - (a.debtIQD + a.debtUSD));

  // 2) Payables: what we still owe each supplier
  const purchaseTotal = (cur: Currency) => sql<string>`(select coalesce(sum(p.total), 0) from purchases p where p.supplierId = ${suppliers.id} and p.status = 'received' and p.currency = ${cur})`;
  const purchasePaid = (cur: Currency) => sql<string>`(select coalesce(sum(p.paidAmount), 0) from purchases p where p.supplierId = ${suppliers.id} and p.status = 'received' and p.currency = ${cur})`;
  const cashOut = (cur: Currency) => sql<string>`(select coalesce(sum(case when c.direction = 'out' then c.amount else -c.amount end), 0) from cashTransactions c where c.supplierId = ${suppliers.id} and c.currency = ${cur})`;
  const returned = (cur: Currency) => sql<string>`(select coalesce(sum(r.total), 0) from returns r where r.supplierId = ${suppliers.id} and r.direction = 'purchases' and r.currency = ${cur})`;
  const owed = (cur: Currency) => sql<string>`(case when ${suppliers.currency} = ${cur} then coalesce(${suppliers.openingBalance}, 0) else 0 end) + ${purchaseTotal(cur)} - ${purchasePaid(cur)} - ${cashOut(cur)} - ${returned(cur)}`;
  const supplierRows = await db.select({ id: suppliers.id, name: suppliers.name, phone: suppliers.phone, owedIQD: owed("IQD"), owedUSD: owed("USD") }).from(suppliers);
  const payables = (supplierRows as any[])
    .map(row => ({ id: row.id as number, name: row.name as string, phone: row.phone as string | null, owedIQD: Number(row.owedIQD), owedUSD: Number(row.owedUSD) }))
    .filter(row => row.owedIQD > 0.005 || row.owedUSD > 0.005)
    .sort((a, b) => (b.owedIQD + b.owedUSD) - (a.owedIQD + a.owedUSD));

  // 3) Profit estimate for the chosen period (cost = quantity × product purchase price in the sale currency)
  const salesWhere = and(eq(sales.status, "confirmed"), ...dateWhere(sales.createdAt));
  const [salesRows, costRows, salesReturnRows, purchaseRows, expenseRows] = await Promise.all([
    db.select({ currency: sales.currency, value: sql<string>`coalesce(sum(${sales.total}), 0)` }).from(sales).where(salesWhere).groupBy(sales.currency),
    db.select({ currency: sales.currency, value: sql<string>`coalesce(sum(${saleItems.quantity} * case when ${sales.currency} = 'IQD' then ${products.purchasePriceIQD} else ${products.purchasePriceUSD} end), 0)` })
      .from(saleItems).innerJoin(sales, eq(saleItems.saleId, sales.id)).innerJoin(products, eq(saleItems.productId, products.id)).where(salesWhere).groupBy(sales.currency),
    db.select({ currency: returns.currency, value: sql<string>`coalesce(sum(${returns.total}), 0)` }).from(returns).where(and(eq(returns.direction, "sales"), ...dateWhere(returns.createdAt))).groupBy(returns.currency),
    db.select({ currency: purchases.currency, value: sql<string>`coalesce(sum(${purchases.total}), 0)` }).from(purchases).where(and(eq(purchases.status, "received"), ...dateWhere(purchases.createdAt))).groupBy(purchases.currency),
    db.select({ currency: cashTransactions.currency, value: sql<string>`coalesce(sum(${cashTransactions.amount}), 0)` }).from(cashTransactions)
      .where(and(eq(cashTransactions.direction, "out"), sql`${cashTransactions.supplierId} is null`, sql`${cashTransactions.customerId} is null`, ...dateWhere(cashTransactions.createdAt))).groupBy(cashTransactions.currency),
  ]);
  const revenue = byCurrency(salesRows), cost = byCurrency(costRows), salesReturns = byCurrency(salesReturnRows), purchased = byCurrency(purchaseRows), expenses = byCurrency(expenseRows);
  const profit = zero();
  (["IQD", "USD"] as Currency[]).forEach(cur => { profit[cur] = revenue[cur] - salesReturns[cur] - cost[cur] - expenses[cur]; });

  // 4) Stock valuation + low stock
  const [productRows, balances] = await Promise.all([db.select().from(products), listStockBalances()]);
  const totals = new Map<number, number>();
  balances.forEach((row: any) => totals.set(row.productId, (totals.get(row.productId) ?? 0) + Number(row.quantity)));
  const stockValue = zero();
  const lowStock: Array<{ id: number; name: string; sku: string; unit: string; quantity: number; reorderLevel: number }> = [];
  (productRows as any[]).forEach(product => {
    const quantity = totals.get(product.id) ?? 0;
    if (quantity > 0) { stockValue.IQD += quantity * Number(product.purchasePriceIQD); stockValue.USD += quantity * Number(product.purchasePriceUSD); }
    const reorderLevel = Number(product.reorderLevel);
    if (product.isActive && reorderLevel > 0 && quantity <= reorderLevel) lowStock.push({ id: product.id, name: product.name, sku: product.sku, unit: product.unit, quantity, reorderLevel });
  });
  lowStock.sort((a, b) => a.quantity - b.quantity);

  return {
    range,
    receivables,
    receivablesTotal: { IQD: receivables.reduce((sum: number, row: any) => sum + row.debtIQD, 0), USD: receivables.reduce((sum: number, row: any) => sum + row.debtUSD, 0) },
    payables,
    payablesTotal: { IQD: payables.reduce((sum, row) => sum + row.owedIQD, 0), USD: payables.reduce((sum, row) => sum + row.owedUSD, 0) },
    profit: { revenue, salesReturns, cost, expenses, purchased, profit },
    stockValue,
    lowStock,
  };
}
