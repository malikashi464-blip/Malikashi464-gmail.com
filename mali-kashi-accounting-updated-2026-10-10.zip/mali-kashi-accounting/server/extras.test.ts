import { describe, expect, it } from "vitest";
import { findStockShortages } from "./extras";

const balances = [{ productId: 1, warehouseId: 1, quantity: "10.000" }, { productId: 2, warehouseId: 1, quantity: "2.000" }];

describe("findStockShortages", () => {
  it("passes when the warehouse still holds everything the purchase brought in", () => {
    expect(findStockShortages([{ productId: 1, quantity: "10" }], balances, 1)).toEqual([]);
  });
  it("flags products that were already sold or moved", () => {
    expect(findStockShortages([{ productId: 2, quantity: "5" }], balances, 1)).toEqual([{ productId: 2, needed: 5, available: 2 }]);
  });
  it("treats a missing balance or another warehouse as zero stock", () => {
    expect(findStockShortages([{ productId: 1, quantity: "1" }], balances, 2)).toHaveLength(1);
  });
  it("adds repeated lines of the same product together", () => {
    expect(findStockShortages([{ productId: 1, quantity: "6" }, { productId: 1, quantity: "6" }], balances, 1)).toHaveLength(1);
  });
});
