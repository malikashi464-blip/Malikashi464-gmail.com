import { describe, expect, it, vi } from "vitest";

const { getSaleByIdMock, createReturnMock } = vi.hoisted(() => ({
  getSaleByIdMock: vi.fn(async (id: number) => id === 12 ? { id, status: "confirmed" } : undefined),
  createReturnMock: vi.fn(async (values: Record<string, unknown>) => ({ id: 88, ...values })),
}));
vi.mock("./db", async () => {
  const actual = await vi.importActual<typeof import("./db")>("./db");
  return { ...actual, getSaleById: getSaleByIdMock, createReturn: createReturnMock };
});
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("returns.invoiceValidation", () => {
  it("lists sales and purchase invoices through protected queries", async () => {
    const ctx: TrpcContext = {
      user: { id: 1, openId: "invoice-list-test", name: "Test", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.invoices.sales()).resolves.toBeDefined();
    await expect(caller.invoices.purchases()).resolves.toBeDefined();
  });

  it("returns an empty detail result for an unavailable invoice", async () => {
    const ctx: TrpcContext = {
      user: { id: 1, openId: "detail-test", name: "Test", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.invoices.salesDetail({ id: 999999 })).resolves.toBeUndefined();
    await expect(caller.invoices.purchasesDetail({ id: 999999 })).resolves.toBeUndefined();
  });

  it("rejects a sales return without an original invoice id", async () => {
    const ctx: TrpcContext = {
      user: { id: 1, openId: "returns-test", name: "Test", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.returns.create({ direction: "sales", currency: "IQD", total: "1000", allowance: "0" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("persists the carton quantity on a valid sales return", async () => {
    const ctx: TrpcContext = {
      user: { id: 1, openId: "returns-carton-test", name: "Test", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.returns.create({ direction: "sales", originalSaleId: 12, currency: "IQD", total: "1000", cartonQuantity: "2.5", allowance: "0" });
    expect(result).toMatchObject({ id: 88, cartonQuantity: "2.5", originalSaleId: 12 });
    expect(createReturnMock).toHaveBeenCalledOnce();
  });

  it("rejects a purchase return without an original purchase id", async () => {
    const ctx: TrpcContext = {
      user: { id: 1, openId: "purchase-return-test", name: "Test", email: "test@example.com", loginMethod: "test", role: "user", createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    await expect(caller.returns.create({ direction: "purchases", currency: "IQD", total: "1000", allowance: "0" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
