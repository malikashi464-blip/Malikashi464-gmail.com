import { describe, expect, it } from "vitest";
import { buildReturnStockMovement, buildSaleStockMovement } from "../shared/sales";
import { createReturn, createSale } from "./db";
import { auditLogs, products, returnItems, returns, saleItems, sales, stockMovements } from "../drizzle/schema";

describe("sales and returns carton persistence contracts", () => {
  function fakeDb() {
    const inserts: Array<{ table: unknown; values: unknown }> = [];
    const db = {
      insert: (table: unknown) => ({ values: async (values: unknown) => { inserts.push({ table, values }); return table === sales ? { insertId: 41 } : { insertId: 52 }; } }),
      select: () => ({ from: () => ({ where: () => { const result = Promise.resolve([{ id: 7, cartonCoverageM2: "1.44", warehouseId: 3 }]) as Promise<Array<{ id: number; cartonCoverageM2: string; warehouseId: number }>> & { limit?: () => Promise<Array<{ warehouseId: number }>> }; result.limit = async () => [{ warehouseId: 3 }]; return result; } }) }),
    };
    return { db, inserts };
  }

  it("runs createSale with carton persistence and warehouse deduction", async () => {
    const { db, inserts } = fakeDb();
    await createSale({ invoiceNumber: "INV-41", warehouseId: 3, currency: "IQD", paymentTerm: "cash", subtotal: "4320", discount: "0", loadingFee: "0", transportFee: "0", total: "4320", paidAmount: "4320", status: "confirmed", createdBy: 9 }, [{ productId: 7, quantity: "2.88", cartonQuantity: "2", unitPrice: "1500", discount: "0", lineTotal: "4320" }], db);
    expect(inserts.find(item => item.table === saleItems)?.values).toMatchObject([{ productId: 7, quantity: "2.88", cartonQuantity: "2", saleId: 41 }]);
    expect(inserts.find(item => item.table === stockMovements)?.values).toMatchObject([{ productId: 7, quantity: "2.88", cartonQuantity: "2", fromWarehouseId: 3, movementType: "sale" }]);
  });

  it("runs createReturn with return line persistence and inbound warehouse movement", async () => {
    const { db, inserts } = fakeDb();
    await createReturn({ returnNumber: "RET-52", direction: "sales", originalSaleId: 41, currency: "IQD", total: "2160", cartonQuantity: "1", allowance: "0", createdBy: 9 }, [{ productId: 7, quantity: "1.44", cartonQuantity: "1" }], db);
    expect(inserts.find(item => item.table === returnItems)?.values).toMatchObject([{ productId: 7, quantity: "1.44", cartonQuantity: "1", returnId: 52 }]);
    expect(inserts.find(item => item.table === stockMovements)?.values).toMatchObject([{ productId: 7, quantity: "1.44", cartonQuantity: "1", toWarehouseId: 3, movementType: "return" }]);
    expect(inserts.find(item => item.table === auditLogs)?.values).toMatchObject({ entityType: "return", entityId: 52, action: "create", editedBy: 9 });
  });

  it("writes the sold carton quantity to the warehouse deduction movement", () => {
    const movement = buildSaleStockMovement({ productId: 7, quantity: "2.88", cartonQuantity: "2", unitPrice: "1500" }, 41, 3, "IQD", "sale", 9);
    expect(movement).toMatchObject({ productId: 7, quantity: "2.88", cartonQuantity: "2", fromWarehouseId: 3, referenceId: 41, movementType: "sale" });
    expect(movement.toWarehouseId).toBeUndefined();
  });

  it("returns sold goods to the warehouse with metre and carton quantities", () => {
    const movement = buildReturnStockMovement({ productId: 7, quantity: "1.44", cartonQuantity: "1" }, 52, "sales", 3, "return", 9);
    expect(movement).toMatchObject({ productId: 7, quantity: "1.44", cartonQuantity: "1", toWarehouseId: 3, referenceId: 52, movementType: "return" });
    expect(movement.fromWarehouseId).toBeUndefined();
  });

  it("removes returned purchase goods from the warehouse", () => {
    const movement = buildReturnStockMovement({ productId: 7, quantity: "2.16", cartonQuantity: "1" }, 53, "purchases", 3);
    expect(movement.fromWarehouseId).toBe(3);
    expect(movement.toWarehouseId).toBeUndefined();
  });
});
