import { describe, expect, it } from "vitest";
import { buildSalePayload, calculateSaleCartons, calculateSaleTotals, canPrintSale, createPrintableSaleSnapshot, findSaleProductByBarcode, printStateAfterDraftSave, printStateAfterProductEdit, printStateAfterSuccessfulSale } from "../shared/sales";

describe("sales reference workflow totals", () => {
  it("converts sold square metres to product-specific cartons", () => {
    expect(calculateSaleCartons("2.88", "1.44")).toBe(2);
    expect(calculateSaleCartons("4.32", "2.16")).toBe(2);
    expect(calculateSaleCartons("2", "0")).toBeNull();
  });

  it("calculates subtotal and total from selected product lines", () => {
    expect(calculateSaleTotals([
      { quantity: "2", unitPrice: "1500", discount: "100" },
      { quantity: "1", unitPrice: "800", discount: "0" },
    ], "200", "300", "400")).toEqual({ subtotal: 3700, total: 4200 });
  });

  it("never returns a negative invoice total", () => {
    expect(calculateSaleTotals([{ quantity: 1, unitPrice: 100, discount: 0 }], 250, 0, 0).total).toBe(0);
  });

  it("finds a product by an exact barcode or SKU", () => {
    const products = [{ id: 11, name: "کاڵای تاقیکردنەوە", sku: "ABC-123" }];
    expect(findSaleProductByBarcode(products, " abc-123 ")?.id).toBe(11);
    expect(findSaleProductByBarcode(products, "missing")).toBeUndefined();
  });

  it("transitions print state for sale completion, draft save, and product edits", () => {
    const snapshot = createPrintableSaleSnapshot({ lines: [{ productId: "11", productName: "کاڵا", quantity: "1", unitPrice: "100", discount: "0" }], currency: "IQD", total: 100, customerName: "کڕیار" });
    expect(printStateAfterSuccessfulSale(snapshot)).toEqual({ completed: true, snapshot });
    expect(printStateAfterDraftSave()).toEqual({ completed: false, snapshot: null });
    expect(printStateAfterProductEdit()).toEqual({ completed: false, snapshot: null });
  });

  it("only enables printing for a completed sale with invoice lines", () => {
    const snapshot = createPrintableSaleSnapshot({ lines: [{ productId: "11", productName: "کاڵا", quantity: "1", unitPrice: "100", discount: "0" }], currency: "IQD", total: 100, customerName: "کڕیار" });
    expect(canPrintSale(true, snapshot)).toBe(true);
    expect(canPrintSale(false, snapshot)).toBe(false);
    expect(canPrintSale(true, null)).toBe(false);
    expect(canPrintSale(true, { ...snapshot, lines: [] })).toBe(false);
  });

  it("creates a printable snapshot independently of mutable sale lines", () => {
    const lines = [{ productId: "11", productName: "کاڵا", quantity: "2", unitPrice: "100", discount: "0" }];
    const snapshot = createPrintableSaleSnapshot({ lines, currency: "IQD", total: 200, customerName: "کڕیار" });
    lines[0].quantity = "9";
    expect(snapshot).toMatchObject({ currency: "IQD", total: 200, customerName: "کڕیار", lines: [{ quantity: "2" }] });
  });

  it("builds a typed submission payload from selected lines and invoice settings", () => {
    expect(buildSalePayload({ customerId: "7", warehouseId: "3", currency: "USD", paymentTerm: "partial", paidAmount: "25", loadingFee: "5", transportFee: "10", discount: "20", notes: "delivery", lines: [{ productId: "11", quantity: "2", cartonQuantity: "1.3889", unitPrice: "100", discount: "5" }, { productId: "", quantity: "1", unitPrice: "10", discount: "0" }] })).toEqual({ customerId: 7, warehouseId: 3, currency: "USD", paymentTerm: "partial", subtotal: "205", discount: "20", loadingFee: "5", transportFee: "10", total: "200", paidAmount: "25", notes: "delivery", lines: [{ productId: 11, quantity: "2", cartonQuantity: "1.3889", unitPrice: "100", discount: "5" }] });
  });
});
