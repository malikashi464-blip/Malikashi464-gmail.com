import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { getUserPermission } from "./db";
import { cancelPurchase, createDriver, createWarehouse, getFinancialReport, listRecentAudit, setDriverActive, setProductActive, setSupplierActive, setWarehouseActive, updateDriver, updateProduct, updateSupplier, updateWarehouse } from "./extras";
import type { PermissionAction, PermissionModule } from "@shared/permissions";

const currency = z.enum(["IQD", "USD"]);
const money = z.string().refine(value => Number(value) >= 0 && Number.isFinite(Number(value)), "بڕی پارە دەبێت ژمارەیەکی دروست بێت");
const reason = z.string().trim().min(2, "هۆکاری دەستکاری بنووسە");
const id = z.number().int().positive();
const dateOnly = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "فۆرماتی بەروار دەبێت YYYY-MM-DD بێت");
const blankToNull = (value?: string) => (value && value.trim() ? value.trim() : null);

const adminOnly = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "تەنها بەڕێوەبەر دەتوانێت ئەم کردارە بکات" });
  return next();
});
const allowed = (module: PermissionModule, action: PermissionAction) => protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user.role === "admin" || await getUserPermission(ctx.user.id, module, action, ctx.user.role)) return next();
  throw new TRPCError({ code: "FORBIDDEN", message: `دەسەڵاتی ${action} بۆ بەشی ${module} نییە` });
});
const guard = async <T,>(work: () => Promise<T>) => {
  try { return await work(); } catch (error) { throw new TRPCError({ code: "BAD_REQUEST", message: error instanceof Error ? error.message : "کردارەکە سەرکەوتوو نەبوو" }); }
};
const toggle = z.object({ id, isActive: z.boolean(), reason });

export const manageRouter = router({
  supplierUpdate: allowed("suppliers", "edit").input(z.object({ id, reason, data: z.object({ name: z.string().trim().min(2), phone: z.string().optional(), address: z.string().optional(), notes: z.string().optional(), currency: currency.optional(), openingBalance: money.optional() }) }))
    .mutation(({ input, ctx }) => guard(() => updateSupplier(input.id, { ...input.data, phone: blankToNull(input.data.phone), address: blankToNull(input.data.address), notes: blankToNull(input.data.notes) }, ctx.user.id, input.reason))),
  supplierSetActive: allowed("suppliers", "delete").input(toggle).mutation(({ input, ctx }) => guard(() => setSupplierActive(input.id, input.isActive, ctx.user.id, input.reason))),

  productUpdate: allowed("products", "edit").input(z.object({ id, reason, data: z.object({ sku: z.string().trim().min(1), barcode: z.string().optional(), name: z.string().trim().min(2), category: z.string().optional(), unit: z.string().trim().min(1).max(24), cartonCoverageM2: money, salePriceIQD: money, salePriceUSD: money, purchasePriceIQD: money, purchasePriceUSD: money, reorderLevel: money }) }))
    .mutation(({ input, ctx }) => guard(() => updateProduct(input.id, { ...input.data, barcode: blankToNull(input.data.barcode), category: blankToNull(input.data.category) }, ctx.user.id, input.reason))),
  productSetActive: allowed("products", "delete").input(toggle).mutation(({ input, ctx }) => guard(() => setProductActive(input.id, input.isActive, ctx.user.id, input.reason))),

  warehouseCreate: allowed("warehouse", "create").input(z.object({ name: z.string().trim().min(2), address: z.string().optional(), managerName: z.string().optional() }))
    .mutation(({ input, ctx }) => guard(() => createWarehouse({ name: input.name, address: blankToNull(input.address), managerName: blankToNull(input.managerName) }, ctx.user.id))),
  warehouseUpdate: allowed("warehouse", "edit").input(z.object({ id, reason, data: z.object({ name: z.string().trim().min(2), address: z.string().optional(), managerName: z.string().optional() }) }))
    .mutation(({ input, ctx }) => guard(() => updateWarehouse(input.id, { name: input.data.name, address: blankToNull(input.data.address), managerName: blankToNull(input.data.managerName) }, ctx.user.id, input.reason))),
  warehouseSetActive: allowed("warehouse", "delete").input(toggle).mutation(({ input, ctx }) => guard(() => setWarehouseActive(input.id, input.isActive, ctx.user.id, input.reason))),

  driverCreate: allowed("drivers", "create").input(z.object({ name: z.string().trim().min(2), phone: z.string().optional(), vehicleNumber: z.string().optional(), vehicleType: z.string().optional(), notes: z.string().optional() }))
    .mutation(({ input, ctx }) => guard(() => createDriver({ name: input.name, phone: blankToNull(input.phone), vehicleNumber: blankToNull(input.vehicleNumber), vehicleType: blankToNull(input.vehicleType), notes: blankToNull(input.notes) }, ctx.user.id))),
  driverUpdate: allowed("drivers", "edit").input(z.object({ id, reason, data: z.object({ name: z.string().trim().min(2), phone: z.string().optional(), vehicleNumber: z.string().optional(), vehicleType: z.string().optional(), notes: z.string().optional() }) }))
    .mutation(({ input, ctx }) => guard(() => updateDriver(input.id, { name: input.data.name, phone: blankToNull(input.data.phone), vehicleNumber: blankToNull(input.data.vehicleNumber), vehicleType: blankToNull(input.data.vehicleType), notes: blankToNull(input.data.notes) }, ctx.user.id, input.reason))),
  driverSetActive: allowed("drivers", "delete").input(toggle).mutation(({ input, ctx }) => guard(() => setDriverActive(input.id, input.isActive, ctx.user.id, input.reason))),

  purchaseCancel: allowed("purchases", "delete").input(z.object({ id, reason })).mutation(({ input, ctx }) => guard(() => cancelPurchase(input.id, ctx.user.id, input.reason))),

  financialReport: allowed("cashbox", "view").input(z.object({ startDate: dateOnly.optional(), endDate: dateOnly.optional() }).optional()).query(({ input }) => getFinancialReport(input ?? {})),
  auditRecent: adminOnly.query(() => listRecentAudit(200)),
});
