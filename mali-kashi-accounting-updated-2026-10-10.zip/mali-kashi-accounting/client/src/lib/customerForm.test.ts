import { describe, expect, it } from "vitest";
import { customerFormRequiredFieldLabels, productFormLayoutClassName } from "../pages/Directory";

describe("customer form contract", () => {
  it("includes all requested customer and advance-payment fields", () => {
    expect(customerFormRequiredFieldLabels).toEqual(["ناوی کڕیار", "ژمارەی پەیوەندی", "ناونیشان", "تێبینی", "پارەی پێشوەختە بە دینار", "پارەی پێشوەختە بە دۆلار"]);
  });
  it("uses a wrapping layout suitable for narrow screens", () => {
    expect(productFormLayoutClassName).toContain("flex-col");
    expect(productFormLayoutClassName).toContain("sm:flex-row");
  });
});
