type InventoryInvalidators = {
  movements: () => Promise<unknown>;
  balances: () => Promise<unknown>;
};

export async function refreshInventoryQueries(invalidators: InventoryInvalidators) {
  await Promise.all([invalidators.movements(), invalidators.balances()]);
}
