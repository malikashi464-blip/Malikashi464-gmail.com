import { describe, expect, it } from "vitest";
import { calculateReturnCartons } from "@shared/sales";
import { hasNarrowWidthProtection, salesReturnsCartonUi } from "@shared/salesReturnsResponsive";

describe("sales and returns carton workflow", () => {
  it("converts a partial return using stored invoice carton quantity", () => {
    expect(calculateReturnCartons("1.44", "2.88", "2", "1.44")).toBe(1);
  });

  it("falls back to product coverage for legacy lines without carton quantity", () => {
    expect(calculateReturnCartons("2.16", "2.16", "0", "2.16")).toBe(1);
  });

  it("protects narrow sales and return rows from overflow", () => {
    expect(hasNarrowWidthProtection(salesReturnsCartonUi.lineRow)).toBe(true);
    expect(hasNarrowWidthProtection(salesReturnsCartonUi.returnLine)).toBe(true);
    expect(salesReturnsCartonUi.cartonBadge).toContain("truncate");
  });
});
