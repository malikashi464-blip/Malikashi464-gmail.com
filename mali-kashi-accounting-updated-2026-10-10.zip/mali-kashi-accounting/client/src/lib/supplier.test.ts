import { describe, expect, it } from "vitest";
import { supplierFormDesktopLayoutClassName, supplierFormLayoutClassName, supplierFormOpenLayoutClassName, supplierFormStateAfterSubmit, validateSupplierDraft } from "@shared/supplier";

describe("supplier form", () => {
  it("requires a supplier name and accepts the requested fields", () => {
    expect(validateSupplierDraft({ name: "", phone: "", address: "", notes: "" }).name).toBeTruthy();
    expect(validateSupplierDraft({ name: "کۆمپانیای کاشی", phone: "07501234567", address: "هەولێر", notes: "کڕینی بەردەوام" })).toEqual({});
  });

  it("validates phone, address, and notes field limits", () => {
    expect(validateSupplierDraft({ name: "فرۆشیار", phone: "123", address: "", notes: "" }).phone).toBeTruthy();
    expect(validateSupplierDraft({ name: "فرۆشیار", phone: "", address: "a".repeat(256), notes: "" }).address).toBeTruthy();
    expect(validateSupplierDraft({ name: "فرۆشیار", phone: "", address: "", notes: "a".repeat(1001) }).notes).toBeTruthy();
  });

  it("keeps entered values after failure and clears them after success", () => {
    const draft = { name: "فرۆشیار", phone: "07501234567", address: "هەولێر", notes: "تێبینی" };
    expect(supplierFormStateAfterSubmit(draft, "error")).toEqual(draft);
    expect(supplierFormStateAfterSubmit(draft, "success")).toEqual({ name: "", phone: "", address: "", notes: "" });
  });

  it("uses narrow-width-safe and desktop-open responsive grids", () => {
    expect(supplierFormLayoutClassName).toContain("grid");
    expect(supplierFormLayoutClassName).toContain("gap-3");
    expect(supplierFormLayoutClassName).toContain("sm:grid-cols-2");
    expect(supplierFormDesktopLayoutClassName).toContain("lg:grid-cols-4");
    expect(supplierFormDesktopLayoutClassName).toContain("lg:items-end");
    expect(supplierFormOpenLayoutClassName).toContain("supplier-form-open");
    expect(supplierFormOpenLayoutClassName).toContain("lg:grid-cols-4");
  });
});
