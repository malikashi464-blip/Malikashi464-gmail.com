import { describe, expect, it } from "vitest";
import { customerFiltersGridClassName, customerSummaryGridClassName, customerTableClassName } from "@/pages/Directory";

describe("customer directory reference layout contract", () => {
  it("keeps the summary cards in a two-column mobile grid", () => {
    expect(customerSummaryGridClassName).toContain("grid-cols-2");
    expect(customerSummaryGridClassName).toContain("sm:grid-cols-4");
  });

  it("keeps filters responsive and the wide accounting table safely scrollable", () => {
    expect(customerFiltersGridClassName).toContain("sm:grid-cols");
    expect(customerTableClassName).toContain("min-w-[1120px]");
    expect(customerTableClassName).toContain("text-right");
  });
});
