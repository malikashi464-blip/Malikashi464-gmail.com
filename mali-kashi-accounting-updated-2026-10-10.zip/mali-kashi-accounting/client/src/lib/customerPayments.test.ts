import { describe, expect, it } from "vitest";
import { customerPaymentDateFilterLayoutClassName, customerPaymentFormLayoutClassName } from "../pages/CustomerPayments";

describe("customer payment history layout", () => {
  it("wraps the payment form from one column to a wider desktop grid", () => {
    expect(customerPaymentFormLayoutClassName).toContain("grid-cols-1");
    expect(customerPaymentFormLayoutClassName).toContain("sm:grid-cols-2");
    expect(customerPaymentFormLayoutClassName).toContain("lg:grid-cols-5");
  });

  it("keeps date filters stacked on mobile and side-by-side on larger screens", () => {
    expect(customerPaymentDateFilterLayoutClassName).toContain("grid-cols-1");
    expect(customerPaymentDateFilterLayoutClassName).toContain("sm:grid-cols-2");
  });
});
