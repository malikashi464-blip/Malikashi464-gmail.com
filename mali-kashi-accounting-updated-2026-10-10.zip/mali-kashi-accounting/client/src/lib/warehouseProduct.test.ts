import { describe, expect, it } from "vitest";
import { calculateCartons, validateWarehouseProduct, warehouseProductFormLayoutClassName } from "@shared/warehouseProduct";

describe("warehouse product form", () => {
  it("converts square metres to cartons using product-specific coverage", () => {
    expect(calculateCartons("2.88", "1.44")).toBe(2);
    expect(calculateCartons("2.17", "2.16")).toBe(1);
    expect(calculateCartons("5", "0")).toBeNull();
  });
  it("keeps the product form single-column on narrow mobile and two-column from 480px", () => {
    expect(warehouseProductFormLayoutClassName).toContain("grid-cols-1");
    expect(warehouseProductFormLayoutClassName).toContain("min-[480px]:grid-cols-2");
  });

  it("requires code, name, purchase price, and sale price", () => {
    expect(validateWarehouseProduct({ code: "", name: "", purchasePrice: "", salePrice: "" })).toEqual({
      code: "کۆدی کاڵا پێویستە.",
      name: "ناوی کاڵا پێویستە.",
      purchasePrice: "نرخی کڕین بە شێوەی دروست بنووسە.",
      salePrice: "نرخی فرۆشتن بە شێوەی دروست بنووسە.",
    });
  });

  it("accepts a complete mobile-form payload", () => {
    expect(validateWarehouseProduct({ code: "TL-001", name: "کاشی سپی", purchasePrice: "12000", salePrice: "15000" })).toEqual({});
  });
});
