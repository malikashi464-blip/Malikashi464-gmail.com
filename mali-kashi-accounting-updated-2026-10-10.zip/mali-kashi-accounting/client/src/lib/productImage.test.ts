import { describe, expect, it } from "vitest";
import { validateProductImage } from "@shared/productImage";
import { productFormLayoutClassName } from "../pages/Directory";

describe("product image picker contract", () => {
  it("accepts supported image types under 5MB", () => {
    expect(validateProductImage({ type: "image/png", size: 1024 })).toEqual({ valid: true });
    expect(validateProductImage({ type: "image/jpeg", size: 5 * 1024 * 1024 })).toEqual({ valid: true });
  });

  it("rejects unsupported types and oversized files", () => {
    expect(validateProductImage({ type: "application/pdf", size: 1024 }).valid).toBe(false);
    expect(validateProductImage({ type: "image/png", size: 5 * 1024 * 1024 + 1 }).valid).toBe(false);
  });

  it("keeps the product form single-column on mobile and horizontal from sm up", () => {
    expect(productFormLayoutClassName).toContain("flex-col");
    expect(productFormLayoutClassName).toContain("sm:flex-row");
    expect(productFormLayoutClassName).toContain("sm:items-end");
  });
});
