import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarInset, SidebarMenu, SidebarMenuButton, SidebarMenuItem, SidebarProvider, SidebarTrigger, useSidebar } from "@/components/ui/sidebar";
import { startLogin } from "@/const";
import { useIsMobile } from "@/hooks/useMobile";
import { BarChart3, Boxes, CircleDollarSign, ClipboardList, FileInput, LayoutDashboard, LogOut, PanelLeft, Settings, ShieldCheck, ShoppingCart, Truck, UserRound, Users, WalletCards, Warehouse } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from "./DashboardLayoutSkeleton";
import { Button } from "./ui/button";
import { trpc } from "@/lib/trpc";

const menuItems = [
  { id: "users-top", icon: Users, label: "بەکارهێنەران", path: "/users", adminOnly: true },
  { id: "dashboard", icon: LayoutDashboard, label: "داشبۆرد", path: "/" },
  { id: "sales", icon: ShoppingCart, label: "فرۆشتن", path: "/sales" },
  { id: "customers", icon: Users, label: "کڕیارەکان", path: "/customers" },
  { id: "customer-payments", icon: WalletCards, label: "مێژووی پارەدان", path: "/customer-payments" },
  { id: "admin", icon: ShieldCheck, label: "ڕۆڵی ئەدمین", path: "/users", adminOnly: true },
  { id: "returns", icon: FileInput, label: "گەڕاوە", path: "/returns" },
  { id: "allowance", icon: FileInput, label: "بەخشین", path: "/returns" },
  { id: "warehouse", icon: Warehouse, label: "کۆگا", path: "/inventory" },
  { id: "drivers", icon: Truck, label: "شۆفێرەکان", path: "/drivers" },
  { id: "suppliers", icon: UserRound, label: "فرۆشیاران", path: "/suppliers" },
  { id: "purchases", icon: ClipboardList, label: "کڕین", path: "/purchases" },
  { id: "expenses", icon: CircleDollarSign, label: "خەرجی", path: "/cashbox" },
  { id: "stock", icon: Boxes, label: "جوڵەی کاڵا", path: "/inventory" },
  { id: "currency", icon: CircleDollarSign, label: "دراو", path: "/cashbox" },
  { id: "delivery", icon: WalletCards, label: "بارەدان و حساب", path: "/cashbox" },
  { id: "cashbox", icon: WalletCards, label: "سندوقی دوکان", path: "/cashbox" },
  { id: "settings", icon: Settings, label: "ڕێکخستن", path: "/settings" },
  { id: "users", icon: Users, label: "بەکارهێنەران", path: "/users", adminOnly: true },
  { id: "roles", icon: ShieldCheck, label: "ڕۆڵ", path: "/users", adminOnly: true },
  { id: "warehouses", icon: Boxes, label: "ژمارەی کۆگا", path: "/inventory" },
  { id: "purchase-report", icon: FileInput, label: "وەرگرتنی کاڵاکان", path: "/purchases" },
  { id: "reports", icon: FileInput, label: "ڕاپۆرتی کڕینەکان", path: "/reports" },
  { id: "customer-report", icon: Users, label: "ڕاپۆرتی کڕیارەکان", path: "/customers" },
  { id: "fin-reports", icon: BarChart3, label: "ڕاپۆرتی دارایی", path: "/financial-reports" },
  { id: "manage", icon: Settings, label: "بەڕێوەبردنی بنەڕەت", path: "/manage" },
  { id: "audit", icon: ShieldCheck, label: "لۆگی گۆڕانکاری", path: "/audit", adminOnly: true },
];

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 136;
const MIN_WIDTH = 128;
const MAX_WIDTH = 180;

export const mobileNavigationClassName = "fixed inset-y-0 right-0 z-50 flex w-[88px] flex-col gap-0.5 overflow-y-auto border-l border-[#e8e9ef] bg-white/95 px-1.5 py-2 shadow-[-2px_0_14px_rgba(40,50,80,0.10)] backdrop-blur";
export const mobileInsetClassName = "min-w-0 overflow-x-hidden bg-[#f7f8f5] pr-[88px] sm:pr-0";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  useEffect(() => { localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString()); }, [sidebarWidth]);
  if (loading) return <DashboardLayoutSkeleton />;
  if (!user) {
    return <div dir="rtl" className="min-h-screen flex items-center justify-center bg-[#f7f8f5] px-6"><div className="w-full max-w-md rounded-[28px] border border-[#dfe6df] bg-white p-10 text-center shadow-[0_24px_80px_rgba(43,63,47,0.10)]"><div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-[#dceee1] text-[#2f6f49]"><BarChart3 className="h-8 w-8" /></div><p className="mb-2 text-sm font-semibold tracking-[0.18em] text-[#67906f]">ماڵی کاشی</p><h1 className="text-3xl font-bold text-[#203328]">بەخێربێیت</h1><p className="mt-3 text-sm leading-7 text-[#718076]">بۆ چوونەژوورەوە و بەڕێوەبردنی کاروبارەکەت، تکایە بچۆ ژوورەوە.</p><Button onClick={() => startLogin()} size="lg" className="mt-8 w-full rounded-xl bg-[#2f6f49] text-white hover:bg-[#255b3b]">چوونە ژوورەوە</Button></div></div>;
  }
  return <SidebarProvider defaultOpen={true} dir="rtl" style={{ "--sidebar-width": `${sidebarWidth}px` } as CSSProperties}><DashboardLayoutContent setSidebarWidth={setSidebarWidth}>{children}</DashboardLayoutContent></SidebarProvider>;
}

type DashboardLayoutContentProps = { children: React.ReactNode; setSidebarWidth: (width: number) => void };
function DashboardLayoutContent({ children, setSidebarWidth }: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const myPermissions = trpc.users.myPermissions.useQuery(undefined, { retry: false });
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const activeId = location === "/" ? "dashboard" : location === "/users" ? "users" : location === "/returns" ? "returns" : location === "/cashbox" ? "cashbox" : location === "/inventory" ? "warehouse" : location === "/customers" ? "customers" : location === "/customer-payments" ? "customer-payments" : location === "/suppliers" ? "suppliers" : location === "/purchases" ? "purchases" : location === "/drivers" ? "drivers" : location === "/settings" ? "settings" : "dashboard"; const activeMenuItem = menuItems.find(item => item.id === activeId) ?? menuItems[0];
  const isDashboard = location === "/";
  const isMobile = useIsMobile();
  useEffect(() => { if (isCollapsed) setIsResizing(false); }, [isCollapsed]);
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => { if (!isResizing) return; const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0; const newWidth = sidebarLeft + (sidebarRef.current?.getBoundingClientRect().width ?? DEFAULT_WIDTH) - e.clientX; if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) setSidebarWidth(newWidth); };
    const handleMouseUp = () => setIsResizing(false);
    if (isResizing) { document.addEventListener("mousemove", handleMouseMove); document.addEventListener("mouseup", handleMouseUp); document.body.style.cursor = "col-resize"; document.body.style.userSelect = "none"; }
    return () => { document.removeEventListener("mousemove", handleMouseMove); document.removeEventListener("mouseup", handleMouseUp); document.body.style.cursor = ""; document.body.style.userSelect = ""; };
  }, [isResizing, setSidebarWidth]);
  const visibleMenu = menuItems.filter(item => { if (item.adminOnly) return user?.role === "admin"; if (user?.role === "admin") return true; const module = item.id === "warehouse" || item.id === "stock" || item.id === "warehouses" ? "warehouse" : item.id === "allowance" ? "returns" : item.id === "expenses" || item.id === "currency" || item.id === "delivery" || item.id === "cashbox" ? "cashbox" : item.id === "fin-reports" ? "cashbox" : item.id === "manage" ? "settings" : item.id === "customer-report" ? "customers" : item.id === "purchase-report" ? "purchases" : item.id; return Boolean(myPermissions.data?.find(permission => permission.module === module)?.view); });
  return <>
    <div className="relative" ref={sidebarRef}>
      <Sidebar collapsible="icon" side="right" className="border-l border-[#e8e9ef] bg-white text-[#717681] shadow-[0_2px_12px_rgba(30,40,60,0.04)]" disableTransition={isResizing}>
        <SidebarHeader className="h-[58px] justify-center border-b border-[#eef0f4] px-2">
          <div className="flex items-center gap-3 w-full"><button onClick={toggleSidebar} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#f0f1ff] text-[#545be8] transition hover:bg-white/20" aria-label="گۆڕینی sidebar"><PanelLeft className="h-4 w-4" /></button>{!isCollapsed && <div className="min-w-0"><p className="truncate text-[11px] font-semibold tracking-[0.22em] text-[#9296a2]">MALI KASHI</p><p className="truncate text-base font-bold text-[#30303a]">ماڵی کاشی</p></div>}</div>
        </SidebarHeader>
        {!isCollapsed && <div className="px-5 pb-3 pt-5 text-[10px] font-bold tracking-[0.18em] text-[#a1a4ae]">بەڕێوەبردنی کاروبار</div>}
        <SidebarContent className="gap-0 px-3"><SidebarMenu>
          {visibleMenu.map(item => <SidebarMenuItem key={item.id}><SidebarMenuButton isActive={item.id === activeId} onClick={() => setLocation(item.path)} tooltip={item.label} className="my-0.5 h-11 rounded-xl px-3 font-medium text-[#8e929f] hover:bg-[#f3f4f8] hover:text-[#4f5663] data-[active=true]:bg-[#eef0ff] data-[active=true]:text-[#545be8]"><item.icon className="h-[18px] w-[18px] shrink-0" /><span>{item.label}</span></SidebarMenuButton></SidebarMenuItem>)}
        </SidebarMenu></SidebarContent>
        <SidebarFooter className="border-t border-[#eef0f4] p-2"><DropdownMenu><DropdownMenuTrigger asChild><button className="flex w-full items-center gap-3 rounded-xl px-2 py-2 text-right transition hover:bg-[#f3f4f8]"><Avatar className="h-9 w-9 shrink-0 border border-white/20"><AvatarFallback className="bg-[#eef0ff] text-[#545be8]">{user?.name?.charAt(0).toUpperCase()}</AvatarFallback></Avatar><div className="min-w-0 flex-1 text-right group-data-[collapsible=icon]:hidden"><p className="truncate text-sm font-semibold text-[#30303a]">{user?.name || "بەکارهێنەر"}</p><p className="mt-1 truncate text-[11px] text-[#8e929f]">{user?.role === "admin" ? "بەڕێوەبەری سیستەم" : "بەکارهێنەر"}</p></div><UserRound className="h-4 w-4 text-[#8e929f] group-data-[collapsible=icon]:hidden" /></button></DropdownMenuTrigger><DropdownMenuContent align="start" className="w-52"><DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive"><LogOut className="ml-2 h-4 w-4" /><span>چوونەدەرەوە</span></DropdownMenuItem></DropdownMenuContent></DropdownMenu></SidebarFooter>
      </Sidebar><div className={`absolute top-0 left-0 h-full w-1 cursor-col-resize transition-colors hover:bg-[#8dbd96]/40 ${isCollapsed ? "hidden" : ""}`} onMouseDown={() => setIsResizing(true)} style={{ zIndex: 50 }} />
    </div>
    {isMobile && !isDashboard && <nav aria-label="ناوگەڕی خێرا" className={mobileNavigationClassName}>{visibleMenu.map(item => <button key={`${item.path}-${item.label}`} onClick={() => setLocation(item.path)} aria-label={item.label} className={`flex min-h-9 w-full shrink-0 items-center gap-1 rounded-lg px-1 text-right text-[9px] font-medium transition ${item.id === activeId ? "bg-[#eef0ff] text-[#545be8]" : "text-[#707580] hover:bg-[#f3f4f8]"}`}><item.icon className="h-3.5 w-3.5 shrink-0" /><span className="truncate">{item.label}</span></button>)}</nav>}
    <SidebarInset className={isDashboard ? "min-w-0 overflow-x-hidden bg-[#f7f8f5] pr-0 sm:pr-0" : mobileInsetClassName} dir="rtl">{isMobile && <div className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-[#e2e9e2] bg-white/95 px-4 backdrop-blur"><div className="rounded-full bg-[#eef0ff] px-3 py-2 text-xs font-bold text-[#545be8]"><ShieldCheck className="ml-1 inline h-4 w-4" />{user?.role === "admin" ? "ڕۆڵی ئەدمین" : "بەکارهێنەر"}</div><div className="flex items-center gap-2"><span className="text-base font-extrabold text-[#203328]">{activeMenuItem.label}</span><SidebarTrigger className="h-9 w-9 rounded-lg" /></div></div>}<main className="min-h-screen min-w-0 flex-1 p-3 sm:p-6 lg:p-8">{children}</main></SidebarInset>
  </>;
}
