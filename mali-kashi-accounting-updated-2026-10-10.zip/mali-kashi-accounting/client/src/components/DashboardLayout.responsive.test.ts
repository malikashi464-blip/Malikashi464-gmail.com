import { describe, expect, it } from "vitest";
import { mobileInsetClassName, mobileNavigationClassName } from "./DashboardLayout";

describe("mobile dashboard layout contract", () => {
  it("keeps navigation at the bottom instead of covering the right side", () => {
    expect(mobileNavigationClassName).toContain("inset-y-0");
    expect(mobileNavigationClassName).toContain("right-0");
    expect(mobileNavigationClassName).toContain("w-[88px]");
    expect(mobileNavigationClassName).toContain("overflow-y-auto");
  });

  it("protects dashboard content from navigation overlap and horizontal overflow", () => {
    expect(mobileInsetClassName).toContain("min-w-0");
    expect(mobileInsetClassName).toContain("overflow-x-hidden");
    expect(mobileInsetClassName).toContain("pr-[88px]");
    expect(mobileInsetClassName).not.toContain("pb-[76px]");
  });
});
