import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";

export default function ReturnHistoryPanel({ onNotice }: { onNotice: (message: string) => void }) {
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [total, setTotal] = useState("");
  const [allowance, setAllowance] = useState("");
  const [reason, setReason] = useState("");
  const utils = trpc.useUtils();
  const list = trpc.returns.list.useQuery(undefined, { retry: false });
  const detail = trpc.returns.detail.useQuery({ id: selectedId ?? 0 }, { enabled: Boolean(selectedId), retry: false });
  const audit = trpc.invoices.audit.useQuery({ entityType: "return", entityId: selectedId ?? 0 }, { enabled: Boolean(selectedId), retry: false });
  const update = trpc.returns.update.useMutation({ onSuccess: async () => { await utils.returns.list.invalidate(); await utils.returns.detail.invalidate(); await utils.invoices.audit.invalidate(); onNotice("گەڕاوەکە و مێژووی دەستکاری نوێ کرانەوە."); setReason(""); } });

  useEffect(() => {
    if (!detail.data) return;
    setTotal(String(detail.data.return.total));
    setAllowance(String(detail.data.return.allowance));
  }, [detail.data]);

  const save = () => {
    if (!detail.data || !selectedId || reason.trim().length < 2) return;
    const header = detail.data.return;
    update.mutate({ id: selectedId, reason, data: { direction: header.direction, customerId: header.customerId ?? undefined, supplierId: header.supplierId ?? undefined, originalSaleId: header.originalSaleId ?? undefined, originalPurchaseId: header.originalPurchaseId ?? undefined, currency: header.currency, total, cartonQuantity: String(header.cartonQuantity), allowance, notes: header.notes ?? "", lines: detail.data.lines.map(line => ({ productId: line.productId, quantity: String(line.quantity), cartonQuantity: String(line.cartonQuantity) })) } });
  };

  return <section dir="rtl" className="rounded-2xl border border-[#dfe9e7] bg-white p-5 shadow-[0_10px_28px_rgba(43,63,47,0.04)]"><div className="mb-4 flex flex-wrap items-center justify-between gap-2"><div><h2 className="text-lg font-bold text-[#203328]">مێژووی گەڕاوەکان</h2><p className="mt-1 text-xs text-[#718076]">گەڕاوەی کۆیی، دەستکاریی بڕ و بەخشین، و audit trail</p></div><span className="rounded-full bg-[#eef8ef] px-3 py-1 text-xs font-bold text-[#438151]">{list.data?.length ?? 0} تۆمار</span></div><div className="grid gap-4 lg:grid-cols-[.9fr_1.1fr]"><div className="space-y-2">{list.data?.length ? list.data.map(row => <button key={row.id} onClick={() => setSelectedId(row.id)} className={`w-full rounded-xl border p-3 text-right transition ${selectedId === row.id ? "border-[#65a66d] bg-[#f4fbf4]" : "border-[#edf2ef] bg-white hover:border-[#cfe5d2]"}`}><div className="flex items-center justify-between gap-2"><b className="text-sm text-[#304234]">{row.returnNumber}</b><span className="text-xs text-[#718076]">{row.direction === "sales" ? "گەڕاندنەوەی فرۆشتن" : "گەڕاندنەوەی کڕین"}</span></div><p className="mt-1 text-xs text-[#718076]">{row.total} {row.currency} · {new Date(row.createdAt).toLocaleDateString("ku-IQ")}</p></button>) : <p className="rounded-xl bg-[#f8fcf8] p-5 text-center text-xs text-[#89958d]">هێشتا گەڕاوەیەک تۆمار نەکراوە.</p>}</div><div className="rounded-xl bg-[#f8fcf8] p-4">{!selectedId || !detail.data ? <p className="py-12 text-center text-xs text-[#89958d]">گەڕاوەیەک هەڵبژێرە بۆ بینینی وردەکاری و مێژوو.</p> : <><div className="grid gap-3 sm:grid-cols-2"><label className="space-y-1 text-xs font-bold text-[#718076]">کۆی گەڕاوە<Input value={total} onChange={e => setTotal(e.target.value)} className="mt-1 h-9 rounded-lg bg-white" /></label><label className="space-y-1 text-xs font-bold text-[#718076]">بەخشین/داشکاندن<Input value={allowance} onChange={e => setAllowance(e.target.value)} className="mt-1 h-9 rounded-lg bg-white" /></label></div><label className="mt-3 block space-y-1 text-xs font-bold text-[#718076]">هۆکاری دەستکاری<Input value={reason} onChange={e => setReason(e.target.value)} placeholder="بۆچی گۆڕانکاری کرا؟" className="mt-1 h-9 rounded-lg bg-white" /></label><Button onClick={save} disabled={update.isPending || reason.trim().length < 2} className="mt-3 rounded-lg bg-[#2f6f49] text-white">پاشەکەوتکردنی دەستکاری</Button><div className="mt-5"><h3 className="mb-2 text-sm font-bold text-[#557064]">مێژووی دەستکاری</h3>{audit.data?.length ? audit.data.map(log => <div key={log.id} className="mb-2 rounded-lg bg-white p-3 text-xs"><b>{log.action === "update" ? "دەستکاری" : log.action === "create" ? "دروستکردن" : "پاشگەزکردنەوە"}</b><span className="mx-2 text-[#718076]">{new Date(log.createdAt).toLocaleString("ku-IQ")}</span><span className="text-[#718076]">{log.reasonForEdit || "بێ هۆکار"}</span></div>) : <p className="text-xs text-[#89958d]">هیچ مێژوویەک نییە.</p>}</div></>}</div></div></section>;
}
