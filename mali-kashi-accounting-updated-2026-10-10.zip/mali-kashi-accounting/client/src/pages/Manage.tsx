import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

type Field = { key: string; label: string; options?: string[] };
type Row = Record<string, any> & { id: number; isActive?: number };
type SaveFn = (id: number | null, values: Record<string, string>, reason: string) => Promise<unknown>;

const tabs = [
  { key: "suppliers", label: "فرۆشیاران" },
  { key: "products", label: "کاڵاکان" },
  { key: "warehouses", label: "کۆگاکان" },
  { key: "drivers", label: "شۆفێرەکان" },
  { key: "purchases", label: "پسوولەی کڕین" },
] as const;
type TabKey = (typeof tabs)[number]["key"];

function errorText(error: unknown) { return error instanceof Error ? error.message : "کردارەکە سەرکەوتوو نەبوو"; }
function askReason(text: string) { const value = window.prompt(text); return value && value.trim().length >= 2 ? value.trim() : null; }

function EntityTable({ rows, loading, error, fields, canCreate, createLabel, onSave, onToggle }: { rows: Row[]; loading: boolean; error: boolean; fields: Field[]; canCreate: boolean; createLabel: string; onSave: SaveFn; onToggle: (row: Row, reason: string) => Promise<unknown> }) {
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [reason, setReason] = useState("");
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState(false);
  const open = (row: Row | null) => { setEditing(row ? row.id : "new"); setReason(""); setValues(Object.fromEntries(fields.map(field => [field.key, String(row?.[field.key] ?? "")]))); };
  const submit = async () => {
    if (editing !== "new" && reason.trim().length < 2) { toast.error("هۆکاری دەستکاری بنووسە"); return; }
    setBusy(true);
    try { await onSave(editing === "new" ? null : editing, values, reason.trim()); toast.success("پاشەکەوت کرا"); setEditing(null); } catch (e) { toast.error(errorText(e)); } finally { setBusy(false); }
  };
  const shown = rows.filter(row => !search.trim() || fields.some(field => String(row[field.key] ?? "").toLowerCase().includes(search.trim().toLowerCase())));
  return <div className="space-y-4">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="گەڕان..." className="h-9 w-full max-w-xs rounded-lg" />
      {canCreate && <Button onClick={() => open(null)} className="rounded-xl bg-[#2f6f49] text-white hover:bg-[#255b3b]">{createLabel}</Button>}
    </div>
    {editing !== null && <div className="rounded-2xl border border-[#dce9df] bg-[#fbfdfb] p-4">
      <p className="mb-3 text-sm font-bold text-[#304234]">{editing === "new" ? createLabel : "دەستکاریکردن"}</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {fields.map(field => <label key={field.key} className="text-xs font-semibold text-[#5c6f61]">{field.label}
          {field.options ? <select value={values[field.key] ?? ""} onChange={e => setValues({ ...values, [field.key]: e.target.value })} className="mt-1 h-9 w-full rounded-lg border border-[#e1e9e1] bg-white px-2 text-sm">{field.options.map(option => <option key={option} value={option}>{option}</option>)}</select>
            : <Input value={values[field.key] ?? ""} onChange={e => setValues({ ...values, [field.key]: e.target.value })} className="mt-1 h-9 rounded-lg" />}
        </label>)}
        {editing !== "new" && <label className="text-xs font-semibold text-[#b86861]">هۆکاری دەستکاری *<Input value={reason} onChange={e => setReason(e.target.value)} className="mt-1 h-9 rounded-lg" /></label>}
      </div>
      <div className="mt-4 flex gap-2"><Button disabled={busy} onClick={submit} className="rounded-xl bg-[#2f6f49] text-white hover:bg-[#255b3b]">پاشەکەوتکردن</Button><Button variant="outline" onClick={() => setEditing(null)} className="rounded-xl">پاشگەزبوونەوە</Button></div>
    </div>}
    {error && <p className="rounded-xl bg-[#fff1f0] px-4 py-3 text-sm font-semibold text-[#b86861]">بارکردنی داتا سەرکەوتوو نەبوو یان دەسەڵاتت نییە.</p>}
    <div className="overflow-x-auto"><table className="w-full min-w-[720px] text-right text-sm">
      <thead><tr className="border-b border-[#edf1ed] text-xs text-[#92a095]">{fields.map(field => <th key={field.key} className="pb-3 font-medium">{field.label}</th>)}<th className="pb-3 font-medium">دۆخ</th><th className="pb-3 font-medium">کردار</th></tr></thead>
      <tbody>{loading ? <tr><td colSpan={fields.length + 2} className="py-8 text-center text-xs text-[#89958d]">داتا بار دەکرێت...</td></tr> : shown.map(row => <tr key={row.id} className={`border-b border-[#f0f3f0] last:border-0 ${row.isActive === 0 ? "opacity-50" : ""}`}>
        {fields.map(field => <td key={field.key} className="py-3 text-[#304234]">{String(row[field.key] ?? "") || "—"}</td>)}
        <td className="py-3"><span className={`rounded-full px-2 py-0.5 text-[11px] font-bold ${row.isActive === 0 ? "bg-[#f3f4f6] text-[#7b8190]" : "bg-[#e6f4ea] text-[#2f8a54]"}`}>{row.isActive === 0 ? "ناچالاک" : "چالاک"}</span></td>
        <td className="py-3"><div className="flex gap-2"><Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" onClick={() => open(row)}>دەستکاری</Button>
          <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs" onClick={async () => { const why = askReason(row.isActive === 0 ? "هۆکاری چالاککردنەوە:" : "هۆکاری ناچالاککردن (مێژووی مامەڵەکان دەمێنێتەوە):"); if (!why) return; try { await onToggle(row, why); toast.success("کرا"); } catch (e) { toast.error(errorText(e)); } }}>{row.isActive === 0 ? "چالاککردن" : "ناچالاککردن"}</Button></div></td>
      </tr>)}</tbody></table></div>
  </div>;
}

function PurchasesTab() {
  const utils = trpc.useUtils();
  const bills = trpc.invoices.purchases.useQuery(undefined, { retry: false });
  const suppliers = trpc.suppliers.list.useQuery(undefined, { retry: false });
  const cancel = trpc.manage.purchaseCancel.useMutation({ onSuccess: () => { void utils.invoices.purchases.invalidate(); void utils.inventory.balances.invalidate(); } });
  const supplierName = (id: number | null) => (suppliers.data as Row[] | undefined)?.find(item => item.id === id)?.name ?? "—";
  const statusLabel: Record<string, string> = { received: "وەرگیراو", cancelled: "هەڵوەشاوە", draft: "ڕەشنووس" };
  return <div className="space-y-3">
    <p className="rounded-xl bg-[#fff8e8] px-4 py-3 text-xs font-semibold text-[#8a6a1f]">هەڵوەشاندنەوە کاڵاکان لە کۆگا دەردەهێنێتەوە و لە حیسابی فرۆشیار دەرەچێت. ئەگەر کاڵاکە فرۆشرابێت ڕێگە نادرێت. بۆ ڕاستکردنەوە: پسوولە هەڵبوەشێنەرەوە و دووبارە تۆماری بکە.</p>
    {bills.isError && <p className="rounded-xl bg-[#fff1f0] px-4 py-3 text-sm font-semibold text-[#b86861]">بارکردنی داتا سەرکەوتوو نەبوو.</p>}
    <div className="overflow-x-auto"><table className="w-full min-w-[640px] text-right text-sm"><thead><tr className="border-b border-[#edf1ed] text-xs text-[#92a095]"><th className="pb-3 font-medium">ژمارە</th><th className="pb-3 font-medium">فرۆشیار</th><th className="pb-3 font-medium">کۆ</th><th className="pb-3 font-medium">بەروار</th><th className="pb-3 font-medium">دۆخ</th><th className="pb-3 font-medium">کردار</th></tr></thead>
      <tbody>{(bills.data as any[] | undefined)?.map(bill => <tr key={bill.id} className="border-b border-[#f0f3f0] last:border-0"><td className="py-3 font-semibold text-[#304234]">{bill.billNumber}</td><td className="py-3">{supplierName(bill.supplierId)}</td><td className="py-3">{Number(bill.total).toLocaleString("ku-IQ")} {bill.currency}</td><td className="py-3 text-xs text-[#89958d]">{new Date(bill.createdAt).toLocaleDateString("ku-IQ")}</td><td className="py-3">{statusLabel[bill.status] ?? bill.status}</td>
        <td className="py-3">{bill.status === "received" && <Button size="sm" variant="outline" className="h-8 rounded-lg text-xs text-[#b86861]" disabled={cancel.isPending} onClick={async () => { const why = askReason("هۆکاری هەڵوەشاندنەوەی پسوولەی کڕین:"); if (!why) return; try { await cancel.mutateAsync({ id: bill.id, reason: why }); toast.success("پسوولە هەڵوەشێنرایەوە"); } catch (e) { toast.error(errorText(e)); } }}>هەڵوەشاندنەوە</Button>}</td></tr>)}</tbody></table></div>
  </div>;
}

export default function Manage() {
  const utils = trpc.useUtils();
  const [tab, setTab] = useState<TabKey>("suppliers");
  const suppliers = trpc.suppliers.list.useQuery(undefined, { retry: false });
  const products = trpc.products.list.useQuery(undefined, { retry: false });
  const warehouses = trpc.warehouses.list.useQuery(undefined, { retry: false });
  const drivers = trpc.drivers.list.useQuery(undefined, { retry: false });
  const m = trpc.manage;
  const supplierUpdate = m.supplierUpdate.useMutation({ onSuccess: () => utils.suppliers.list.invalidate() });
  const supplierToggle = m.supplierSetActive.useMutation({ onSuccess: () => utils.suppliers.list.invalidate() });
  const productUpdate = m.productUpdate.useMutation({ onSuccess: () => utils.products.list.invalidate() });
  const productToggle = m.productSetActive.useMutation({ onSuccess: () => utils.products.list.invalidate() });
  const warehouseCreate = m.warehouseCreate.useMutation({ onSuccess: () => utils.warehouses.list.invalidate() });
  const warehouseUpdate = m.warehouseUpdate.useMutation({ onSuccess: () => utils.warehouses.list.invalidate() });
  const warehouseToggle = m.warehouseSetActive.useMutation({ onSuccess: () => utils.warehouses.list.invalidate() });
  const driverCreate = m.driverCreate.useMutation({ onSuccess: () => utils.drivers.list.invalidate() });
  const driverUpdate = m.driverUpdate.useMutation({ onSuccess: () => utils.drivers.list.invalidate() });
  const driverToggle = m.driverSetActive.useMutation({ onSuccess: () => utils.drivers.list.invalidate() });

  return <main dir="rtl" className="mx-auto max-w-[1500px] space-y-5 text-[#203328]">
    <header><p className="text-xs font-bold text-[#5c9a68]">بەڕێوەبردن</p><h1 className="mt-1 text-3xl font-extrabold">بەڕێوەبردنی بنەڕەت</h1><p className="mt-1 text-sm text-[#718076]">دەستکاری، ناچالاککردن و هەڵوەشاندنەوە. هەموو گۆڕانکارییەک لە لۆگدا تۆمار دەکرێت و مێژووی مامەڵەکان ناسڕدرێتەوە.</p></header>
    <nav className="flex flex-wrap gap-2">{tabs.map(item => <button key={item.key} onClick={() => setTab(item.key)} className={`rounded-xl px-4 py-2 text-sm font-bold transition ${tab === item.key ? "bg-[#2f6f49] text-white" : "bg-white text-[#557064] hover:bg-[#eef5ef]"}`}>{item.label}</button>)}</nav>
    <section className="rounded-[24px] border border-[#e3ebe3] bg-white p-5 shadow-sm">
      {tab === "suppliers" && <EntityTable rows={(suppliers.data ?? []) as Row[]} loading={suppliers.isLoading} error={suppliers.isError} canCreate={false} createLabel=""
        fields={[{ key: "name", label: "ناو" }, { key: "phone", label: "مۆبایل" }, { key: "address", label: "ناونیشان" }, { key: "notes", label: "تێبینی" }, { key: "currency", label: "دراو", options: ["IQD", "USD"] }, { key: "openingBalance", label: "قەرزی سەرەتا" }]}
        onSave={(id, v, reason) => supplierUpdate.mutateAsync({ id: id!, reason, data: { name: v.name, phone: v.phone, address: v.address, notes: v.notes, currency: v.currency as "IQD" | "USD", openingBalance: v.openingBalance || "0" } })}
        onToggle={(row, reason) => supplierToggle.mutateAsync({ id: row.id, isActive: row.isActive === 0, reason })} />}
      {tab === "products" && <EntityTable rows={(products.data ?? []) as Row[]} loading={products.isLoading} error={products.isError} canCreate={false} createLabel=""
        fields={[{ key: "sku", label: "کۆد" }, { key: "barcode", label: "باڕکۆد" }, { key: "name", label: "ناو" }, { key: "category", label: "پۆل" }, { key: "unit", label: "یەکە" }, { key: "cartonCoverageM2", label: "م² لە کارتۆن" }, { key: "salePriceIQD", label: "فرۆشتن IQD" }, { key: "salePriceUSD", label: "فرۆشتن USD" }, { key: "purchasePriceIQD", label: "کڕین IQD" }, { key: "purchasePriceUSD", label: "کڕین USD" }, { key: "reorderLevel", label: "سنووری کەمبوون" }]}
        onSave={(id, v, reason) => productUpdate.mutateAsync({ id: id!, reason, data: { sku: v.sku, barcode: v.barcode, name: v.name, category: v.category, unit: v.unit, cartonCoverageM2: v.cartonCoverageM2 || "0", salePriceIQD: v.salePriceIQD || "0", salePriceUSD: v.salePriceUSD || "0", purchasePriceIQD: v.purchasePriceIQD || "0", purchasePriceUSD: v.purchasePriceUSD || "0", reorderLevel: v.reorderLevel || "0" } })}
        onToggle={(row, reason) => productToggle.mutateAsync({ id: row.id, isActive: row.isActive === 0, reason })} />}
      {tab === "warehouses" && <EntityTable rows={(warehouses.data ?? []) as Row[]} loading={warehouses.isLoading} error={warehouses.isError} canCreate createLabel="زیادکردنی کۆگا"
        fields={[{ key: "name", label: "ناو" }, { key: "address", label: "ناونیشان" }, { key: "managerName", label: "بەرپرس" }]}
        onSave={(id, v, reason) => id === null ? warehouseCreate.mutateAsync({ name: v.name, address: v.address, managerName: v.managerName }) : warehouseUpdate.mutateAsync({ id, reason, data: { name: v.name, address: v.address, managerName: v.managerName } })}
        onToggle={(row, reason) => warehouseToggle.mutateAsync({ id: row.id, isActive: row.isActive === 0, reason })} />}
      {tab === "drivers" && <EntityTable rows={(drivers.data ?? []) as Row[]} loading={drivers.isLoading} error={drivers.isError} canCreate createLabel="زیادکردنی شۆفێر"
        fields={[{ key: "name", label: "ناو" }, { key: "phone", label: "مۆبایل" }, { key: "vehicleNumber", label: "ژمارەی ئۆتۆمبێل" }, { key: "vehicleType", label: "جۆر" }, { key: "notes", label: "تێبینی" }]}
        onSave={(id, v, reason) => id === null ? driverCreate.mutateAsync({ name: v.name, phone: v.phone, vehicleNumber: v.vehicleNumber, vehicleType: v.vehicleType, notes: v.notes }) : driverUpdate.mutateAsync({ id, reason, data: { name: v.name, phone: v.phone, vehicleNumber: v.vehicleNumber, vehicleType: v.vehicleType, notes: v.notes } })}
        onToggle={(row, reason) => driverToggle.mutateAsync({ id: row.id, isActive: row.isActive === 0, reason })} />}
      {tab === "purchases" && <PurchasesTab />}
    </section>
  </main>;
}
