import { useState } from "react";
import { Download, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";

const money = (value: number) => value.toLocaleString("ku-IQ", { maximumFractionDigits: 2 });
type Pair = { IQD: number; USD: number };

function downloadCsv(name: string, rows: Array<Array<string | number>>) {
  const escape = (cell: string | number) => `"${String(cell).replace(/"/g, '""')}"`;
  const blob = new Blob(["\ufeff" + rows.map(row => row.map(escape).join(",")).join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = name; a.click(); URL.revokeObjectURL(url);
}

function Stat({ label, value, tone = "text-[#203328]" }: { label: string; value: Pair; tone?: string }) {
  return <div className="rounded-2xl border border-[#dce9df] bg-white p-4"><p className="text-xs font-bold text-[#6f8875]">{label}</p><p className={`mt-2 text-lg font-extrabold ${tone}`}>{money(value.IQD)} IQD</p><p className={`text-sm font-bold ${tone}`}>{money(value.USD)} USD</p></div>;
}

export default function FinancialReports() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const query = trpc.manage.financialReport.useQuery({ startDate: startDate || undefined, endDate: endDate || undefined }, { retry: false });
  const data = query.data;
  return <main dir="rtl" className="mx-auto max-w-[1500px] space-y-6 text-[#203328]">
    <header className="flex flex-wrap items-end justify-between gap-3 print:hidden">
      <div><p className="text-xs font-bold text-[#5c9a68]">ڕاپۆرت</p><h1 className="mt-1 text-3xl font-extrabold">ڕاپۆرتی دارایی</h1><p className="mt-1 text-sm text-[#718076]">قەرزی کڕیاران، قەرزی فرۆشیاران، قازانجی تەخمینی، نرخی کۆگا و کاڵا کەمبووەکان.</p></div>
      <div className="flex flex-wrap items-end gap-2">
        <label className="text-xs font-semibold text-[#5c6f61]">لە بەروار<Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="mt-1 h-9 rounded-lg" /></label>
        <label className="text-xs font-semibold text-[#5c6f61]">تا بەروار<Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="mt-1 h-9 rounded-lg" /></label>
        <Button variant="outline" className="h-9 rounded-xl" onClick={() => window.print()}><Printer className="ml-2 h-4 w-4" />چاپ</Button>
      </div>
    </header>
    {query.isError && <p className="rounded-xl bg-[#fff1f0] px-4 py-3 text-sm font-semibold text-[#b86861]">بارکردنی ڕاپۆرت سەرکەوتوو نەبوو یان دەسەڵاتت نییە.</p>}
    {query.isLoading && <p className="py-10 text-center text-sm text-[#89958d]">داتا بار دەکرێت...</p>}
    {data && <>
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="کۆی قەرزی کڕیاران (بۆ ئێمە)" value={data.receivablesTotal as Pair} tone="text-[#2f8a54]" />
        <Stat label="کۆی قەرزی ئێمە بۆ فرۆشیاران" value={data.payablesTotal as Pair} tone="text-[#b86861]" />
        <Stat label="نرخی کۆگا (بە نرخی کڕین)" value={data.stockValue as Pair} tone="text-[#315e9b]" />
        <Stat label="قازانجی تەخمینی" value={data.profit.profit as Pair} tone="text-[#2f6f49]" />
      </section>

      <section className="rounded-[24px] border border-[#e3ebe3] bg-white p-5">
        <h2 className="text-lg font-extrabold">قازانج و زەرەر{startDate || endDate ? ` (${startDate || "..."} → ${endDate || "..."})` : " (هەموو کات)"}</h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Stat label="فرۆشتن" value={data.profit.revenue as Pair} /><Stat label="گەڕاوەی فرۆشتن" value={data.profit.salesReturns as Pair} /><Stat label="تێچووی کاڵای فرۆشراو" value={data.profit.cost as Pair} /><Stat label="خەرجی (سندوق)" value={data.profit.expenses as Pair} /><Stat label="کڕینی ماوەکە" value={data.profit.purchased as Pair} />
        </div>
        <p className="mt-3 text-[11px] text-[#89958d]">قازانج = فرۆشتن − گەڕاوە − تێچوو − خەرجی. تێچوو بە نرخی کڕینی ئێستای کاڵا هەژمار دەکرێت، بۆیە ژمارەکە تەخمینییە.</p>
      </section>

      <section className="grid gap-5 xl:grid-cols-2">
        <article className="rounded-[24px] border border-[#e3ebe3] bg-white p-5">
          <div className="flex items-center justify-between"><h2 className="text-lg font-extrabold">قەرزی کڕیاران ({data.receivables.length})</h2>
            <Button size="sm" variant="outline" className="print:hidden" onClick={() => downloadCsv("customer-debts.csv", [["ناو", "مۆبایل", "IQD", "USD", "ڕۆژ"], ...data.receivables.map(r => [r.name, r.phone ?? "", r.debtIQD, r.debtUSD, r.debtDays])])}><Download className="ml-1 h-3 w-3" />CSV</Button></div>
          <table className="mt-3 w-full text-right text-sm"><thead><tr className="border-b text-xs text-[#92a095]"><th className="pb-2 font-medium">کڕیار</th><th className="pb-2 font-medium">IQD</th><th className="pb-2 font-medium">USD</th><th className="pb-2 font-medium">ڕۆژ</th></tr></thead>
            <tbody>{data.receivables.map(r => <tr key={r.id} className="border-b border-[#f0f3f0] last:border-0"><td className="py-2 font-semibold">{r.name}</td><td className="py-2">{money(r.debtIQD)}</td><td className="py-2">{money(r.debtUSD)}</td><td className="py-2 text-xs text-[#89958d]">{r.debtDays}</td></tr>)}{!data.receivables.length && <tr><td colSpan={4} className="py-6 text-center text-xs text-[#89958d]">هیچ قەرزێک نییە.</td></tr>}</tbody></table>
        </article>
        <article className="rounded-[24px] border border-[#e3ebe3] bg-white p-5">
          <div className="flex items-center justify-between"><h2 className="text-lg font-extrabold">قەرزی فرۆشیاران ({data.payables.length})</h2>
            <Button size="sm" variant="outline" className="print:hidden" onClick={() => downloadCsv("supplier-debts.csv", [["ناو", "مۆبایل", "IQD", "USD"], ...data.payables.map(r => [r.name, r.phone ?? "", r.owedIQD, r.owedUSD])])}><Download className="ml-1 h-3 w-3" />CSV</Button></div>
          <table className="mt-3 w-full text-right text-sm"><thead><tr className="border-b text-xs text-[#92a095]"><th className="pb-2 font-medium">فرۆشیار</th><th className="pb-2 font-medium">IQD</th><th className="pb-2 font-medium">USD</th></tr></thead>
            <tbody>{data.payables.map(r => <tr key={r.id} className="border-b border-[#f0f3f0] last:border-0"><td className="py-2 font-semibold">{r.name}</td><td className="py-2">{money(r.owedIQD)}</td><td className="py-2">{money(r.owedUSD)}</td></tr>)}{!data.payables.length && <tr><td colSpan={3} className="py-6 text-center text-xs text-[#89958d]">هیچ قەرزێک نییە.</td></tr>}</tbody></table>
        </article>
      </section>

      <section className="rounded-[24px] border border-[#e3ebe3] bg-white p-5">
        <div className="flex items-center justify-between"><h2 className="text-lg font-extrabold">کاڵا کەمبووەکان ({data.lowStock.length})</h2>
          <Button size="sm" variant="outline" className="print:hidden" onClick={() => downloadCsv("low-stock.csv", [["کۆد", "ناو", "بڕی ماوە", "سنوور"], ...data.lowStock.map(r => [r.sku, r.name, r.quantity, r.reorderLevel])])}><Download className="ml-1 h-3 w-3" />CSV</Button></div>
        <p className="mt-1 text-[11px] text-[#89958d]">ئەو کاڵایانەی بڕی ماوەیان لە سنووری کەمبوون کەمترە یان یەکسانە (سنوور لە بەشی «بەڕێوەبردنی بنەڕەت» → کاڵاکان دیاری دەکرێت).</p>
        <table className="mt-3 w-full text-right text-sm"><thead><tr className="border-b text-xs text-[#92a095]"><th className="pb-2 font-medium">کۆد</th><th className="pb-2 font-medium">کاڵا</th><th className="pb-2 font-medium">ماوە</th><th className="pb-2 font-medium">سنوور</th></tr></thead>
          <tbody>{data.lowStock.map(r => <tr key={r.id} className="border-b border-[#f0f3f0] last:border-0"><td className="py-2 text-xs text-[#89958d]">{r.sku}</td><td className="py-2 font-semibold">{r.name}</td><td className="py-2 font-bold text-[#b86861]">{money(r.quantity)} {r.unit}</td><td className="py-2">{money(r.reorderLevel)}</td></tr>)}{!data.lowStock.length && <tr><td colSpan={4} className="py-6 text-center text-xs text-[#89958d]">هیچ کاڵایەک لە سنوور کەمتر نییە.</td></tr>}</tbody></table>
      </section>
    </>}
  </main>;
}
