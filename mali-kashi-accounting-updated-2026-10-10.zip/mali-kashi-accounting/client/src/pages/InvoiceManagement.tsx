import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export default function InvoiceManagement() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<number | null>(null);
  const utils = trpc.useUtils();
  const invoices = trpc.invoices.sales.useQuery({ search: search.trim() || undefined }, { retry: false });
  const detail = trpc.invoices.salesDetail.useQuery({ id: selected ?? 0 }, { enabled: Boolean(selected), retry: false });
  const audit = trpc.invoices.audit.useQuery({ entityType: "sale", entityId: selected ?? 0 }, { enabled: Boolean(selected), retry: false });
  const remove = trpc.sales.delete.useMutation({ onSuccess: () => { void utils.invoices.sales.invalidate(); setSelected(null); } });

  const openEdit = async (id: number) => {
    const data = await utils.invoices.salesDetail.fetch({ id });
    if (!data) return;
    const draft = { customerId: data.invoice.customerId ? String(data.invoice.customerId) : "", warehouseId: data.invoice.warehouseId ? String(data.invoice.warehouseId) : "", driverId: data.invoice.driverId ? String(data.invoice.driverId) : "", currency: data.invoice.currency, paymentTerm: data.invoice.paymentTerm, paidAmount: data.invoice.paidAmount, loadingFee: data.invoice.loadingFee, transportFee: data.invoice.transportFee, discount: data.invoice.discount, notes: data.invoice.notes ?? "", lines: data.lines.map(line => ({ productId: String(line.productId), productName: `کاڵا #${line.productId}`, quantity: String(line.quantity), cartonQuantity: String(line.cartonQuantity ?? "0"), unitPrice: String(line.unitPrice), discount: String(line.discount) })) };
    localStorage.setItem("mali-kashi-sale-draft-edit-id", String(id));
    localStorage.setItem("mali-kashi-sale-draft", JSON.stringify(draft));
    setLocation("/sales");
  };

  return <main dir="rtl" className="mx-auto w-full max-w-[1180px] space-y-4">
    <div className="flex flex-wrap items-center justify-between gap-3"><div><h1 className="text-2xl font-extrabold text-[#203328]">بەڕێوەبردنی پسوولەکانی فرۆشتن</h1><p className="mt-1 text-xs text-[#718076]">گەڕان بە ناوی کڕیار، بینین، دەستکاری و مێژووی گۆڕانکاری</p></div><Button onClick={() => setLocation("/sales")} className="rounded-xl bg-[#079b71] text-white">پسوولەی نوێ</Button></div>
    <div className="flex flex-col gap-2 rounded-2xl border border-[#dfe9e7] bg-white p-4 sm:flex-row sm:items-center"><label className="text-xs font-bold text-[#557064]">گەڕان</label><Input value={search} onChange={e => setSearch(e.target.value)} placeholder="ناوی کڕیار یان ژمارەی پسوولە..." className="h-10 rounded-xl" /></div>
    <section className="overflow-x-auto rounded-2xl border border-[#dfe9e7] bg-white"><div className="min-w-[820px]"><div className="grid grid-cols-7 bg-[#f2f8f4] px-4 py-3 text-xs font-bold text-[#557064]"><span>کڕیار</span><span>ژمارە</span><span>بەروار</span><span>دراو</span><span>کۆی گشتی</span><span>دۆخ</span><span>کردار</span></div>{invoices.isLoading ? <p className="p-6 text-center text-sm">داتا بار دەکرێت...</p> : invoices.data?.length ? invoices.data.map(row => <div key={row.id} className="grid grid-cols-7 items-center border-t border-[#edf2ef] px-4 py-3 text-xs"><b className="text-[#2f6f49]">{row.customerName || "کڕیاری نەناسراو"}</b><span>{row.invoiceNumber}</span><span>{new Date(row.createdAt).toLocaleDateString("ku-IQ")}</span><span>{row.currency}</span><b>{row.total}</b><span>{row.status === "confirmed" ? "پەسەندکراو" : "پاشگەزکراوە"}</span><div className="flex flex-wrap gap-1"><Button onClick={() => setSelected(row.id)} variant="outline" className="h-8 rounded-lg px-2 text-[10px]">وردەکاری</Button><Button onClick={() => void openEdit(row.id)} variant="outline" className="h-8 rounded-lg px-2 text-[10px]">دەستکاری</Button>{row.status === "confirmed" && <Button onClick={() => { if (window.confirm("ئایا دڵنیایت لە پاشگەزکردنەوەی ئەم پسوولەیە؟")) remove.mutate({ id: row.id }); }} variant="outline" className="h-8 rounded-lg px-2 text-[10px] text-red-600">سڕینەوە</Button>}</div></div>) : <p className="p-8 text-center text-sm text-[#89958d]">هیچ پسوولەیەک نییە.</p>}</div></section>
    {selected && <section className="rounded-2xl border border-[#dfe9e7] bg-white p-5"><div className="flex items-center justify-between gap-3"><h2 className="font-bold text-[#203328]">وردەکاری و مێژووی دەستکاری</h2><Button variant="outline" onClick={() => setSelected(null)} className="rounded-lg">داخستن</Button></div>{detail.data && <div className="mt-4 grid gap-3 sm:grid-cols-4"><Info label="کڕیار" value={invoices.data?.find(row => row.id === selected)?.customerName || "نەناسراو"} /><Info label="پسوولە" value={detail.data.invoice.invoiceNumber} /><Info label="کۆی گشتی" value={`${detail.data.invoice.total} ${detail.data.invoice.currency}`} /><Info label="هێڵەکان" value={String(detail.data.lines.length)} /></div>}<div className="mt-5 space-y-2"><h3 className="text-sm font-bold text-[#557064]">مێژووی گۆڕانکاری</h3>{audit.data?.length ? audit.data.map(log => <div key={log.id} className="rounded-xl bg-[#f7fbf7] p-3 text-xs"><b>{log.action === "update" ? "دەستکاری" : log.action === "cancel" ? "پاشگەزکردنەوە" : "دروستکردن"}</b><span className="mx-2 text-[#718076]">{new Date(log.createdAt).toLocaleString("ku-IQ")}</span><span className="text-[#718076]">{log.reasonForEdit || "بێ هۆکار"}</span></div>) : <p className="text-xs text-[#89958d]">هێشتا مێژووی دەستکاری نییە.</p>}</div></section>}
  </main>;
}
function Info({ label, value }: { label: string; value: string }) { return <div className="rounded-xl bg-[#f7fbf7] p-3"><p className="text-[10px] text-[#89958d]">{label}</p><p className="mt-1 text-sm font-bold text-[#304234]">{value}</p></div>; }
