import { useLocation } from "wouter";
import { ArrowDownLeft, ArrowUpLeft, Boxes, CircleDollarSign, ClipboardList, FileText, LayoutGrid, Package, ReceiptText, Settings2, ShieldCheck, ShoppingCart, Truck, Users, Warehouse, WalletCards } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { trpc } from "@/lib/trpc";

const modules: { title: string; subtitle: string; path: string; icon: LucideIcon; color: string; tint: string }[] = [
  { title: "فرۆشتن", subtitle: "پسوولە و فرۆشتن", path: "/sales", icon: ShoppingCart, color: "from-[#ef1631] to-[#ff3349]", tint: "bg-white/15" },
  { title: "کڕین", subtitle: "فاکتۆری کڕین", path: "/purchases", icon: ClipboardList, color: "from-[#1e67e8] to-[#347cff]", tint: "bg-white/15" },
  { title: "کڕیاران", subtitle: "کڕیار و حساب", path: "/customers", icon: Users, color: "from-[#06b884] to-[#0bc698]", tint: "bg-white/15" },
  { title: "فرۆشیاران", subtitle: "دابینکەر و حساب", path: "/suppliers", icon: Users, color: "from-[#7b2ce8] to-[#9942ff]", tint: "bg-white/15" },
  { title: "کۆگا", subtitle: "بڕ و جوڵەی کاڵا", path: "/inventory", icon: Warehouse, color: "from-[#08ae6b] to-[#16c47e]", tint: "bg-white/15" },
  { title: "کاڵاکان", subtitle: "بەڕێوەبردنی کاڵا", path: "/products", icon: Boxes, color: "from-[#70c900] to-[#8edb04]", tint: "bg-white/15" },
  { title: "بارەدان", subtitle: "وەرگرتنی بارەدان", path: "/purchases", icon: WalletCards, color: "from-[#06a6bf] to-[#11b9d3]", tint: "bg-white/15" },
  { title: "سندوقی دوکان", subtitle: "داهات و خەرجی", path: "/cashbox", icon: WalletCards, color: "from-[#e87500] to-[#f38b09]", tint: "bg-white/15" },
  { title: "گەڕاوە", subtitle: "گەڕاندنەوەی کاڵا", path: "/returns", icon: ReceiptText, color: "from-[#f20b63] to-[#ff2776]", tint: "bg-white/15" },
  { title: "خەرجی", subtitle: "تۆمارکردنی خەرج", path: "/cashbox", icon: CircleDollarSign, color: "from-[#fa5a00] to-[#ff7600]", tint: "bg-white/15" },
  { title: "ڕاپۆرت", subtitle: "وردەکاری کاروبار", path: "/reports", icon: FileText, color: "from-[#4c3ce8] to-[#6255f5]", tint: "bg-white/15" },
  { title: "دراو", subtitle: "بڕ و گۆڕینی دراو", path: "/cashbox", icon: CircleDollarSign, color: "from-[#078edb] to-[#16a6e8]", tint: "bg-white/15" },
  { title: "شۆفێرەکان", subtitle: "ناو و زانیاری مۆبایل", path: "/drivers", icon: Truck, color: "from-[#08ab93] to-[#16bba5]", tint: "bg-white/15" },
  { title: "بەخشین", subtitle: "بەڕێوەبردنی بەخشین", path: "/returns", icon: ReceiptText, color: "from-[#f39b00] to-[#ffad09]", tint: "bg-white/15" },
  { title: "ڕێکخستن", subtitle: "ڕێکخستنی سیستەم", path: "/settings", icon: Settings2, color: "from-[#666763] to-[#858681]", tint: "bg-white/15" },
  { title: "ڕۆڵی ئەدمین", subtitle: "دەسەڵات و پاراستن", path: "/users", icon: ShieldCheck, color: "from-[#00765c] to-[#0b936f]", tint: "bg-white/15" },
  { title: "ڕۆڵ", subtitle: "مۆڵەت و دەسەڵات", path: "/users", icon: ShieldCheck, color: "from-[#8022e8] to-[#9b35f4]", tint: "bg-white/15" },
  { title: "بەکارهێنەران", subtitle: "هەژمار و بەکارهێنەر", path: "/users", icon: Users, color: "from-[#cf00dd] to-[#e218e9]", tint: "bg-white/15" },
  { title: "ژمارەی کۆگا", subtitle: "پوختەی کۆگاکان", path: "/inventory", icon: Package, color: "from-[#2d4567] to-[#3d587d]", tint: "bg-white/15" },
];

function number(value: unknown, fallback = "0") { return String(value ?? fallback); }

export const mobileDashboardGridClassName = "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-3";
export const mobileDashboardCardClassName = "group relative min-h-[126px] overflow-hidden rounded-[22px] bg-gradient-to-br p-4 text-right text-white shadow-[0_8px_18px_rgba(80,80,100,0.14)] transition duration-200 hover:-translate-y-0.5 hover:shadow-lg active:scale-[.98] sm:min-h-[92px] sm:rounded-xl sm:p-3";

export default function Home() {
  const [, setLocation] = useLocation();
  const summaryQuery = trpc.dashboard.summary.useQuery(undefined, { retry: false });
  const summary = summaryQuery.data;
  const valueFor = (rows: Array<{ currency: string; total: string }> | undefined, currency: string) => rows?.find(row => row.currency === currency)?.total ?? "0";
  const cashValue = (currency: string, direction: "in" | "out") => summary?.cashSummary?.find(row => row.currency === currency && row.direction === direction)?.total ?? "0";

  return <div dir="rtl" className="min-h-screen bg-[#f7f8fc] text-[#30303a]">
    <div className="flex min-h-screen">
      <main className="min-w-0 flex-1">
        <header className="flex h-[58px] items-center justify-between border-b border-[#e8e9ef] bg-white px-4 sm:px-7">
          <div className="flex items-center gap-3"><div className="rounded-md bg-[#eef9f3] px-2 py-1 text-[10px] font-bold text-[#22915a]">سیستەمی جەلالی</div><span className="text-xs text-[#9296a2]">بەڕێوەبردنی کاروبار</span></div>
          <div className="flex items-center gap-3"><div className="text-right"><p className="text-sm font-bold text-[#30303a]">داشبۆرد</p><p className="hidden text-[10px] text-[#a5a8b1] sm:block">پوختەی کاروبار و چالاکییەکان</p></div><LayoutGrid className="h-4 w-4 text-[#6c7181]" /></div>
        </header>
        <div className="mx-auto max-w-[1180px] px-4 pb-10 pt-5 sm:px-7">
          <div className="mb-5 flex items-center justify-between gap-3 rounded-[22px] bg-white p-2 shadow-[0_3px_16px_rgba(40,50,80,0.06)] sm:rounded-none sm:bg-transparent sm:p-0 sm:shadow-none"><div className="flex items-center gap-2"><button onClick={() => setLocation("/settings")} className="rounded-[18px] border border-[#dce0e8] bg-white px-3 py-3 text-xs font-bold text-[#555b68] shadow-sm sm:rounded-lg sm:py-1.5">ڕێکخستنی کارتەکان <Settings2 className="mr-1 inline h-4 w-4" /></button></div><button onClick={() => setLocation("/sales")} className="rounded-[18px] border border-[#a9e8d3] bg-white px-3 py-3 text-xs font-bold text-[#268f62] shadow-sm sm:rounded-lg sm:border-0 sm:bg-[#e9f8ef] sm:py-1.5">نووسینەوە <ArrowUpLeft className="mr-1 inline h-4 w-4" /></button></div>
          <section className={mobileDashboardGridClassName}>
            {modules.map(({ title, subtitle, path, icon: Icon, color, tint }) => <button key={title} onClick={() => setLocation(path)} className={`${mobileDashboardCardClassName} ${color}`}><div className="absolute -left-3 -top-3 opacity-[0.12]"><Icon className="h-24 w-24 sm:h-20 sm:w-20" /></div><div className={`mb-3 flex h-11 w-11 items-center justify-center rounded-2xl ${tint} backdrop-blur-sm sm:mb-2 sm:h-8 sm:w-8 sm:rounded-lg`}><Icon className="h-6 w-6 sm:h-4 sm:w-4" /></div><p className="text-lg font-extrabold leading-none sm:text-sm">{title}</p><p className="mt-2 text-[11px] font-medium text-white/80 sm:mt-1 sm:text-[9px]">{subtitle}</p></button>)}
          </section>
          <section className="mt-5 grid grid-cols-1 gap-3 min-[420px]:grid-cols-2 lg:grid-cols-3">
            <StatCard label="کۆی فرۆشتن" value={summaryQuery.isLoading ? "…" : number(summary?.salesTotal)} icon={ArrowUpLeft} accent="green" suffix="IQD" />
            <StatCard label="کڕیاران" value={summaryQuery.isLoading ? "…" : number(summary?.customerCount)} icon={Users} accent="violet" suffix="کەس" />
            <StatCard label="کۆی کڕین بە دینار" value={summaryQuery.isLoading ? "…" : number(summary?.purchaseTotal)} icon={ClipboardList} accent="orange" suffix="IQD" />
            <StatCard label="کۆی فرۆشتن بە دۆلار" value={cashValue("USD", "in")} icon={CircleDollarSign} accent="cyan" suffix="USD" />
            <StatCard label="کۆی کڕین بە دۆلار" value={cashValue("USD", "out")} icon={CircleDollarSign} accent="orange" suffix="USD" />
          </section>
          <section className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2"><BalanceCard title="قەرزی کڕیارانی دوکان" icon={Users} red values={[`${valueFor(summary?.customerBalances, "IQD")} IQD`, `${valueFor(summary?.customerBalances, "USD")} USD`]} /><BalanceCard title="قەرزی فرۆشیارانی دوکان" icon={Truck} values={[`${valueFor(summary?.supplierBalances, "IQD")} IQD`, `${valueFor(summary?.supplierBalances, "USD")} USD`]} /></section>
          <section className="mt-3 rounded-xl border border-[#e5e7ef] bg-white p-4 shadow-[0_3px_12px_rgba(40,50,80,0.04)]"><div className="mb-3 flex items-center justify-between"><div><h2 className="text-sm font-extrabold text-[#3a3b46]">دوایین چالاکییەکان</h2><p className="mt-1 text-[10px] text-[#a1a4ae]">دوایین پسوولە و مامەڵەکان</p></div><ReceiptText className="h-5 w-5 text-[#8f95a3]" /></div>{summaryQuery.isLoading ? <p className="py-4 text-center text-xs text-[#a1a4ae]">داتا بار دەکرێت...</p> : summary?.recentSales?.length ? <div className="divide-y divide-[#f0f1f5]">{summary.recentSales.slice(0, 4).map(row => <div key={row.id} className="flex items-center justify-between gap-3 py-2.5 text-xs"><span className="font-semibold text-[#535662]">{row.invoiceNumber}</span><span className="text-[#9296a1]">{new Date(row.createdAt).toLocaleDateString("ku-IQ")}</span><span className="font-bold text-[#29915d]">{row.total} {row.currency}</span></div>)}</div> : <p className="py-4 text-center text-xs text-[#a1a4ae]">هێشتا هیچ مامەڵەیەک تۆمار نەکراوە.</p>}</section>
        </div>
      </main>
    </div>
  </div>;
}

function StatCard({ label, value, suffix, icon: Icon, accent }: { label: string; value: string; suffix: string; icon: LucideIcon; accent: string }) { const accents: Record<string, string> = { green: "bg-[#e7f8ee] text-[#24915b]", violet: "bg-[#f0edff] text-[#7b65db]", orange: "bg-[#fff3e5] text-[#e38a24]", cyan: "bg-[#e7f8fb] text-[#2aa3b8]" }; return <div className="min-h-[94px] rounded-xl border border-[#e5e7ef] bg-white p-4 shadow-[0_3px_12px_rgba(40,50,80,0.04)]"><div className="flex items-start justify-between"><div><p className="text-[10px] text-[#a0a3ad]">{label}</p><p className="mt-3 text-lg font-extrabold tracking-tight text-[#292b35]">{value} <span className="text-[10px] font-semibold text-[#9296a0]">{suffix}</span></p></div><div className={`flex h-8 w-8 items-center justify-center rounded-lg ${accents[accent]}`}><Icon className="h-4 w-4" /></div></div></div>; }
function BalanceCard({ title, icon: Icon, values, red = false }: { title: string; icon: LucideIcon; values: string[]; red?: boolean }) { return <div className={`rounded-xl border p-4 shadow-[0_3px_12px_rgba(40,50,80,0.04)] ${red ? "border-[#f3dfe3] bg-[#fffafa]" : "border-[#deebf4] bg-[#f9fcff]"}`}><div className="mb-3 flex items-center gap-2"><Icon className={`h-4 w-4 ${red ? "text-[#d76a77]" : "text-[#568fc3]"}`} /><p className="text-xs font-bold text-[#555762]">{title}</p></div><div className="grid grid-cols-2 gap-2">{values.map((value, i) => <div key={i} className="rounded-lg bg-white p-2 text-center"><p className="text-[9px] text-[#a0a3ad]">{i ? "دۆلار USD" : "دینار IQD"}</p><p className={`mt-1 text-xs font-extrabold ${red ? "text-[#a6404c]" : "text-[#24558b]"}`}>{value}</p></div>)}</div></div>; }
