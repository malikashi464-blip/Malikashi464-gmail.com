import { trpc } from "@/lib/trpc";

const entityLabels: Record<string, string> = { sale: "پسوولەی فرۆشتن", purchase: "پسوولەی کڕین", return: "گەڕاوە", customer_payment: "پارەدانی کڕیار", cash: "سندوق", supplier: "فرۆشیار", product: "کاڵا", warehouse: "کۆگا", driver: "شۆفێر" };
const actionLabels: Record<string, string> = { create: "دروستکردن", update: "دەستکاری", cancel: "هەڵوەشاندنەوە" };

export default function AuditLog() {
  const query = trpc.manage.auditRecent.useQuery(undefined, { retry: false });
  return <main dir="rtl" className="mx-auto max-w-[1500px] space-y-5 text-[#203328]">
    <header><p className="text-xs font-bold text-[#5c9a68]">پاراستن</p><h1 className="mt-1 text-3xl font-extrabold">لۆگی گۆڕانکاری</h1><p className="mt-1 text-sm text-[#718076]">٢٠٠ کردارە نوێیەکان: کێ چی گۆڕی و بۆچی. تەنها ئەدمین دەیبینێت.</p></header>
    {query.isError && <p className="rounded-xl bg-[#fff1f0] px-4 py-3 text-sm font-semibold text-[#b86861]">بارکردن سەرکەوتوو نەبوو یان دەسەڵاتت نییە.</p>}
    <div className="overflow-x-auto rounded-[24px] border border-[#e3ebe3] bg-white p-5"><table className="w-full min-w-[720px] text-right text-sm">
      <thead><tr className="border-b border-[#edf1ed] text-xs text-[#92a095]"><th className="pb-3 font-medium">کات</th><th className="pb-3 font-medium">بەکارهێنەر</th><th className="pb-3 font-medium">جۆر</th><th className="pb-3 font-medium">ژمارە</th><th className="pb-3 font-medium">کردار</th><th className="pb-3 font-medium">هۆکار</th></tr></thead>
      <tbody>{query.isLoading ? <tr><td colSpan={6} className="py-8 text-center text-xs text-[#89958d]">داتا بار دەکرێت...</td></tr> : (query.data ?? []).map(row => <tr key={row.id} className="border-b border-[#f0f3f0] last:border-0"><td className="py-3 text-xs text-[#89958d]">{new Date(row.createdAt).toLocaleString("ku-IQ")}</td><td className="py-3">{row.editorName ?? "—"}</td><td className="py-3 font-semibold">{entityLabels[row.entityType] ?? row.entityType}</td><td className="py-3">#{row.entityId}</td><td className="py-3">{actionLabels[row.action] ?? row.action}</td><td className="py-3 text-xs text-[#718076]">{row.reasonForEdit ?? "—"}</td></tr>)}</tbody></table></div>
  </main>;
}
