import { useEffect, useMemo, useState } from "react";
import { CalendarRange, Printer, ReceiptText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

type PeriodKey = "today" | "week" | "month" | "year";
type ReceiptRow = { id: number; customerId: number | null; customerName: string; date: Date | string; currency: "IQD" | "USD"; amount: string; note: string | null; source: string };

const periodLabels: Record<PeriodKey, string> = { today: "ئەمڕۆ", week: "ئەم هەفتەیە", month: "ئەم مانگە", year: "ئەم ساڵە" };

function startOfPeriod(key: PeriodKey, now = new Date()) {
  const start = new Date(now); start.setHours(0, 0, 0, 0);
  if (key === "week") { const day = start.getDay(); start.setDate(start.getDate() - (day === 0 ? 6 : day - 1)); }
  if (key === "month") start.setDate(1);
  if (key === "year") { start.setMonth(0, 1); }
  return start;
}
function endOfPeriod(key: PeriodKey, now = new Date()) { const end = startOfPeriod(key, now); if (key === "today") end.setDate(end.getDate() + 1); if (key === "week") end.setDate(end.getDate() + 7); if (key === "month") end.setMonth(end.getMonth() + 1, 1); if (key === "year") end.setFullYear(end.getFullYear() + 1, 0, 1); return end; }
function money(value: number) { return value.toLocaleString("ku-IQ", { maximumFractionDigits: 2 }); }

export default function Reports() {
  const [, setLocation] = useLocation();
  const receiptsQuery = trpc.reports.customerReceipts.useQuery(undefined, { retry: false });
  const receipts = (receiptsQuery.data ?? []) as ReceiptRow[];
  const [printPeriod, setPrintPeriod] = useState<PeriodKey | null>(null);
  const periods = useMemo(() => (Object.keys(periodLabels) as PeriodKey[]).map(key => { const start = startOfPeriod(key); const end = endOfPeriod(key); const rows = receipts.filter(row => { const date = new Date(row.date); return date >= start && date < end; }); const totals = rows.reduce((total, row) => { total[row.currency] += Number(row.amount); return total; }, { IQD: 0, USD: 0 }); return { key, label: periodLabels[key], rows, totals }; }), [receipts]);
  useEffect(() => { if (!printPeriod) return; const afterPrint = () => setPrintPeriod(null); window.addEventListener("afterprint", afterPrint); const timer = window.setTimeout(() => window.print(), 80); return () => { window.clearTimeout(timer); window.removeEventListener("afterprint", afterPrint); }; }, [printPeriod]);
  return <main dir="rtl" className="receipt-report-shell min-h-screen w-full space-y-5 bg-[#f7f8f5] text-[#203328]"><header className="flex flex-wrap items-end justify-between gap-3"><div><button onClick={() => setLocation("/")} className="mb-2 text-xs font-semibold text-[#5a8b64]">← گەڕانەوە بۆ داشبۆرد</button><p className="text-xs font-bold text-[#5c9a68]">ڕاپۆرتی پارەی وەرگیراو</p><h1 className="mt-1 text-3xl font-extrabold">واسڵکراوەکانی کڕیاران</h1><p className="mt-1 text-sm text-[#718076]">کۆی پارەی وەرگیراو بە ناوی کڕیار و بەرواری مامەڵە</p></div><div className="rounded-2xl bg-white px-4 py-3 text-xs font-bold text-[#557064]"><CalendarRange className="ml-1 inline h-4 w-4" /> چوار ماوەی کات</div></header>{receiptsQuery.isError && <p className="rounded-xl bg-[#fff1f0] px-4 py-3 text-sm font-semibold text-[#b86861]">بارکردنی ڕاپۆرت سەرکەوتوو نەبوو.</p>}<section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{periods.map(period => <article key={period.key} className={`receipt-report rounded-2xl border border-[#dce9df] bg-white p-4 shadow-sm ${printPeriod === period.key ? "receipt-report-selected" : ""}`}><div className="flex items-start justify-between gap-2"><div><p className="text-sm font-extrabold text-[#304234]">واسڵی {period.label}</p><p className="mt-1 text-[11px] text-[#89958d]">{period.rows.length} مامەڵە</p></div><ReceiptText className="h-5 w-5 text-[#4d945a]" /></div><div className="mt-4 grid grid-cols-2 gap-2"><div className="rounded-xl bg-[#eef8ef] p-3"><span className="block text-[10px] text-[#6f8875]">دینار</span><b className="mt-1 block text-sm text-[#2f8a54]">{money(period.totals.IQD)} IQD</b></div><div className="rounded-xl bg-[#eef5ff] p-3"><span className="block text-[10px] text-[#70819b]">دۆلار</span><b className="mt-1 block text-sm text-[#315e9b]">{money(period.totals.USD)} USD</b></div></div><Button type="button" onClick={() => setPrintPeriod(period.key)} className="mt-4 h-9 w-full rounded-xl bg-[#2f7b49] text-xs text-white"><Printer className="ml-2 h-4 w-4" />چاپکردنی {period.label}</Button><div className="mt-4 space-y-2 border-t border-[#edf2ef] pt-3">{receiptsQuery.isLoading ? <p className="py-5 text-center text-xs text-[#89958d]">داتا بار دەکرێت...</p> : period.rows.length ? period.rows.map(row => <div key={`${period.key}-${row.source}-${row.id}`} className="rounded-xl bg-[#fbfdfb] p-3 text-xs"><div className="flex items-start justify-between gap-2"><b className="text-[#304234]">{row.customerName}</b><strong className={row.currency === "IQD" ? "text-[#2f8a54]" : "text-[#315e9b]"}>{money(Number(row.amount))} {row.currency}</strong></div><p className="mt-1 text-[10px] text-[#89958d]">{new Date(row.date).toLocaleString("ku-IQ")}</p>{row.note && <p className="mt-1 text-[10px] text-[#718076]">{row.note}</p>}</div>) : <p className="py-5 text-center text-xs text-[#89958d]">لەو ماوەیەدا هیچ واسڵێک نییە.</p>}</div></article>)}</section></main>;
}
