# Sidebar Reference Findings

The supplied narrow sidebar reference is a portrait mobile screenshot. Verified reading order from top to bottom:

1. بەکارهێنەران
2. داشبۆرد
3. فرۆشتن
4. کڕیارەکان
5. ڕۆڵی ئەدمین
6. گەڕاوە
7. بەخشین
8. کۆگا
9. شۆفێرەکان
10. فرۆشیاران
11. کڕین
12. خەرجی
13. جوڵەی کاڵا
14. دراو
15. بارەدان و کۆمپاساب
16. سندوقی دوکان
17. ڕێکخستن
18. بەکارهێنەران (highlighted active in the lower section)
19. ڕۆڵ
20. ژمارەی کۆگاکان
21. وەرگرتنی کاڵاکۆ
22. ڕاپۆرتی کڕینەکان
23. ڕاپۆرتی کڕیارەکان

The screenshot uses a white compact rail, dark gray small labels, small line icons, tight vertical spacing, and a pale blue active-row background. The lower repeated labels are treated as distinct reference entries because they appear in the source image; route navigation must use unique keys and only one active item per current route.

## Final implementation verification

The compact sidebar was checked at 720x1610 and 1280x720 after the final rewrite. The verified order begins with بەکارهێنەران, داشبۆرد, فرۆشتن, کڕیارەکان, ڕۆڵی ئەدمین, گەڕاوە, بەخشین, کۆگا, شۆفێرەکان, فرۆشیاران, کڕین, خەرجی, جوڵەی کاڵا, دراو, بارەدان و حساب, سندوقی دوکان, ڕێکخستن, then the lower account/role/report items. Route-specific IDs prevent duplicate active highlights; the dashboard row is the only active row on the dashboard route. The rail is visible on mobile and the full compact sidebar is visible on desktop.
