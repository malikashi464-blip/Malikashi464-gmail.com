import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

const id = (name = "id") => int(name).autoincrement().primaryKey();
const createdAt = () => timestamp("createdAt").defaultNow().notNull();
const updatedAt = () => timestamp("updatedAt").defaultNow().onUpdateNow().notNull();

export const users = mysqlTable("users", {
  id: id(), openId: varchar("openId", { length: 64 }).notNull().unique(), name: text("name"), email: varchar("email", { length: 320 }), loginMethod: varchar("loginMethod", { length: 64 }), role: mysqlEnum("role", ["user", "admin", "manager", "editor", "viewer"]).default("user").notNull(), createdAt: createdAt(), updatedAt: updatedAt(), lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const customers = mysqlTable("customers", {
  id: id(), name: varchar("name", { length: 180 }).notNull(), phone: varchar("phone", { length: 32 }), address: varchar("address", { length: 255 }), notes: text("notes"), currency: mysqlEnum("currency", ["IQD", "USD"]).default("IQD").notNull(), openingBalance: decimal("openingBalance", { precision: 18, scale: 2 }).default("0").notNull(), advancePaymentIQD: decimal("advancePaymentIQD", { precision: 18, scale: 2 }).default("0").notNull(), advancePaymentUSD: decimal("advancePaymentUSD", { precision: 18, scale: 2 }).default("0").notNull(), isActive: int("isActive").default(1).notNull(), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const customerPayments = mysqlTable("customerPayments", {
  id: id(), customerId: int("customerId").notNull(), saleId: int("saleId"), currency: mysqlEnum("currency", ["IQD", "USD"]).notNull(), direction: mysqlEnum("direction", ["in", "out"]).notNull(), amount: decimal("amount", { precision: 18, scale: 2 }).default("0").notNull(), referenceType: varchar("referenceType", { length: 40 }), referenceId: int("referenceId"), note: text("note"), createdBy: int("createdBy"), createdAt: createdAt(),
});

export const suppliers = mysqlTable("suppliers", {
  id: id(), name: varchar("name", { length: 180 }).notNull(), phone: varchar("phone", { length: 32 }), address: varchar("address", { length: 255 }), notes: text("notes"), currency: mysqlEnum("currency", ["IQD", "USD"]).default("IQD").notNull(), openingBalance: decimal("openingBalance", { precision: 18, scale: 2 }).default("0").notNull(), isActive: int("isActive").default(1).notNull(), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const products = mysqlTable("products", {
  id: id(), sku: varchar("sku", { length: 64 }).notNull().unique(), barcode: varchar("barcode", { length: 96 }).unique(), imageUrl: varchar("imageUrl", { length: 512 }), imageKey: varchar("imageKey", { length: 512 }), name: varchar("name", { length: 180 }).notNull(), category: varchar("category", { length: 120 }), unit: varchar("unit", { length: 24 }).default("دانە").notNull(), cartonCoverageM2: decimal("cartonCoverageM2", { precision: 12, scale: 4 }).default("0").notNull(), salePriceIQD: decimal("salePriceIQD", { precision: 18, scale: 2 }).default("0").notNull(), salePriceUSD: decimal("salePriceUSD", { precision: 18, scale: 2 }).default("0").notNull(), purchasePriceIQD: decimal("purchasePriceIQD", { precision: 18, scale: 2 }).default("0").notNull(), purchasePriceUSD: decimal("purchasePriceUSD", { precision: 18, scale: 2 }).default("0").notNull(), reorderLevel: decimal("reorderLevel", { precision: 18, scale: 2 }).default("0").notNull(), isActive: int("isActive").default(1).notNull(), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const warehouses = mysqlTable("warehouses", {
  id: id(), name: varchar("name", { length: 140 }).notNull(), address: varchar("address", { length: 255 }), managerName: varchar("managerName", { length: 140 }), isActive: int("isActive").default(1).notNull(), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const drivers = mysqlTable("drivers", {
  id: id(), name: varchar("name", { length: 140 }).notNull(), phone: varchar("phone", { length: 32 }), vehicleNumber: varchar("vehicleNumber", { length: 64 }), vehicleType: varchar("vehicleType", { length: 80 }), notes: text("notes"), isActive: int("isActive").default(1).notNull(), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const sales = mysqlTable("sales", {
  id: id(), invoiceNumber: varchar("invoiceNumber", { length: 64 }).notNull().unique(), customerId: int("customerId"), warehouseId: int("warehouseId"), driverId: int("driverId"), currency: mysqlEnum("currency", ["IQD", "USD"]).default("IQD").notNull(), paymentTerm: mysqlEnum("paymentTerm", ["cash", "credit", "partial"]).default("credit").notNull(), subtotal: decimal("subtotal", { precision: 18, scale: 2 }).default("0").notNull(), discount: decimal("discount", { precision: 18, scale: 2 }).default("0").notNull(), loadingFee: decimal("loadingFee", { precision: 18, scale: 2 }).default("0").notNull(), transportFee: decimal("transportFee", { precision: 18, scale: 2 }).default("0").notNull(), total: decimal("total", { precision: 18, scale: 2 }).default("0").notNull(), paidAmount: decimal("paidAmount", { precision: 18, scale: 2 }).default("0").notNull(), status: mysqlEnum("status", ["draft", "confirmed", "cancelled"]).default("draft").notNull(), notes: text("notes"), createdBy: int("createdBy"), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const saleItems = mysqlTable("saleItems", {
  id: id(), saleId: int("saleId").notNull(), productId: int("productId").notNull(), quantity: decimal("quantity", { precision: 18, scale: 3 }).default("0").notNull(), cartonQuantity: decimal("cartonQuantity", { precision: 18, scale: 4 }).default("0").notNull(), unitPrice: decimal("unitPrice", { precision: 18, scale: 2 }).default("0").notNull(), discount: decimal("discount", { precision: 18, scale: 2 }).default("0").notNull(), lineTotal: decimal("lineTotal", { precision: 18, scale: 2 }).default("0").notNull(),
});

export const purchases = mysqlTable("purchases", {
  id: id(), billNumber: varchar("billNumber", { length: 64 }).notNull().unique(), supplierId: int("supplierId"), warehouseId: int("warehouseId"), currency: mysqlEnum("currency", ["IQD", "USD"]).default("IQD").notNull(), paymentTerm: mysqlEnum("paymentTerm", ["cash", "credit", "partial"]).default("credit").notNull(), subtotal: decimal("subtotal", { precision: 18, scale: 2 }).default("0").notNull(), discount: decimal("discount", { precision: 18, scale: 2 }).default("0").notNull(), total: decimal("total", { precision: 18, scale: 2 }).default("0").notNull(), paidAmount: decimal("paidAmount", { precision: 18, scale: 2 }).default("0").notNull(), status: mysqlEnum("status", ["draft", "received", "cancelled"]).default("draft").notNull(), notes: text("notes"), createdBy: int("createdBy"), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const purchaseItems = mysqlTable("purchaseItems", {
  id: id(), purchaseId: int("purchaseId").notNull(), productId: int("productId").notNull(), quantity: decimal("quantity", { precision: 18, scale: 3 }).default("0").notNull(), cartonQuantity: decimal("cartonQuantity", { precision: 18, scale: 4 }).default("0").notNull(), unitPrice: decimal("unitPrice", { precision: 18, scale: 2 }).default("0").notNull(), discount: decimal("discount", { precision: 18, scale: 2 }).default("0").notNull(), lineTotal: decimal("lineTotal", { precision: 18, scale: 2 }).default("0").notNull(),
});

export const stockMovements = mysqlTable("stockMovements", {
  id: id(), productId: int("productId").notNull(), fromWarehouseId: int("fromWarehouseId"), toWarehouseId: int("toWarehouseId"), quantity: decimal("quantity", { precision: 18, scale: 3 }).default("0").notNull(), cartonQuantity: decimal("cartonQuantity", { precision: 18, scale: 4 }).default("0").notNull(), unitPrice: decimal("unitPrice", { precision: 18, scale: 2 }).default("0").notNull(), currency: mysqlEnum("currency", ["IQD", "USD"]).default("IQD").notNull(), movementType: mysqlEnum("movementType", ["purchase", "sale", "return", "transfer", "adjustment"]).notNull(), referenceType: varchar("referenceType", { length: 40 }), referenceId: int("referenceId"), note: text("note"), createdBy: int("createdBy"), createdAt: createdAt(),
});

export const returns = mysqlTable("returns", {
  id: id(), returnNumber: varchar("returnNumber", { length: 64 }).notNull().unique(), direction: mysqlEnum("direction", ["sales", "purchases"]).notNull(), customerId: int("customerId"), supplierId: int("supplierId"), originalSaleId: int("originalSaleId"), originalPurchaseId: int("originalPurchaseId"), currency: mysqlEnum("currency", ["IQD", "USD"]).default("IQD").notNull(), total: decimal("total", { precision: 18, scale: 2 }).default("0").notNull(), cartonQuantity: decimal("cartonQuantity", { precision: 18, scale: 4 }).default("0").notNull(), allowance: decimal("allowance", { precision: 18, scale: 2 }).default("0").notNull(), notes: text("notes"), createdBy: int("createdBy"), createdAt: createdAt(),
});

export const returnItems = mysqlTable("returnItems", {
  id: id(), returnId: int("returnId").notNull(), productId: int("productId").notNull(), quantity: decimal("quantity", { precision: 18, scale: 3 }).default("0").notNull(), cartonQuantity: decimal("cartonQuantity", { precision: 18, scale: 4 }).default("0").notNull(),
});

export const cashTransactions = mysqlTable("cashTransactions", {
  id: id(), transactionNumber: varchar("transactionNumber", { length: 64 }).notNull().unique(), currency: mysqlEnum("currency", ["IQD", "USD"]).notNull(), direction: mysqlEnum("direction", ["in", "out"]).notNull(), amount: decimal("amount", { precision: 18, scale: 2 }).default("0").notNull(), category: varchar("category", { length: 100 }).notNull(), customerId: int("customerId"), supplierId: int("supplierId"), referenceType: varchar("referenceType", { length: 40 }), referenceId: int("referenceId"), note: text("note"), createdBy: int("createdBy"), createdAt: createdAt(),
});

export const businessSettings = mysqlTable("businessSettings", {
  id: id(), businessName: varchar("businessName", { length: 180 }).default("ماڵی کاشی").notNull(), phone: varchar("phone", { length: 32 }), address: varchar("address", { length: 255 }), defaultCurrency: mysqlEnum("defaultCurrency", ["IQD", "USD"]).default("IQD").notNull(), usdRate: decimal("usdRate", { precision: 18, scale: 4 }).default("0").notNull(), invoicePrefix: varchar("invoicePrefix", { length: 16 }).default("INV").notNull(), updatedBy: int("updatedBy"), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const userPermissions = mysqlTable("userPermissions", {
  id: id(), userId: int("userId").notNull(), module: varchar("module", { length: 60 }).notNull(), canView: int("canView").default(0).notNull(), canCreate: int("canCreate").default(0).notNull(), canEdit: int("canEdit").default(0).notNull(), canDelete: int("canDelete").default(0).notNull(), createdAt: createdAt(), updatedAt: updatedAt(),
});

export const auditLogs = mysqlTable("auditLogs", {
  id: id(), entityType: varchar("entityType", { length: 40 }).notNull(), entityId: int("entityId").notNull(), action: mysqlEnum("action", ["create", "update", "cancel"]).notNull(), editedBy: int("editedBy"), reasonForEdit: text("reasonForEdit"), previousValues: text("previousValues"), newValues: text("newValues"), createdAt: createdAt(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
