CREATE TABLE `businessSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`businessName` varchar(180) NOT NULL DEFAULT 'ماڵی کاشی',
	`phone` varchar(32),
	`address` varchar(255),
	`defaultCurrency` enum('IQD','USD') NOT NULL DEFAULT 'IQD',
	`usdRate` decimal(18,4) NOT NULL DEFAULT '0',
	`invoicePrefix` varchar(16) NOT NULL DEFAULT 'INV',
	`updatedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `businessSettings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cashTransactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`transactionNumber` varchar(64) NOT NULL,
	`currency` enum('IQD','USD') NOT NULL,
	`direction` enum('in','out') NOT NULL,
	`amount` decimal(18,2) NOT NULL DEFAULT '0',
	`category` varchar(100) NOT NULL,
	`customerId` int,
	`supplierId` int,
	`referenceType` varchar(40),
	`referenceId` int,
	`note` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cashTransactions_id` PRIMARY KEY(`id`),
	CONSTRAINT `cashTransactions_transactionNumber_unique` UNIQUE(`transactionNumber`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`phone` varchar(32),
	`address` varchar(255),
	`notes` text,
	`currency` enum('IQD','USD') NOT NULL DEFAULT 'IQD',
	`openingBalance` decimal(18,2) NOT NULL DEFAULT '0',
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `drivers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(140) NOT NULL,
	`phone` varchar(32),
	`vehicleNumber` varchar(64),
	`vehicleType` varchar(80),
	`notes` text,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drivers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sku` varchar(64) NOT NULL,
	`name` varchar(180) NOT NULL,
	`category` varchar(120),
	`unit` varchar(24) NOT NULL DEFAULT 'دانە',
	`salePriceIQD` decimal(18,2) NOT NULL DEFAULT '0',
	`salePriceUSD` decimal(18,2) NOT NULL DEFAULT '0',
	`purchasePriceIQD` decimal(18,2) NOT NULL DEFAULT '0',
	`purchasePriceUSD` decimal(18,2) NOT NULL DEFAULT '0',
	`reorderLevel` decimal(18,2) NOT NULL DEFAULT '0',
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`),
	CONSTRAINT `products_sku_unique` UNIQUE(`sku`)
);
--> statement-breakpoint
CREATE TABLE `purchaseItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`purchaseId` int NOT NULL,
	`productId` int NOT NULL,
	`quantity` decimal(18,3) NOT NULL DEFAULT '0',
	`unitPrice` decimal(18,2) NOT NULL DEFAULT '0',
	`discount` decimal(18,2) NOT NULL DEFAULT '0',
	`lineTotal` decimal(18,2) NOT NULL DEFAULT '0',
	CONSTRAINT `purchaseItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`billNumber` varchar(64) NOT NULL,
	`supplierId` int,
	`warehouseId` int,
	`currency` enum('IQD','USD') NOT NULL DEFAULT 'IQD',
	`paymentTerm` enum('cash','credit','partial') NOT NULL DEFAULT 'credit',
	`subtotal` decimal(18,2) NOT NULL DEFAULT '0',
	`discount` decimal(18,2) NOT NULL DEFAULT '0',
	`total` decimal(18,2) NOT NULL DEFAULT '0',
	`paidAmount` decimal(18,2) NOT NULL DEFAULT '0',
	`status` enum('draft','received','cancelled') NOT NULL DEFAULT 'draft',
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `purchases_id` PRIMARY KEY(`id`),
	CONSTRAINT `purchases_billNumber_unique` UNIQUE(`billNumber`)
);
--> statement-breakpoint
CREATE TABLE `returns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`returnNumber` varchar(64) NOT NULL,
	`direction` enum('sales','purchases') NOT NULL,
	`customerId` int,
	`supplierId` int,
	`originalSaleId` int,
	`originalPurchaseId` int,
	`currency` enum('IQD','USD') NOT NULL DEFAULT 'IQD',
	`total` decimal(18,2) NOT NULL DEFAULT '0',
	`allowance` decimal(18,2) NOT NULL DEFAULT '0',
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `returns_id` PRIMARY KEY(`id`),
	CONSTRAINT `returns_returnNumber_unique` UNIQUE(`returnNumber`)
);
--> statement-breakpoint
CREATE TABLE `saleItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`saleId` int NOT NULL,
	`productId` int NOT NULL,
	`quantity` decimal(18,3) NOT NULL DEFAULT '0',
	`unitPrice` decimal(18,2) NOT NULL DEFAULT '0',
	`discount` decimal(18,2) NOT NULL DEFAULT '0',
	`lineTotal` decimal(18,2) NOT NULL DEFAULT '0',
	CONSTRAINT `saleItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(64) NOT NULL,
	`customerId` int,
	`warehouseId` int,
	`driverId` int,
	`currency` enum('IQD','USD') NOT NULL DEFAULT 'IQD',
	`paymentTerm` enum('cash','credit','partial') NOT NULL DEFAULT 'credit',
	`subtotal` decimal(18,2) NOT NULL DEFAULT '0',
	`discount` decimal(18,2) NOT NULL DEFAULT '0',
	`loadingFee` decimal(18,2) NOT NULL DEFAULT '0',
	`transportFee` decimal(18,2) NOT NULL DEFAULT '0',
	`total` decimal(18,2) NOT NULL DEFAULT '0',
	`paidAmount` decimal(18,2) NOT NULL DEFAULT '0',
	`status` enum('draft','confirmed','cancelled') NOT NULL DEFAULT 'draft',
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sales_id` PRIMARY KEY(`id`),
	CONSTRAINT `sales_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
CREATE TABLE `stockMovements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`productId` int NOT NULL,
	`fromWarehouseId` int,
	`toWarehouseId` int,
	`quantity` decimal(18,3) NOT NULL DEFAULT '0',
	`movementType` enum('purchase','sale','return','transfer','adjustment') NOT NULL,
	`referenceType` varchar(40),
	`referenceId` int,
	`note` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `stockMovements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `suppliers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`phone` varchar(32),
	`address` varchar(255),
	`notes` text,
	`currency` enum('IQD','USD') NOT NULL DEFAULT 'IQD',
	`openingBalance` decimal(18,2) NOT NULL DEFAULT '0',
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `suppliers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userPermissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`module` varchar(60) NOT NULL,
	`canView` int NOT NULL DEFAULT 0,
	`canCreate` int NOT NULL DEFAULT 0,
	`canEdit` int NOT NULL DEFAULT 0,
	`canDelete` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userPermissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `warehouses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(140) NOT NULL,
	`address` varchar(255),
	`managerName` varchar(140),
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `warehouses_id` PRIMARY KEY(`id`)
);
