CREATE TABLE `customerPayments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`saleId` int,
	`currency` enum('IQD','USD') NOT NULL,
	`direction` enum('in','out') NOT NULL,
	`amount` decimal(18,2) NOT NULL DEFAULT '0',
	`referenceType` varchar(40),
	`referenceId` int,
	`note` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `customerPayments_id` PRIMARY KEY(`id`)
);
