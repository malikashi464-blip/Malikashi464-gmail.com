ALTER TABLE `stockMovements` ADD `unitPrice` decimal(18,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `stockMovements` ADD `currency` enum('IQD','USD') DEFAULT 'IQD' NOT NULL;