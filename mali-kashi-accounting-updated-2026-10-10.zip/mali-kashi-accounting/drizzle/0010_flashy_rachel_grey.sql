ALTER TABLE `customers` ADD `advancePaymentIQD` decimal(18,2) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `advancePaymentUSD` decimal(18,2) DEFAULT '0' NOT NULL;