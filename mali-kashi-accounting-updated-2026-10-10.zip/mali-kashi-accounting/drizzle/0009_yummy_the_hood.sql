CREATE TABLE `returnItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`returnId` int NOT NULL,
	`productId` int NOT NULL,
	`quantity` decimal(18,3) NOT NULL DEFAULT '0',
	`cartonQuantity` decimal(18,4) NOT NULL DEFAULT '0',
	CONSTRAINT `returnItems_id` PRIMARY KEY(`id`)
);
