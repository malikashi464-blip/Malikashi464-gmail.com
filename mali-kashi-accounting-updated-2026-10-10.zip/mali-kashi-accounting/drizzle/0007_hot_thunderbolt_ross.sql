ALTER TABLE `purchaseItems` ADD `cartonQuantity` decimal(18,4) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `saleItems` ADD `cartonQuantity` decimal(18,4) DEFAULT '0' NOT NULL;--> statement-breakpoint
ALTER TABLE `stockMovements` ADD `cartonQuantity` decimal(18,4) DEFAULT '0' NOT NULL;