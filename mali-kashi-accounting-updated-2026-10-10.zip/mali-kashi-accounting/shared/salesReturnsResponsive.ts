export const salesReturnsCartonUi = {
  lineRow: "min-w-0 overflow-hidden",
  cartonBadge: "mr-1 inline-block max-w-full truncate text-[10px] text-[#6f8d83]",
  returnLine: "grid min-w-0 grid-cols-1 gap-2 overflow-hidden rounded-lg sm:grid-cols-[1fr_auto_auto]",
} as const;

export function hasNarrowWidthProtection(classes: string) {
  return classes.includes("min-w-0") && classes.includes("overflow-hidden");
}
