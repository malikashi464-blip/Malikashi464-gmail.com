export type SaleStockLine = { productId: string | number; quantity: string };
export type SaleStockBalance = { productId: number; warehouseId: number; quantity: string };

export function validateSaleStock(lines: SaleStockLine[], warehouseId: number | string | undefined, balances: SaleStockBalance[]) {
  const errors: Record<string, string> = {};
  if (!warehouseId) return { warehouse: "کۆگای فرۆشتن هەڵبژێرە", lines: errors };
  const requested = new Map<number, number>();
  for (const line of lines) requested.set(Number(line.productId), (requested.get(Number(line.productId)) ?? 0) + Number(line.quantity || 0));
  requested.forEach((quantity, productId) => {
    const available = balances.find(row => row.productId === productId && row.warehouseId === Number(warehouseId));
    if (!available || quantity > Number(available.quantity)) errors[String(productId)] = `بڕی بەردەست تەنها ${Number(available?.quantity ?? 0).toFixed(3)} ـە`;
  });
  return { warehouse: "", lines: errors };
}
