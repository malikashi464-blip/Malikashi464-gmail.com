export type WarehouseProductDraft = { code: string; name: string; purchasePrice: string; salePrice: string };
export function calculateCartons(squareMeters: string | number, squareMetersPerCarton?: string | number | null) {
  const total = Number(squareMeters);
  const coverage = Number(squareMetersPerCarton);
  if (!Number.isFinite(total) || !Number.isFinite(coverage) || total < 0 || coverage <= 0) return null;
  return Math.round((total / coverage) * 100) / 100;
}

export function validateWarehouseProduct(draft: WarehouseProductDraft) {
  const errors: Record<string, string> = {};
  if (!draft.code.trim()) errors.code = "کۆدی کاڵا پێویستە.";
  if (!draft.name.trim()) errors.name = "ناوی کاڵا پێویستە.";
  if (!draft.purchasePrice || Number(draft.purchasePrice) < 0 || !Number.isFinite(Number(draft.purchasePrice))) errors.purchasePrice = "نرخی کڕین بە شێوەی دروست بنووسە.";
  if (!draft.salePrice || Number(draft.salePrice) < 0 || !Number.isFinite(Number(draft.salePrice))) errors.salePrice = "نرخی فرۆشتن بە شێوەی دروست بنووسە.";
  return errors;
}

export const warehouseProductFormLayoutClassName = "grid grid-cols-1 gap-3 min-[480px]:grid-cols-2";
