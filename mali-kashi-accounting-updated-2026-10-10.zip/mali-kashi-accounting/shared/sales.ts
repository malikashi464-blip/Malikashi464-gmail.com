export type SaleLineCalculation = {
  quantity: string | number;
  unitPrice: string | number;
  discount: string | number;
};

export function calculateSaleTotals(
  lines: SaleLineCalculation[],
  invoiceDiscount: string | number,
  loadingFee: string | number,
  transportFee: string | number,
) {
  const subtotal = lines.reduce(
    (sum, line) => sum + Number(line.quantity || 0) * Number(line.unitPrice || 0) - Number(line.discount || 0),
    0,
  );
  const total = Math.max(0, subtotal - Number(invoiceDiscount || 0) + Number(loadingFee || 0) + Number(transportFee || 0));
  return { subtotal, total };
}

export type BarcodeProduct = { id: number; name: string; sku: string; barcode?: string | null };

export function findSaleProductByBarcode<T extends BarcodeProduct>(products: T[], code: string) {
  const normalized = code.trim().toLowerCase();
  if (!normalized) return undefined;
  return products.find(product => product.sku.trim().toLowerCase() === normalized || product.barcode?.trim().toLowerCase() === normalized);
}

export function calculateSaleCartons(quantity: string | number, cartonCoverageM2?: string | number | null) {
  const coverage = Number(cartonCoverageM2 || 0);
  const metres = Number(quantity || 0);
  if (!Number.isFinite(coverage) || coverage <= 0 || !Number.isFinite(metres) || metres <= 0) return null;
  return Math.round((metres / coverage) * 10000) / 10000;
}

export function buildSaleStockMovement(line: { productId: number; quantity: string; cartonQuantity?: string | null; unitPrice: string }, saleId: number, warehouseId: number, currency: "IQD" | "USD", note?: string, createdBy?: number | null) {
  return { productId: line.productId, fromWarehouseId: warehouseId, quantity: line.quantity, cartonQuantity: line.cartonQuantity ?? "0", unitPrice: line.unitPrice, currency, movementType: "sale" as const, referenceType: "sale", referenceId: saleId, note, createdBy };
}

export function buildReturnStockMovement(line: { productId: number; quantity: string; cartonQuantity: string; }, returnId: number, direction: "sales" | "purchases", warehouseId: number, note?: string, createdBy?: number | null) {
  return { productId: line.productId, fromWarehouseId: direction === "purchases" ? warehouseId : undefined, toWarehouseId: direction === "sales" ? warehouseId : undefined, quantity: line.quantity, cartonQuantity: line.cartonQuantity, movementType: "return" as const, referenceType: "return", referenceId: returnId, note, createdBy };
}

export function calculateReturnCartons(quantity: string | number, originalQuantity: string | number, storedCartons?: string | number | null, cartonCoverageM2?: string | number | null) {
  const metres = Number(quantity || 0);
  const originalMetres = Number(originalQuantity || 0);
  const cartons = Number(storedCartons || 0);
  if (!Number.isFinite(metres) || metres <= 0) return 0;
  if (cartons > 0 && originalMetres > 0) return Math.round(cartons * (metres / originalMetres) * 10000) / 10000;
  return calculateSaleCartons(metres, cartonCoverageM2) ?? 0;
}

export type PrintableSaleSnapshot = { lines: Array<{ productName: string; productId: string; quantity: string; unitPrice: string; discount: string; cartonQuantity?: string | null }>; currency: "IQD" | "USD"; total: number; customerName: string };
export type PrintState = { completed: boolean; snapshot: PrintableSaleSnapshot | null };
export function printStateAfterSuccessfulSale(snapshot: PrintableSaleSnapshot): PrintState { return { completed: true, snapshot }; }
export function printStateAfterDraftSave(): PrintState { return { completed: false, snapshot: null }; }
export function printStateAfterProductEdit(): PrintState { return { completed: false, snapshot: null }; }
export function canPrintSale(completed: boolean, snapshot: PrintableSaleSnapshot | null) { return completed && Boolean(snapshot?.lines.length); }
export function createPrintableSaleSnapshot(input: PrintableSaleSnapshot): PrintableSaleSnapshot { return { lines: input.lines.map(line => ({ ...line })), currency: input.currency, total: input.total, customerName: input.customerName }; }

export type SalePayloadInput = {
  customerId?: string; warehouseId?: string; currency: "IQD" | "USD"; paymentTerm: "cash" | "credit" | "partial"; paidAmount: string; loadingFee: string; transportFee: string; discount: string; notes: string;
  lines: Array<{ productId: string; quantity: string; unitPrice: string; discount: string; cartonQuantity?: string | null }>;
};
export function buildSalePayload(input: SalePayloadInput) {
  const { subtotal, total } = calculateSaleTotals(input.lines, input.discount, input.loadingFee, input.transportFee);
  return { customerId: input.customerId ? Number(input.customerId) : undefined, warehouseId: input.warehouseId ? Number(input.warehouseId) : undefined, currency: input.currency, paymentTerm: input.paymentTerm, subtotal: String(subtotal), discount: String(Number(input.discount || 0)), loadingFee: String(Number(input.loadingFee || 0)), transportFee: String(Number(input.transportFee || 0)), total: String(total), paidAmount: String(Number(input.paidAmount || 0)), notes: input.notes, lines: input.lines.filter(line => line.productId).map(line => ({ productId: Number(line.productId), quantity: line.quantity, cartonQuantity: line.cartonQuantity ?? undefined, unitPrice: line.unitPrice, discount: line.discount })) };
}
