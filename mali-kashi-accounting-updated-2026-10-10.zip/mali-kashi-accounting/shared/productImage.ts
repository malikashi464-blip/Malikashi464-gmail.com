export const productImageTypes = ["image/jpeg", "image/png", "image/webp", "image/gif"] as const;
export type ProductImageType = (typeof productImageTypes)[number];

export function validateProductImage(file: { type: string; size: number }) {
  if (!productImageTypes.includes(file.type as ProductImageType)) return { valid: false as const, message: "تەنها JPG، PNG، WEBP یان GIF ڕێگەپێدراوە." };
  if (file.size > 5 * 1024 * 1024) return { valid: false as const, message: "قەبارەی وێنە نابێت لە 5MB زیاتر بێت." };
  return { valid: true as const };
}
