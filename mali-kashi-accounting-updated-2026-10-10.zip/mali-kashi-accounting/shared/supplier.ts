export type SupplierDraft = { name: string; phone: string; address: string; notes: string };
export type SupplierErrors = Partial<Record<keyof SupplierDraft, string>>;

export function validateSupplierDraft(draft: SupplierDraft): SupplierErrors {
  const errors: SupplierErrors = {};
  if (draft.name.trim().length < 2) errors.name = "ناوی فرۆشیار پێویستە لانیکەم دوو پیت بێت";
  if (draft.phone.trim() && draft.phone.trim().length < 7) errors.phone = "ژمارەی فرۆشیار نادروستە";
  if (draft.address.trim().length > 255) errors.address = "ناونیشان زۆر درێژە";
  if (draft.notes.trim().length > 1000) errors.notes = "تێبینی زۆر درێژە";
  return errors;
}

export const supplierFormLayoutClassName = "grid gap-3 p-5 sm:grid-cols-2 lg:grid-cols-4";
export const supplierFormDesktopLayoutClassName = supplierFormLayoutClassName + " lg:items-end";
export const supplierFormOpenLayoutClassName = supplierFormDesktopLayoutClassName + " supplier-form-open";
export function supplierFormStateAfterSubmit(draft: SupplierDraft, outcome: "success" | "error"): SupplierDraft {
  return outcome === "success" ? { name: "", phone: "", address: "", notes: "" } : draft;
}
export function supplierSubmitEffects(outcome: "success" | "error") {
  return { clearForm: outcome === "success", refreshList: outcome === "success" } as const;
}
