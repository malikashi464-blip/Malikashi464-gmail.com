export const permissionModules = [
  { key: "dashboard", label: "داشبۆرد" },
  { key: "sales", label: "فرۆشتن" },
  { key: "customers", label: "کڕیارەکان" },
  { key: "customer-payments", label: "پارەدانی کڕیار" },
  { key: "purchases", label: "کڕین" },
  { key: "suppliers", label: "فرۆشیاران" },
  { key: "products", label: "کاڵاکان" },
  { key: "warehouse", label: "کۆگا و جوڵەی کاڵا" },
  { key: "returns", label: "گەڕاوە و بەخشین" },
  { key: "cashbox", label: "سندوق و خەرجی" },
  { key: "drivers", label: "شۆفێرەکان" },
  { key: "settings", label: "ڕێکخستن" },
  { key: "users", label: "بەکارهێنەر و ڕۆڵ" },
] as const;

export type PermissionModule = (typeof permissionModules)[number]["key"];
export type PermissionAction = "view" | "create" | "edit" | "delete";
export type Role = "admin" | "manager" | "editor" | "viewer" | "user";
export type PermissionFlags = Record<PermissionAction, boolean>;

export const permissionActions: Array<{ key: PermissionAction; label: string }> = [
  { key: "view", label: "بینین" },
  { key: "create", label: "دروستکردن" },
  { key: "edit", label: "دەستکاری" },
  { key: "delete", label: "سڕینەوە" },
];

export const roleOptions: Array<{ key: Role; label: string; description: string }> = [
  { key: "admin", label: "ئەدمین", description: "دەسەڵاتی تەواو و بەڕێوەبردنی ڕۆڵەکان" },
  { key: "manager", label: "بەڕێوەبەر", description: "بینین، تۆمارکردن، دەستکاری و سڕینەوەی مامەڵەکان" },
  { key: "editor", label: "دەستکار", description: "بینین، تۆمارکردن و دەستکاری؛ بێ سڕینەوە" },
  { key: "viewer", label: "تەنها بینین", description: "تەنها بینینی بەشە ڕێپێدراوەکان" },
  { key: "user", label: "بەکارهێنەر", description: "بینین، تۆمارکردن و دەستکاریی مامەڵەکان؛ بێ سڕینەوە" },
];

export const roleDefaults: Record<Exclude<Role, "admin">, PermissionFlags> = {
  manager: { view: true, create: true, edit: true, delete: true },
  editor: { view: true, create: true, edit: true, delete: false },
  viewer: { view: true, create: false, edit: false, delete: false },
  user: { view: true, create: true, edit: true, delete: false },
};

export const fullPermissionFlags: PermissionFlags = { view: true, create: true, edit: true, delete: true };
