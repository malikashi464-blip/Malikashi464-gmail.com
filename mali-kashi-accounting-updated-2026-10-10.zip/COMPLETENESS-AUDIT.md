# پشکنینی تەواوی archive ـی ماڵی کاشی

## ئەنجام

هیچ فایلێکی source لە پڕۆژەی latest ـی کاراک لە archive ـەکەدا بەجێ نەهێڵراوە.

- source ـی latest: **176 فایل** لە `client/`, `server/`, `drizzle/`, `shared/`
- source ـی latest هەمووی لە `mali-kashi-accounting/` ـدا هەیە
- schema و هەموو migration ـەکان لە `drizzle/` ـدان
- production build ـی نوێ لە `mali-kashi-accounting/dist/` ـە
- source ـی ZIP ـی سەرەتایی لە `supplemental/original-transfer-source/` ـە
- ZIP ـی سەرەتایی بە شێوەی خامیش لە `supplemental/` ـە

## شتە جێهێڵراوەکان

ئەم شتانە بە ئەنقەست لە archive ـەکەدا نیین چونکە runtime یان نهێنین، نەک تایبەتمەندی:

- `node_modules/`: بە `pnpm install` دروست دەکرێت و platform-dependent ـە.
- فایلەکانی environment و secret: نابێت لەگەڵ source بگوازرێنەوە.
- `.git/` و log ـەکانی session: کۆدی بەرنامە نین.

## پشتڕاستکردنەوە

پێش packaging:

- TypeScript check: سەرکەوتوو
- Vitest: **21 test files / 75 tests passed**
- Production build: سەرکەوتوو
- ZIP integrity test: سەرکەوتوو
